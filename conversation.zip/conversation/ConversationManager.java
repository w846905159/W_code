// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.conversation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ConversationManager {

    private final List<Message> history = new ArrayList<>();

    private boolean ltmInjected = false;

    private String activeSkillName;
    private String activeSkillBody;

    public void addUserMessage(String content) {
        history.add(new Message("user", content));
    }

    public void addAssistantMessage(String content) {
        history.add(new Message("assistant", content));
    }

    public void addAssistantFull(String text, List<ThinkingBlock> thinking, List<ToolUseBlock> toolUses) {
        var msg = new Message("assistant", text);
        msg.setThinkingBlocks(thinking);
        msg.setToolUses(toolUses);
        history.add(msg);
    }

    public void addAssistantMessageWithTools(String text, List<ToolUseBlock> toolUses) {
        var msg = new Message("assistant", text);
        msg.setToolUses(toolUses);
        history.add(msg);
    }

    public void addToolResultsMessage(List<ToolResultBlock> results) {
        var msg = new Message("user", "");
        msg.setToolResults(results);
        history.add(msg);
    }

    /**
     * Closes any tool-use / tool-result pairing left dangling by an interrupted
     * agent. When an agent is cancelled mid-turn it may have appended an assistant
     * message carrying {@code tool_use} blocks but never added the matching
     * {@code tool_result} message (results are only written after all tools
     * execute). Re-sending that orphaned tool_use to the LLM would break protocol
     * pairing, so append placeholder error results for every tool_use id with no
     * matching result. Idempotent: ids already matched are left untouched, so this
     * is safe to run even after the dying agent appended its own results.
     */
    public void repairDanglingToolUses() {
        Set<String> used = new LinkedHashSet<>();
        Set<String> matched = new HashSet<>();
        for (Message m : history) {
            if (m.getToolUses() != null) {
                for (ToolUseBlock tu : m.getToolUses()) {
                    if (tu.toolUseId() != null) used.add(tu.toolUseId());
                }
            }
            if (m.getToolResults() != null) {
                for (ToolResultBlock tr : m.getToolResults()) {
                    if (tr.toolUseId() != null) matched.add(tr.toolUseId());
                }
            }
        }
        List<ToolResultBlock> placeholders = new ArrayList<>();
        for (String id : used) {
            if (!matched.contains(id)) {
                placeholders.add(new ToolResultBlock(
                        id, "(user interrupted the agent before this tool returned a result)", true));
            }
        }
        if (!placeholders.isEmpty()) {
            addToolResultsMessage(placeholders);
        }
    }

    public void injectLongTermMemory(String instructions, String memories) {
        if (ltmInjected) return;
        var sections = new ArrayList<String>();
        if (instructions != null && !instructions.isEmpty()) {
            sections.add("# mewcodeMd\nCodebase and user instructions are shown below. Be sure to adhere to these instructions. IMPORTANT: These instructions OVERRIDE any default behavior and you MUST follow them exactly as written.\n\n" + instructions);
        }
        if (memories != null && !memories.isEmpty()) {
            sections.add("# autoMemory\n" + memories);
        }
        if (sections.isEmpty()) return;
        sections.add("# currentDate\nToday's date is " + java.time.LocalDate.now() + ".");
        String body = String.join("\n\n", sections);
        String wrapped = "<system-reminder>\nAs you answer the user's questions, you can use the following context:\n" +
            body +
            "\n\n      IMPORTANT: this context may or may not be relevant to your tasks. You should not respond to this context unless it is highly relevant to your task.\n</system-reminder>";
        history.add(0, new Message("user", wrapped));
        ltmInjected = true;
    }

    public void addSystemReminder(String content) {
        history.add(new Message("user", "<system-reminder>\n" + content + "\n</system-reminder>"));
    }

    public List<Message> getMessages() {
        return List.copyOf(history);
    }

    public List<Message> getMessagesMutable() {
        return history;
    }

    public int size() {
        return history.size();
    }

    public void truncateTo(int index) {
        if (index >= 0 && index < history.size()) {
            history.subList(index, history.size()).clear();
        }
    }

    public void setActiveSkill(String name, String body) {
        this.activeSkillName = name;
        this.activeSkillBody = body;
    }

    public String getActiveSkillName() {
        return activeSkillName;
    }

    public String getActiveSkillBody() {
        return activeSkillBody;
    }

    public String getActiveSkillContext() {
        if (activeSkillName == null || activeSkillBody == null || activeSkillBody.isEmpty()) {
            return "";
        }
        return "\n\n<skill>\n<name>" + activeSkillName + "</name>\n<context>\n" + activeSkillBody + "\n</context>\n</skill>";
    }

}
