// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.filehistory;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;

public class FileHistory {

    public record Backup(String backupPath, int version, Instant time) {}

    public record Snapshot(
            int messageIndex,
            String userText,
            Map<String, Backup> backups,
            Instant timestamp,
            /** Number of non-empty lines in the persisted session transcript at snapshot time. */
            int persistedLines,
            /** Git commit SHA of the checkpoint commit, or "" when git is unavailable. */
            String gitHash
    ) {}

    private static final int MAX_SNAPSHOTS = 100;
    private static final String SNAPSHOTS_FILE = "snapshots.json";

    private final String baseDir;
    private final String sessionId;
    private final Path sessionDir;
    private final Map<String, Integer> trackedFiles = new LinkedHashMap<>();
    private final Map<String, String> trackedBlob = new LinkedHashMap<>();
    /** Files that were created by a tool (did not exist before the agent wrote them). */
    private final Set<String> createdFiles = new HashSet<>();
    private final List<Snapshot> snapshots = new CopyOnWriteArrayList<>();
    private final ObjectMapper mapper = new ObjectMapper();

    public FileHistory(String baseDir, String sessionId) {
        this.baseDir = baseDir;
        this.sessionId = sessionId;
        this.sessionDir = Path.of(baseDir, ".mewcode", "file-history", sessionId);
        try {
            Files.createDirectories(sessionDir);
        } catch (IOException ignored) {}
        loadPersistence();
    }

    /** Path of the session transcript this FileHistory records against. */
    private Path sessionTranscript() {
        if (baseDir == null || sessionId == null) return null;
        return Path.of(baseDir, ".mewcode", "sessions", sessionId + ".jsonl");
    }

    /** Count non-empty lines of the session transcript (must match SessionManager.truncateSession). */
    private int persistedLineCount() {
        Path f = sessionTranscript();
        if (f == null || !Files.exists(f)) return 0;
        int count = 0;
        try (BufferedReader reader = Files.newBufferedReader(f)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) count++;
            }
        } catch (IOException ignored) {}
        return count;
    }

    private String backupName(String filePath, int version) {
        try {
            var md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(filePath.getBytes());
            return "%02x%02x%02x%02x%02x%02x%02x%02x@v%d".formatted(
                    hash[0], hash[1], hash[2], hash[3],
                    hash[4], hash[5], hash[6], hash[7], version);
        } catch (Exception e) {
            return "backup-" + filePath.hashCode() + "@v" + version;
        }
    }

    public synchronized void trackEdit(String path) {
        trackWrite(path, false);
    }

    /**
     * Record a file write/edit. {@code created} marks a path that was newly
     * created by the agent (did not exist before the write); such files are
     * eligible for deletion when rewinding past the checkpoint that created them.
     */
    public synchronized void trackWrite(String path, boolean created) {
        Path absPath;
        try {
            absPath = Path.of(path).toAbsolutePath();
        } catch (Exception e) {
            absPath = Path.of(path);
        }
        String key = absPath.toString();

        if (created) {
            createdFiles.add(key);
        }

        int ver = trackedFiles.getOrDefault(key, 0);
        int newVer = ver + 1;

        try {
            byte[] data = Files.readAllBytes(absPath);
            String bp = dedupBlob(data);
            if (bp != null) {
                trackedBlob.put(key, bp);
            }
        } catch (IOException ignored) {
            // File doesn't exist yet (new file) — no backup, but still track
        }

        trackedFiles.put(key, newVer);
        savePersistence();
    }

    /**
     * Content-addressed storage. The blob is named by the SHA-256 of its bytes,
     * so identical content is written exactly once and reused by every later
     * edit/snapshot that has the same bytes (dedup).
     */
    private String dedupBlob(byte[] data) {
        try {
            var md = MessageDigest.getInstance("SHA-256");
            String name = "blob-" + String.format("%064x", new java.math.BigInteger(1, md.digest(data)));
            Path p = sessionDir.resolve(name);
            if (!Files.exists(p)) {
                Files.write(p, data);
            }
            return p.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public synchronized void makeSnapshot(int msgIndex, String userText, String gitHash) {
        var backups = new LinkedHashMap<String, Backup>();        for (var entry : trackedFiles.entrySet()) {
            String path = entry.getKey();
            int ver = entry.getValue();
            String bp = trackedBlob.get(path);

            // If a blob isn't tracked yet (e.g. file created this turn without
            // a prior edit backup), snapshot the current state as a blob.
            if (bp == null || !Files.exists(Path.of(bp))) {
                try {
                    byte[] data = Files.readAllBytes(Path.of(path));
                    bp = dedupBlob(data);
                } catch (IOException ignored) {
                    bp = null;
                }
            }
            if (bp == null) {
                continue;
            }
            trackedBlob.put(path, bp);
            backups.put(path, new Backup(bp, ver, Instant.now()));
        }

        snapshots.add(new Snapshot(msgIndex, userText, backups, Instant.now(), persistedLineCount(), gitHash));

        while (snapshots.size() > MAX_SNAPSHOTS) {
            snapshots.removeFirst();
        }
        savePersistence();
        purgeOrphans();
    }

    public List<Snapshot> getSnapshots() {
        return List.copyOf(snapshots);
    }

    public boolean hasSnapshots() {
        return !snapshots.isEmpty();
    }

    public synchronized List<String> rewind(int snapshotIndex) {
        if (snapshotIndex < 0 || snapshotIndex >= snapshots.size()) {
            return List.of();
        }

        Snapshot target = snapshots.get(snapshotIndex);
        var changed = new ArrayList<String>();

        for (var entry : target.backups().entrySet()) {
            String filePath = entry.getKey();
            Backup backup = entry.getValue();

            try {
                byte[] backupData = Files.readAllBytes(Path.of(backup.backupPath()));
                byte[] currentData = new byte[0];
                try {
                    currentData = Files.readAllBytes(Path.of(filePath));
                } catch (IOException ignored) {}

                if (!Arrays.equals(currentData, backupData)) {
                    Files.createDirectories(Path.of(filePath).getParent());
                    Files.write(Path.of(filePath), backupData);
                    changed.add(filePath);
                }
            } catch (IOException e) {
                // Backup missing → file didn't exist at that point
                try {
                    if (Files.exists(Path.of(filePath))) {
                        Files.delete(Path.of(filePath));
                        changed.add(filePath);
                    }
                } catch (IOException ignored) {}
            }
        }

        // Delete agent-created files that were created AFTER the target
        // checkpoint (present in createdFiles but not in the target's backups).
        // Only created files are removed so pre-existing project files edited
        // later are never deleted.
        Set<String> targetKeys = target.backups().keySet();
        for (String path : new HashSet<>(createdFiles)) {
            if (targetKeys.contains(path)) {
                continue;
            }
            try {
                if (Files.exists(Path.of(path))) {
                    Files.delete(Path.of(path));
                    changed.add(path);
                }
            } catch (IOException ignored) {}
            createdFiles.remove(path);
        }

        // Truncate snapshots after target
        while (snapshots.size() > snapshotIndex + 1) {
            snapshots.removeLast();
        }

        // Reset tracked versions/state to the target checkpoint
        trackedFiles.clear();
        trackedBlob.clear();
        for (var entry : target.backups().entrySet()) {
            trackedFiles.put(entry.getKey(), entry.getValue().version());
            trackedBlob.put(entry.getKey(), entry.getValue().backupPath());
        }

        savePersistence();
        purgeOrphans();
        return changed;
    }

    /**
     * Delete on-disk blob files that no live snapshot references.
     *
     * <p>Safety: the snapshot list is in-memory for the current process, and it
     * is also persisted via {@link #savePersistence()}, so this only cleans up
     * blobs that no longer appear in the saved snapshots after each mutation.</p>
     */
    public synchronized void purgeOrphans() {
        try (var stream = Files.list(sessionDir)) {
            var live = collectLiveBlobs();
            for (Path p : (Iterable<Path>) stream::iterator) {
                String name = p.getFileName().toString();
                if (name.startsWith("blob-") && !live.contains(name)) {
                    Files.deleteIfExists(p);
                }
            }
        } catch (IOException ignored) {
            // best-effort cleanup
        }
    }

    private Set<String> collectLiveBlobs() {
        var live = new HashSet<String>();
        for (Snapshot s : snapshots) {
            for (Backup b : s.backups().values()) {
                try {
                    live.add(Path.of(b.backupPath()).getFileName().toString());
                } catch (Exception ignored) {
                    // skip malformed path
                }
            }
        }
        return live;
    }

    private void savePersistence() {
        try {
            var state = new PersistedState();
            state.snapshots = new ArrayList<>();
            for (Snapshot s : snapshots) {
                var sd = new SnapshotDto();
                sd.messageIndex = s.messageIndex();
                sd.userText = s.userText();
                sd.timestamp = s.timestamp() != null ? s.timestamp().toString() : null;
                sd.persistedLines = s.persistedLines();
                sd.gitHash = s.gitHash();
                sd.backups = new LinkedHashMap<>();
                for (var e : s.backups().entrySet()) {
                    Backup b = e.getValue();
                    var bd = new BackupDto();
                    bd.backupPath = b.backupPath();
                    bd.version = b.version();
                    bd.time = b.time() != null ? b.time().toString() : null;
                    sd.backups.put(e.getKey(), bd);
                }
                state.snapshots.add(sd);
            }
            state.trackedFiles = new LinkedHashMap<>(trackedFiles);
            state.trackedBlob = new LinkedHashMap<>(trackedBlob);
            state.createdFiles = new ArrayList<>(createdFiles);
            mapper.writerWithDefaultPrettyPrinter().writeValue(sessionDir.resolve(SNAPSHOTS_FILE).toFile(), state);
        } catch (IOException ignored) {}
    }

    private void loadPersistence() {
        Path file = sessionDir.resolve(SNAPSHOTS_FILE);
        if (!Files.exists(file)) return;
        try {
            PersistedState state = mapper.readValue(file.toFile(), PersistedState.class);
            snapshots.clear();
            trackedFiles.clear();
            trackedBlob.clear();
            createdFiles.clear();
            if (state.snapshots != null) {
                for (SnapshotDto sd : state.snapshots) {
                    if (sd == null) continue;
                    var backups = new LinkedHashMap<String, Backup>();
                    if (sd.backups != null) {
                        for (var e : sd.backups.entrySet()) {
                            BackupDto bd = e.getValue();
                            if (bd == null) continue;
                            backups.put(e.getKey(), new Backup(
                                    bd.backupPath, bd.version,
                                    bd.time != null ? Instant.parse(bd.time) : Instant.now()));
                        }
                    }
                    snapshots.add(new Snapshot(
                            sd.messageIndex, sd.userText, backups,
                            sd.timestamp != null ? Instant.parse(sd.timestamp) : Instant.now(),
                            sd.persistedLines, sd.gitHash == null ? "" : sd.gitHash));
                }
            }
            if (state.trackedFiles != null) {
                trackedFiles.putAll(state.trackedFiles);
            }
            if (state.trackedBlob != null) {
                trackedBlob.putAll(state.trackedBlob);
            }
            if (state.createdFiles != null) {
                createdFiles.addAll(state.createdFiles);
            }
        } catch (Exception ignored) {
            // Corrupt/unreadable file — start fresh
            snapshots.clear();
            trackedFiles.clear();
            trackedBlob.clear();
            createdFiles.clear();
        }
    }

    private static class BackupDto {
        public String backupPath;
        public int version;
        public String time;
    }

    private static class SnapshotDto {
        public int messageIndex;
        public String userText;
        public Map<String, BackupDto> backups;
        public String timestamp;
        public int persistedLines;
        public String gitHash;
    }

    private static class PersistedState {
        public List<SnapshotDto> snapshots;
        public Map<String, Integer> trackedFiles;
        public Map<String, String> trackedBlob;
        public List<String> createdFiles;
    }
}
