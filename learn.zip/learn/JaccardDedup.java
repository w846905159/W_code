package com.mewcode.learn;
import java.util.*;
public final class JaccardDedup {
    private JaccardDedup() {}
    public static double similarity(Instinct a, Instinct b) {
        Set<String> sa = KeywordExtractor.extract(a.trigger() + " " + a.action() + " " + a.domain());
        Set<String> sb = KeywordExtractor.extract(b.trigger() + " " + b.action() + " " + b.domain());
        if (sa.isEmpty() || sb.isEmpty()) return 0.0;
        Set<String> inter = new HashSet<>(sa); inter.retainAll(sb);
        Set<String> union = new HashSet<>(sa); union.addAll(sb);
        return (double) inter.size() / union.size();
    }

    public static List<List<Instinct>> cluster(List<Instinct> instincts, double threshold) {
        int n = instincts.size();
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) parent[i] = i;
        for (int i = 0; i < n; i++)
            for (int j = i + 1; j < n; j++)
                if (similarity(instincts.get(i), instincts.get(j)) >= threshold) union(parent, i, j);
        Map<Integer, List<Instinct>> map = new LinkedHashMap<>();
        for (int i = 0; i < n; i++) map.computeIfAbsent(find(parent, i), k -> new ArrayList<>()).add(instincts.get(i));
        return new ArrayList<>(map.values());
    }

    private static int find(int[] p, int x) { while (p[x] != x) { p[x] = p[p[x]]; x = p[x]; } return x; }
    private static void union(int[] p, int a, int b) { p[find(p, a)] = find(p, b); }
}
