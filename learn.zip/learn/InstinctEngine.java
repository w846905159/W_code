package com.mewcode.learn;

import java.util.*;

public class InstinctEngine {

    public static final double INITIAL_CONFIDENCE = 0.5;
    public static final double CONFIDENCE_STEP = 0.15;
    public static final double CONFIDENCE_CAP = 0.95;
    public static final double DEPRECATE_THRESHOLD = 0.55;
    public static final double INJECT_THRESHOLD = 0.65;
    private static final double HALF_LIFE_MS = 30L * 86_400_000L; // 30 days
    private static final long NEW_RULE_GRACE_MS = 24L * 3_600_000L; // 1 day

    private final InstinctRepository repository;
    private List<AiInstinctExtractor.Candidate> aiBatch = List.of();
    private int consecutiveAiFailures = 0;
    private static final int MAX_AI_FAILURES = 3;
    private final int aiBatchThreshold;      // N new observations
    private long lastAiWatermark;            // last observed position

    public record SeqHit(String seq, List<String> samples, int count, long lastSeen) {}

    public InstinctEngine(InstinctRepository repository) { this(repository, 50); }
    public InstinctEngine(InstinctRepository repository, int aiBatchThreshold) {
        this.repository = repository;
        this.aiBatchThreshold = aiBatchThreshold;
    }

    private AiInstinctExtractor.ExtractorFn aiExtractor;
    public void setAiExtractor(AiInstinctExtractor.ExtractorFn fn) { this.aiExtractor = fn; }
    public boolean isAiTripped() { return consecutiveAiFailures >= MAX_AI_FAILURES; }

    public static double confidence(int sightings) {
        double c = INITIAL_CONFIDENCE + CONFIDENCE_STEP * (sightings - 1);
        return Math.min(c, CONFIDENCE_CAP);
    }

    public static double decay(double confidence, long idleMs) {
        double steps = idleMs / HALF_LIFE_MS;
        return confidence * Math.pow(0.5, steps);
    }

    /** Detect n-gram tool-name sequences occurring >= minCount times in a window. */
    public List<SeqHit> detectFrequentSequences(List<Observation> observations, int minCount) {
        Map<String, Integer> seqCount = new LinkedHashMap<>();
        Map<String, List<String>> seqSamples = new LinkedHashMap<>();
        Map<String, Long> seqLastSeen = new LinkedHashMap<>();

        Map<String, List<Observation>> byTurn = new LinkedHashMap<>();
        for (var o : observations) byTurn.computeIfAbsent(o.sessionId() + "|" + o.turnId(), k -> new ArrayList<>()).add(o);

        for (var turn : byTurn.values()) {
            turn.sort(Comparator.comparingInt(Observation::order));
            for (int i = 0; i + 1 < turn.size(); i++) {
                String seq = turn.get(i).toolName() + "->" + turn.get(i + 1).toolName();
                seqCount.merge(seq, 1, Integer::sum);
                seqSamples.computeIfAbsent(seq, k -> new ArrayList<>())
                        .add(turn.get(i).toolName() + "(" + summarize(turn.get(i).toolArgs()) + ") -> "
                                + turn.get(i + 1).toolName() + "(" + summarize(turn.get(i + 1).toolArgs()) + ")");
                seqLastSeen.merge(seq, turn.get(i + 1).ts(), Math::max);
            }
        }

        List<SeqHit> hits = new ArrayList<>();
        for (var e : seqCount.entrySet()) {
            if (e.getValue() >= minCount) {
                hits.add(new SeqHit(e.getKey(), List.copyOf(seqSamples.get(e.getKey())), e.getValue(), seqLastSeen.get(e.getKey())));
            }
        }
        hits.sort((a, b) -> Integer.compare(b.count(), a.count()));
        return hits;
    }

    /** Statistical incremental pass: detect sequences, update confidence, dedup, aggregate, persist. */
    public String incrementalUpdate(ObservationStore store, int minCount, long now) {
        List<Observation> window = store.loadWindow(0L, Long.MAX_VALUE);
        List<SeqHit> hits = detectFrequentSequences(window, minCount);
        Map<String, Instinct> byId = new LinkedHashMap<>();
        for (var in : repository.loadInstincts()) byId.put(in.id(), in);
        for (var h : hits) {
            String id = h.seq();
            Instinct existing = byId.get(id);
            if (existing == null) {
                String sample = h.samples().isEmpty() ? h.seq() : h.samples().get(0);
                byId.put(id, new Instinct(id, classifyDomain(h.seq(), sample),
                        h.seq(), sample,
                        h.samples(), confidence(h.count()), h.lastSeen(), scope()));
            } else {
                List<String> ev = new ArrayList<>(existing.evidence());
                for (String s : h.samples()) if (!ev.contains(s)) ev.add(s);
                byId.put(id, new Instinct(id, existing.domain(), existing.trigger(), existing.action(),
                        ev, Math.max(existing.confidence(), confidence(h.count())), Math.max(existing.lastSeenMs(), h.lastSeen()), existing.scope()));
            }
        }
        List<Instinct> merged = mergeAiBatch(byId, now);
        merged = pruneDeprecated(merged, now);
        merged = dedupAndAggregate(merged, now);
        aiBatch = List.of();
        repository.saveInstincts(merged);
        repository.saveMarkdown(repository.renderMarkdown(merged, INJECT_THRESHOLD));
        return "learn: %d instinct(s), %d deprecated".formatted(merged.size(), 0);
    }

    /**
     * Install the latest AI-extracted candidates into state. A rule the LLM
     * independently re-asserts across batches (same trigger+action) is trusted
     * more: its confidence climbs by {@link #CONFIDENCE_STEP} each time until it
     * can cross the injection bar ({@link #INJECT_THRESHOLD}).
     */
    private List<Instinct> mergeAiBatch(Map<String, Instinct> byId, long now) {
        for (var c : aiBatch) {
            String key = c.trigger() + " :: " + c.action();
            Instinct ex = byId.get(key);
            if (ex == null) {
                byId.put(key, new Instinct(key, c.domain() != null ? c.domain() : "workflow",
                        c.trigger(), c.action(), List.of("ai"), INITIAL_CONFIDENCE, now, scope()));
            } else if (ex.evidence().contains("ai")) {
                double nc = Math.min(ex.confidence() + CONFIDENCE_STEP, CONFIDENCE_CAP);
                byId.put(key, new Instinct(key, ex.domain(), ex.trigger(), ex.action(),
                        ex.evidence(), nc, now, ex.scope()));
            }
        }
        return new ArrayList<>(byId.values());
    }

    private List<Instinct> dedupAndAggregate(List<Instinct> merged, long now) {
        // Family-aware dedup. Statistical tool-pair sequences (e.g. "Bash->Bash",
        // "Glob->ReadFile") must NOT be fuzzy-merged into one another, otherwise
        // richer observation sets collapse to a handful of rules (their action
        // samples share tokens like bash/git/test, so a low Jaccard threshold
        // over trigger+action+domain wrongly unions them). AI prose rules are
        // the ones worth fuzzy-merging (LLM rephrases the same behavior).
        List<Instinct> stat = new ArrayList<>();
        List<Instinct> ai = new ArrayList<>();
        for (var i : merged) (isToolPairTrigger(i.trigger()) ? stat : ai).add(i);
        List<Instinct> out = new ArrayList<>();
        out.addAll(aggregate(stat, 1.0)); // only identical tool-pair triggers merge
        out.addAll(aggregate(ai, 0.5));   // near-dup AI prose merges
        return out;
    }

    private static boolean isToolPairTrigger(String trigger) {
        return trigger != null && trigger.matches("[A-Za-z]+->[A-Za-z]+");
    }

    private List<Instinct> aggregate(List<Instinct> list, double threshold) {
        Map<String, Instinct> out = new LinkedHashMap<>();
        for (var cluster : JaccardDedup.cluster(list, threshold)) {
            Instinct best = cluster.stream().max(Comparator.comparingDouble(Instinct::confidence)).orElse(cluster.get(0));
            List<String> ev = new ArrayList<>();
            for (var c : cluster) for (String e : c.evidence()) if (!ev.contains(e)) ev.add(e);
            out.put(best.id(), new Instinct(best.id(), best.domain(), best.trigger(), best.action(), ev, best.confidence(), best.lastSeenMs(), best.scope()));
        }
        return new ArrayList<>(out.values());
    }

    private List<Instinct> pruneDeprecated(List<Instinct> list, long now) {
        List<Instinct> out = new ArrayList<>();
        for (var i : list) {
            long idle = Math.max(0, now - i.lastSeenMs());
            double c = decay(i.confidence(), idle);
            // Keep freshly-created rules (idle ~ 0) even if their initial
            // confidence is below the deprecation bar; only decay over time
            // should retire a rule that never gets reinforced.
            if (c >= DEPRECATE_THRESHOLD || idle < NEW_RULE_GRACE_MS) out.add(i);
        }
        return out;
    }

    /** AI semantic batch: runs when enough new observations since last AI pass. */
    public void runSemanticBatch(ObservationStore store, long now) {
        if (aiExtractor == null || isAiTripped()) return;
        List<Observation> all = store.loadAll();
        if (all.size() - lastAiWatermark < aiBatchThreshold) return;
        try {
            String summary = buildSummary(all);
            List<AiInstinctExtractor.Candidate> cands = aiExtractor.extract(summary);
            this.aiBatch = cands;
            consecutiveAiFailures = 0;
            lastAiWatermark = all.size();
            incrementalUpdate(store, 2, now);
        } catch (Exception e) {
            consecutiveAiFailures++;
        }
    }

    private static String buildSummary(List<Observation> all) {
        Map<String, List<Observation>> byTurn = new LinkedHashMap<>();
        for (var o : all) {
            byTurn.computeIfAbsent(o.sessionId() + "|" + o.turnId(), k -> new ArrayList<>()).add(o);
        }
        var sb = new StringBuilder();
        for (var turn : byTurn.values()) {
            turn.sort(Comparator.comparingInt(Observation::order));
            for (int i = 0; i + 1 < turn.size(); i++) {
                sb.append(turn.get(i).toolName()).append('(').append(summarize(turn.get(i).toolArgs()))
                  .append(") -> ").append(turn.get(i + 1).toolName()).append('(')
                  .append(summarize(turn.get(i + 1).toolArgs())).append(")\n");
            }
        }
        String s = sb.toString();
        return s.length() > 8000 ? s.substring(0, 8000) : s;
    }

    private static String classifyDomain(String seq, String sample) {
        String s = (seq + " " + sample).toLowerCase();
        if (s.contains("bash->bash")) return "workflow";
        if (s.contains("test") || s.contains("npm") || s.contains("mvn") || s.contains("gradle")) return "testing";
        if (s.contains("git")) return "git";
        if (s.contains("readfile") || s.contains("editfile") || s.contains("writefile")) return "filesystem";
        return "workflow";
    }

    private static String scope() { return ""; }

    private static String summarize(Map<String, Object> args) {
        if (args == null) return "?";
        Object v = args.get("command"); if (v != null) return String.valueOf(v);
        Object p = args.get("file_path"); if (p != null) return String.valueOf(p);
        return "…";
    }
}
