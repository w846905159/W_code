package com.mewcode.learn;
import java.util.*;
public final class KeywordExtractor {
    private static final Set<String> STOP = Set.of(
            "this","that","with","from","into","have","has","been","will","would","then","than",
            "just","when","what","which","before","after","always","never","should","must","also");
    private KeywordExtractor() {}
    public static Set<String> extract(String text) {
        Set<String> out = new HashSet<>();
        if (text == null) return out;
        for (String tok : text.toLowerCase(Locale.ROOT).split("[^a-z0-9]+")) {
            if (tok.length() >= 3 && !STOP.contains(tok)) out.add(tok);
        }
        return out;
    }
}
