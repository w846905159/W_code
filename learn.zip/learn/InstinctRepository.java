package com.mewcode.learn;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

public class InstinctRepository {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    public static final String RULES_DIR = ".mewcode/rules";
    public static final String STATE_FILE = "instincts.json";
    public static final String RENDER_FILE = "auto-evolved.md";

    private final Path rulesDir;

    public InstinctRepository(Path workDir) {
        this.rulesDir = workDir.resolve(RULES_DIR);
    }

    public Path rulesDir() { return rulesDir; }

    public static Path userRulesDir() {
        return Path.of(System.getProperty("user.home")).resolve(RULES_DIR);
    }

    private Path stateFile() { return rulesDir.resolve(STATE_FILE); }
    private Path renderFile() { return rulesDir.resolve(RENDER_FILE); }

    public List<Instinct> loadInstincts() {
        try {
            if (!Files.exists(stateFile())) return List.of();
            byte[] data = Files.readAllBytes(stateFile());
            return MAPPER.readValue(data, new TypeReference<List<Instinct>>() {});
        } catch (IOException e) { return List.of(); }
    }

    public void saveInstincts(List<Instinct> list) {
        try {
            Files.createDirectories(rulesDir);
            String json = MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(list);
            atomicWrite(stateFile(), json);
        } catch (IOException ignored) {}
    }

    /**
     * Add (or replace) a user-authored rule. Manual rules carry high
     * confidence ({@code >} injection bar) so they are injected directly, and
     * are tagged with evidence {@code "manual"} to distinguish them from
     * statistically-learned and AI-extracted rules.
     *
     * @param domain  e.g. "workflow" / "git" / "testing"
     * @param trigger the condition ("when ...")
     * @param action  the behavior ("then ...")
     * @param scope   e.g. "user" (preference) or "project"
     * @return the persisted rule id
     */
    public String upsertManualRule(String domain, String trigger, String action, String scope) {
        long now = System.currentTimeMillis();
        String id = trigger.trim() + " :: " + action.trim();
        Instinct rule = new Instinct(id,
                domain == null || domain.isBlank() ? "workflow" : domain.trim(),
                trigger.trim(), action.trim(), List.of("manual"),
                InstinctEngine.CONFIDENCE_CAP, now,
                scope == null || scope.isBlank() ? "user" : scope.trim());

        List<Instinct> list = new ArrayList<>(loadInstincts());
        list.removeIf(i -> i.id().equals(id));
        list.add(rule);
        saveInstincts(list);
        saveMarkdown(renderMarkdown(list, InstinctEngine.INJECT_THRESHOLD));
        return id;
    }

    public String renderMarkdown(List<Instinct> instincts, double minConfidence) {
        var byDomain = new TreeMap<String, List<Instinct>>();
        for (var i : instincts) {
            if (i.confidence() < minConfidence) continue;
            byDomain.computeIfAbsent(i.domain(), k -> new ArrayList<>()).add(i);
        }
        if (byDomain.isEmpty()) return "";
        var sb = new StringBuilder("# Auto-Evolved Instincts\n\n");
        for (var e : byDomain.entrySet()) {
            sb.append("## ").append(e.getKey()).append("\n\n");
            for (var i : e.getValue()) {
                sb.append("- **Trigger:** ").append(i.trigger()).append("\n");
                sb.append("  **Action:** ").append(i.action()).append("\n");
                sb.append("  **Confidence:** ").append(String.format(Locale.ROOT, "%.2f", i.confidence())).append("\n");
                if (!i.evidence().isEmpty())
                    sb.append("  **Evidence:** ").append(String.join(", ", i.evidence())).append("\n");
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    public void saveMarkdown(String content) {
        try {
            Files.createDirectories(rulesDir);
            atomicWrite(renderFile(), content);
        } catch (IOException ignored) {}
    }

    public String loadMarkdown() {
        try {
            if (!Files.exists(renderFile())) return "";
            return Files.readString(renderFile());
        } catch (IOException e) { return ""; }
    }

    private static void atomicWrite(Path file, String content) throws IOException {
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        Files.writeString(tmp, content);
        try {
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (java.nio.file.AtomicMoveNotSupportedException e) {
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
