package com.mewcode.learn;

import com.mewcode.conversation.ConversationManager;
import com.mewcode.llm.LlmClient;
import com.mewcode.llm.StreamEvent;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AiInstinctExtractor {

    public record Candidate(String trigger, String action, String domain) {}

    public interface ExtractorFn { List<Candidate> extract(String summary) throws Exception; }

    private static final String SYSTEM_PROMPT =
            "You analyze an AI coding assistant's tool-usage observations to derive reusable behavior rules. " +
            "Output numbered rules, each with a single-line 'Trigger:' and 'Action:'. " +
            "Capture honest, reusable habits (e.g. run tests before commit). Output nothing else.";

    private static final Pattern TRIGGER = Pattern.compile("(?i)\\bTrigger\\s*:\\s*(.+)");
    private static final Pattern ACTION = Pattern.compile("(?i)\\bAction\\s*:\\s*(.+)");

    /** Default extractor backed by the configured LlmClient (side-query, non-stream). */
    public static ExtractorFn using(LlmClient client) {
        return summary -> {
            ConversationManager conv = new ConversationManager();
            conv.addUserMessage(SYSTEM_PROMPT + "\n\nObservations:\n" + summary);
            BlockingQueue<StreamEvent> events = client.stream(conv, null);
            var sb = new StringBuilder();
            while (true) {
                StreamEvent ev;
                try { ev = events.take(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                if (ev instanceof StreamEvent.TextDelta td) sb.append(td.text());
                // Some gateways route to a reasoning model that streams the final,
                // formatted answer inside reasoning_content (never a separate
                // content field). Collect that too so we still extract rules.
                else if (ev instanceof StreamEvent.ThinkingDelta th) sb.append(th.text());
                else if (ev instanceof StreamEvent.StreamEnd || ev instanceof StreamEvent.Error) break;
            }
            return parseCandidates(sb.toString());
        };
    }

    static List<Candidate> parseCandidates(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        List<Candidate> out = new ArrayList<>();
        String[] blocks = raw.split("(?i)(?=\\d+\\.\\s)");
        for (String block : blocks) {
            Matcher tm = TRIGGER.matcher(block);
            Matcher am = ACTION.matcher(block);
            if (tm.find() && am.find()) {
                out.add(new Candidate(tm.group(1).trim(), am.group(1).trim(), "workflow"));
            }
        }
        return out;
    }
}
