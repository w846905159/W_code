package com.mewcode.learn;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

public class ObservationStore implements ToolObserver {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final DateTimeFormatter MONTH =
            DateTimeFormatter.ofPattern("yyyyMM").withZone(ZoneOffset.UTC);

    public static final String OBSERVATIONS_DIR = ".mewcode/observations";
    public static final long DEFAULT_ARCHIVE_BYTES = 5L * 1024 * 1024;
    public static final int DEFAULT_ARCHIVE_ROWS = 8000;

    private final Path baseDir;
    private final long archiveBytes;
    private final int archiveRows;
    private final AtomicInteger rowsInCurrentFile = new AtomicInteger(0);

    public ObservationStore(Path workDir) {
        this(workDir, DEFAULT_ARCHIVE_BYTES, DEFAULT_ARCHIVE_ROWS);
    }

    public ObservationStore(Path workDir, long archiveBytes, int archiveRows) {
        this.baseDir = workDir.resolve(OBSERVATIONS_DIR);
        this.archiveBytes = archiveBytes;
        this.archiveRows = archiveRows;
    }

    Path currentFile(long ts) {
        return baseDir.resolve("observations_" + MONTH.format(Instant.ofEpochMilli(ts)) + ".jsonl");
    }

    Path archiveDir() { return baseDir.resolve("archive"); }

    @Override
    public void observed(Observation o) { record(o); }

    public void record(Observation o) {
        try {
            Path file = currentFile(o.ts());
            Files.createDirectories(file.getParent());
            Files.writeString(file, MAPPER.writeValueAsString(o) + "\n",
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            afterAppend(file);
        } catch (IOException ignored) {}
    }

    private void afterAppend(Path file) {
        if (rowsInCurrentFile.incrementAndGet() >= archiveRows || sizeOf(file) >= archiveBytes) {
            rotate(file);
            rowsInCurrentFile.set(0);
        }
    }

    private long sizeOf(Path file) {
        try { return Files.size(file); } catch (IOException e) { return 0; }
    }

    public void rotate(Path file) {
        try {
            Files.createDirectories(archiveDir());
            Path target = archiveDir().resolve(file.getFileName().toString() + "_" + System.currentTimeMillis());
            Files.move(file, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {}
    }

    public List<Observation> loadAll() {
        return loadWindow(0L, Long.MAX_VALUE);
    }

    public List<Observation> loadWindow(long fromTs, long toTs) {
        List<Observation> out = new ArrayList<>();
        for (Path file : listObservationFiles()) {
            for (String line : readLines(file)) {
                if (line.isBlank()) continue;
                try {
                    Observation o = MAPPER.readValue(line, Observation.class);
                    if (o.ts() >= fromTs && o.ts() <= toTs) out.add(o);
                } catch (IOException ignored) {}
            }
        }
        out.sort(Comparator.comparingLong(Observation::ts).thenComparingInt(Observation::order));
        return out;
    }

    private List<Path> listObservationFiles() {
        if (!Files.isDirectory(baseDir)) return List.of();
        try (Stream<Path> s = Files.list(baseDir)) {
            return s.filter(p -> {
                        String name = p.getFileName().toString();
                        return name.startsWith("observations_") && name.endsWith(".jsonl");
                    })
                    .sorted().toList();
        } catch (IOException e) { return List.of(); }
    }

    private List<String> readLines(Path file) {
        try { return Files.readAllLines(file); } catch (IOException e) { return List.of(); }
    }

    public int prune(int retentionDays) {
        long cutoff = System.currentTimeMillis() - retentionDays * 86_400_000L;
        int removed = 0;
        try { Files.createDirectories(archiveDir()); } catch (IOException ignored) {}
        for (Path file : listObservationFiles()) {
            long last = lastTsInFile(file);
            if (last > 0 && last < cutoff && !Files.exists(archiveDir().resolve(file.getFileName().toString()))) {
                try { Files.move(file, archiveDir().resolve(file.getFileName().toString()), StandardCopyOption.REPLACE_EXISTING); removed++; }
                catch (IOException ignored) {}
            }
        }
        return removed;
    }

    private long lastTsInFile(Path file) {
        long max = 0;
        for (String line : readLines(file)) {
            if (line.isBlank()) continue;
            try { max = Math.max(max, MAPPER.readValue(line, Observation.class).ts()); } catch (IOException ignored) {}
        }
        return max;
    }

    public void flush() { /* appends are immediate writes; no-op hook */ }
}
