package com.mewcode.learn;

import java.nio.file.Path;
import java.util.*;

public final class InstinctInjector {
    private InstinctInjector() {}

    /** Merge user + project MD renders; project render overrides when present. */
    public static String buildRulesContent(Path userRulesDir, Path projectRulesDir, double minConfidence) {
        String userMd = readMarkdown(userRulesDir);
        String projMd = readMarkdown(projectRulesDir);
        // Confidence filtering already applied at render time (renderMarkdown).
        if (!projMd.isBlank()) return projMd;
        return userMd;
    }

    public static String withHeading(String body) {
        if (body == null || body.isBlank()) return "";
        return "# Auto-Evolved Instincts\n" + body;
    }

    private static String readMarkdown(Path rulesDir) {
        var repo = new InstinctRepository(rulesDir);
        String md = repo.loadMarkdown();
        if (md != null && !md.isBlank()) return md;
        // fallback: re-render from state
        return repo.renderMarkdown(repo.loadInstincts(), InstinctEngine.INJECT_THRESHOLD);
    }
}
