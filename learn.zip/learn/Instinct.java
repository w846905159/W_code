package com.mewcode.learn;
import java.util.List;
public record Instinct(
        String id, String domain, String trigger, String action,
        List<String> evidence, double confidence, long lastSeenMs, String scope) {}
