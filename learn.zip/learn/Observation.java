package com.mewcode.learn;
import java.util.Map;
public record Observation(
        String sessionId, String turnId, int order,
        String toolName, Map<String, Object> toolArgs,
        boolean success, long latencyMs, long ts) {}
