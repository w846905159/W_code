package com.mewcode.learn;
@FunctionalInterface
public interface ToolObserver {
    void observed(Observation observation);
}
