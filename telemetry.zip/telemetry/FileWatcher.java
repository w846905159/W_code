package com.mewcode.telemetry;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Watches the project directory for external file edits (any editor: UI,
 * IDE, plain text editor) and attributes them to the USER using the shared
 * snapshot in {@link FileStateRegistry}.
 *
 * <p>Agent's own writes already emit AGENT events and update the snapshot, so
 * the watcher skips any change that exactly matches the snapshot to avoid
 * double counting.</p>
 */
public final class FileWatcher {

    private static final Set<String> CODE_EXTS = Set.of(
            ".java", ".kt", ".kts", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs",
            ".py", ".go", ".rs", ".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".hh",
            ".cs", ".php", ".rb", ".swift", ".scala", ".sql", ".css", ".scss",
            ".less", ".html", ".htm", ".json", ".xml", ".yaml", ".yml", ".toml",
            ".md", ".txt", ".csv", ".properties", ".ini", ".cfg", ".conf",
            ".ets", ".etsx", ".sh", ".ps1", ".vue", ".svelte", ".proto");

    private static final Set<String> IGNORED_DIRS = Set.of(
            "target", "build", "node_modules", ".git", ".gradle", ".idea",
            ".mewcode", ".settings", "out", "dist");

    private static final long DEBOUNCE_MS = 500;

    private final Path root;
    private final WatchService watchService;
    private final Set<String> registeredDirs = ConcurrentHashMap.newKeySet();
    private final Map<Path, Long> dirty = new ConcurrentHashMap<>();
    private final Set<String> preExisting = new HashSet<>();
    private volatile boolean running = true;
    private Thread thread;

    private FileWatcher(Path root) throws IOException {
        this.root = root.toAbsolutePath().normalize();
        this.watchService = FileSystems.getDefault().newWatchService();
        registerTree(root);
    }

    public static FileWatcher start(String workDir) {
        Path root = Path.of(workDir);
        if (!Files.isDirectory(root)) return null;
        try {
            FileWatcher watcher = new FileWatcher(root);
            watcher.collectPreExisting();
            watcher.thread = Thread.ofPlatform().name("file-watcher").daemon(true).start(watcher::loop);
            Runtime.getRuntime().addShutdownHook(new Thread(watcher::stop));
            return watcher;
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Records the paths of all watched files that already exist when the
     * watcher starts. Files seen here are treated as pre-existing (their
     * initial content is a baseline, not a USER contribution). Any file that
     * appears later without a snapshot (and isn't agent-written) counts as
     * user-created content.
     */
    private void collectPreExisting() {
        try (var stream = Files.walk(root)) {
            stream.filter(Files::isRegularFile)
                    .filter(FileWatcher::isCodeFile)
                    .filter(p -> !isIgnored(p))
                    .forEach(p -> preExisting.add(norm(p)));
        } catch (IOException ignored) {
        }
    }

    private static String norm(Path p) {
        return p.toAbsolutePath().normalize().toString();
    }

    public void stop() {
        running = false;
        try { watchService.close(); } catch (IOException ignored) {}
    }

    private void loop() {
        try {
            while (running) {
                WatchKey key = watchService.poll(DEBOUNCE_MS, TimeUnit.MILLISECONDS);
                if (key == null) {
                    processDirty();
                    continue;
                }
                Path dir = (Path) key.watchable();
                for (WatchEvent<?> ev : key.pollEvents()) {
                    if (ev.kind() == StandardWatchEventKinds.OVERFLOW) continue;
                    Path child = dir.resolve((Path) ev.context());
                    if (Files.isDirectory(child)) {
                        registerTree(child);
                        continue;
                    }
                    if (isCodeFile(child) && !isIgnored(child)) {
                        dirty.put(child, System.currentTimeMillis());
                    }
                }
                key.reset();
                processDirty();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void processDirty() {
        long now = System.currentTimeMillis();
        for (var it = dirty.entrySet().iterator(); it.hasNext(); ) {
            var entry = it.next();
            if (now - entry.getValue() < DEBOUNCE_MS) continue;
            it.remove();
            process(entry.getKey());
        }
    }

    private void process(Path path) {
        String current;
        try {
            current = Files.readString(path);
        } catch (IOException e) {
            return;
        }
        FileStateRegistry registry = FileStateRegistry.get();
        if (registry == null) return;
        String norm = norm(path);
        if (!registry.hasSnapshot(norm)) {
            // Not agent-written (agent writes set the snapshot synchronously).
            // If it existed at startup it's pre-existing baseline; otherwise it was
            // created externally during this session, so its whole content is USER.
            if (!preExisting.contains(norm)) {
                TelemetryEvent.FileDiff d = FileWriteService.diff("", current);
                TelemetryEmitter.emit(new TelemetryEvent.FileChangeEvent(
                        "file_change", TelemetryEmitter.getSessionId(), System.currentTimeMillis(),
                        TelemetryEmitter.getModelName(),
                        path.toString(), extOf(path.toString()),
                        d.addedLines(), 0, TelemetryEvent.EditSource.USER));
            }
            registry.set(norm, current);
            return;
        }
        String before = registry.snapshot(norm);
        if (before != null && before.equals(current)) return;
        TelemetryEvent.FileDiff d = FileWriteService.diff(before, current);
        TelemetryEmitter.emit(new TelemetryEvent.FileChangeEvent(
                "file_change", TelemetryEmitter.getSessionId(), System.currentTimeMillis(),
                TelemetryEmitter.getModelName(),
                path.toString(), extOf(path.toString()),
                d.addedLines(), d.removedLines(), TelemetryEvent.EditSource.USER));
        registry.set(norm, current);
    }

    private void registerTree(Path start) {
        try (var stream = Files.walk(start)) {
            stream.filter(Files::isDirectory).forEach(this::register);
        } catch (IOException ignored) {
        }
    }

    private void register(Path dir) {
        String norm = dir.toAbsolutePath().normalize().toString();
        if (isIgnored(dir) || !registeredDirs.add(norm)) return;
        try {
            dir.register(watchService,
                    StandardWatchEventKinds.ENTRY_CREATE,
                    StandardWatchEventKinds.ENTRY_MODIFY);
        } catch (IOException ignored) {
        }
    }

    private boolean isIgnored(Path p) {
        for (Path part : p) {
            if (IGNORED_DIRS.contains(part.toString())) return true;
        }
        return false;
    }

    private static boolean isCodeFile(Path p) {
        String name = p.getFileName().toString();
        int idx = name.lastIndexOf('.');
        if (idx < 0) return false;
        return CODE_EXTS.contains(name.substring(idx));
    }

    private static String extOf(String path) {
        int idx = path.lastIndexOf('.');
        return idx >= 0 ? path.substring(idx) : "";
    }
}
