package com.mewcode.telemetry;

import java.nio.file.Path;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class TelemetryEmitter {

    private static TelemetryEmitter INSTANCE;

    private final TelemetryStore store;
    private final BlockingQueue<TelemetryEvent> queue = new LinkedBlockingQueue<>(1024);
    private volatile boolean running = true;

    private String sessionId = "";
    private String modelName = "";

    TelemetryEmitter(Path baseDir) {
        this.store = new TelemetryStore(baseDir);
        Thread.ofVirtual().name("telemetry-writer").start(() -> {
            while (running) {
                try {
                    TelemetryEvent event = queue.poll(1, TimeUnit.SECONDS);
                    if (event != null) {
                        store.append(event);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            drainRemaining();
        });
    }

    private void drainRemaining() {
        var list = new java.util.ArrayList<TelemetryEvent>();
        queue.drainTo(list);
        for (var e : list) {
            store.append(e);
        }
    }

    public static synchronized void init(String workDir, String modelName, String sessionId) {
        if (INSTANCE != null) {
            INSTANCE.shutdown();
        }
        Path baseDir = Path.of(workDir, ".mewcode", "telemetry");
        INSTANCE = new TelemetryEmitter(baseDir);
        INSTANCE.modelName = modelName != null ? modelName : "";
        INSTANCE.sessionId = sessionId != null ? sessionId : "";
    }

    public static void emit(TelemetryEvent event) {
        if (INSTANCE == null) return;
        INSTANCE.queue.offer(event);
    }

    public static String getModelName() {
        return INSTANCE != null ? INSTANCE.modelName : "";
    }

    public static String getSessionId() {
        return INSTANCE != null ? INSTANCE.sessionId : "";
    }

    public static TelemetryStore getStore() {
        return INSTANCE != null ? INSTANCE.store : null;
    }

    public void shutdown() {
        running = false;
    }

    public static synchronized void shutdownInstance() {
        if (INSTANCE != null) {
            INSTANCE.shutdown();
            INSTANCE = null;
        }
    }
}
