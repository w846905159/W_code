package com.mewcode.telemetry;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Map;

/**
 * 异步落盘的遥测管道，采用 WAL（write-ahead log）实现 at-least-once：
 * <ul>
 *   <li>emit() 先在同步路径把事件（含自增 seq）追加到磁盘 events.wal；</li>
 *   <li>writer 线程周期把 WAL 合并进按日的 events_*.jsonl，随后 fsync 并截断 WAL；</li>
 *   <li>崩溃（kill -9/断电）只丢“上次 fsync 到崩溃”的窗口（默认 ≤500ms），重启时从 WAL 重放。</li>
 * </ul>
 */
public class TelemetryEmitter {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    /** 空闲轮询间隔，也是断电丢失窗口的上限。 */
    private static final long WRITE_INTERVAL_MS = 500L;

    private static TelemetryEmitter INSTANCE;

    private final Object lock = new Object();
    private final TelemetryStore store;
    private final Path walPath;
    private FileChannel walChannel;
    private long nextSeq = 1;
    private volatile boolean running = true;
    private Thread writerThread;

    private String sessionId = "";
    private String modelName = "";

    TelemetryEmitter(Path baseDir) {
        this.store = new TelemetryStore(baseDir);
        this.walPath = baseDir.resolve("events.wal");
        try {
            Files.createDirectories(baseDir);
            // 崩溃恢复：把上次异常终止遗留的 WAL 合并进按日文件，再清空。
            try (FileChannel recovery = FileChannel.open(walPath,
                    StandardOpenOption.CREATE, StandardOpenOption.READ, StandardOpenOption.WRITE)) {
                mergeWal(recovery);
                recovery.force(false);
            }
            this.walChannel = FileChannel.open(walPath,
                    StandardOpenOption.CREATE, StandardOpenOption.READ, StandardOpenOption.WRITE);
            this.nextSeq = store.maxSeq() + 1;
        } catch (IOException e) {
            System.err.println("telemetry init failed: " + e.getMessage());
            this.running = false;
            this.walChannel = null;
        }
        this.writerThread = Thread.ofVirtual().name("telemetry-writer").start(this::runWriter);
    }

    private void runWriter() {
        try {
            while (true) {
                synchronized (lock) {
                    try {
                        lock.wait(WRITE_INTERVAL_MS);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                    boolean idle;
                    try {
                        idle = !running && walEmpty();
                    } catch (IOException e) {
                        idle = true;
                    }
                    if (idle) break;
                    try {
                        mergeWal(walChannel);
                    } catch (IOException e) {
                        System.err.println("telemetry merge failed (will retry): " + e.getMessage());
                    }
                    boolean done;
                    try {
                        done = !running && walEmpty();
                    } catch (IOException e) {
                        done = false;
                    }
                    if (done) break;
                }
            }
        } finally {
            synchronized (lock) {
                try {
                    mergeWal(walChannel);
                } catch (IOException ignored) {
                }
                closeWal();
                walChannel = null;
                lock.notifyAll();
            }
        }
    }

    private boolean walEmpty() throws IOException {
        return walChannel == null || walChannel.size() == 0;
    }

    /**
     * 把 WAL 中的行合并进按日 jsonl（fsync 后清空 WAL）。调用方需持有 lock。
     * 合并/落盘失败时不清空 WAL，保证可重试或下次启动重放。
     */
    private boolean mergeWal(FileChannel wal) throws IOException {
        if (wal == null) return false;
        long size = wal.size();
        if (size == 0) return false;
        wal.position(0);
        ByteBuffer buf = ByteBuffer.allocate((int) size);
        while (buf.hasRemaining()) {
            if (wal.read(buf) < 0) break;
        }
        buf.flip();
        String content = StandardCharsets.UTF_8.decode(buf).toString();
        for (String line : content.split("\n")) {
            if (line.isBlank()) continue;
            Map<String, Object> row;
            try {
                row = MAPPER.readValue(line, Map.class);
            } catch (IOException parseErr) {
                // 残缺/损坏行：无法搬运，最终随 WAL 截断丢弃（与 loadAll 的逐行容错一致）。
                continue;
            }
            store.appendRow(row);
        }
        store.forcePending();
        wal.position(0);
        wal.truncate(0);
        wal.force(false);
        return true;
    }

    private void closeWal() {
        try {
            if (walChannel != null) {
                walChannel.force(false);
                walChannel.close();
            }
        } catch (IOException ignored) {
        }
    }

    public static synchronized void init(String workDir, String modelName, String sessionId) {
        if (INSTANCE != null) {
            INSTANCE.shutdown();
        }
        Path baseDir = Path.of(workDir, ".mewcode", "telemetry");
        INSTANCE = new TelemetryEmitter(baseDir);
        INSTANCE.modelName = modelName != null ? modelName : "";
        INSTANCE.sessionId = sessionId != null ? sessionId : "";
    }

    /**
     * 把事件先同步写入 WAL（持久化点提前到 emit），队列满/丢失语义不再存在。
     *
     * @return true 表示已进入 WAL
     */
    public static boolean emit(TelemetryEvent event) {
        if (event == null) return false;
        TelemetryEmitter e = INSTANCE;
        return e != null && e.write(event);
    }

    private boolean write(TelemetryEvent event) {
        synchronized (lock) {
            if (!running || walChannel == null) return false;
            long oldSize = 0;
            try {
                oldSize = walChannel.size();
                long seq = nextSeq++;
                String line = TelemetryStore.serializeEvent(event, seq);
                ByteBuffer buf = StandardCharsets.UTF_8.encode(line + "\n");
                while (buf.hasRemaining()) {
                    walChannel.write(buf);
                }
                lock.notifyAll();
                return true;
            } catch (Exception e) {
                try {
                    if (walChannel != null && walChannel.size() != oldSize) {
                        walChannel.truncate(oldSize);
                    }
                } catch (IOException ignored) {
                }
                System.err.println("telemetry emit failed: " + e.getMessage());
                return false;
            }
        }
    }

    /**
     * 停止并确认落盘：阻塞直到 writer 完成最后一次合并/fsync（同步 join）。
     * 返回后所有已 emit 的事件要么进了 jsonl、要么仍在 WAL 中可被下次启动恢复。
     */
    public void shutdown() {
        Thread t;
        synchronized (lock) {
            if (!running) return;
            running = false;
            t = writerThread;
            lock.notifyAll();
        }
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static String getModelName() {
        return INSTANCE != null ? INSTANCE.modelName : "";
    }

    public static String getSessionId() {
        return INSTANCE != null ? INSTANCE.sessionId : "";
    }

    public static TelemetryStore getStore() {
        return INSTANCE != null ? INSTANCE.store : null;
    }

    public static synchronized void shutdownInstance() {
        if (INSTANCE != null) {
            INSTANCE.shutdown();
            INSTANCE = null;
        }
    }
}
