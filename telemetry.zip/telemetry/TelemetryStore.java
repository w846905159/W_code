package com.mewcode.telemetry;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TelemetryStore {

    static final String SEQ_FIELD = "seq";

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");

    private final Path baseDir;
    private final Set<Path> dirtyFiles = new HashSet<>();

    public TelemetryStore(Path baseDir) {
        this.baseDir = baseDir;
    }

    /** 把事件序列化成一条带 seq 的 jsonl 行（WAL 写入用）。 */
    static String serializeEvent(TelemetryEvent event, long seq) throws JsonProcessingException {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(SEQ_FIELD, seq);
        map.put("eventType", event.eventType());
        map.put("sessionId", event.sessionId());
        map.put("ts", event.timestamp());
        map.put("model", event.model());
        toMap(event, map);
        return MAPPER.writeValueAsString(map);
    }

    /**
     * 把一行事件追加到按事件 ts 归属的日期文件，并登记为待 fsync。
     * 写失败抛 IOException，调用方应保留 WAL 以便重启后重放。
     */
    public void appendRow(Map<String, Object> row) throws IOException {
        String json = MAPPER.writeValueAsString(row);
        long ts = row.get("ts") instanceof Number n ? n.longValue() : System.currentTimeMillis();
        Files.createDirectories(baseDir);
        Path file = dateFile(ts);
        try {
            Files.writeString(file, json + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            synchronized (dirtyFiles) {
                dirtyFiles.add(file);
            }
        } catch (IOException e) {
            throw new IOException("telemetry append failed: " + file, e);
        }
    }

    /** fsync 所有新写入的日期文件；失败的保留在集合中下次重试（保证 at-least-once）。 */
    public void forcePending() throws IOException {
        List<Path> pending;
        synchronized (dirtyFiles) {
            pending = new ArrayList<>(dirtyFiles);
        }
        IOException last = null;
        for (Path p : pending) {
            if (!Files.exists(p)) {
                synchronized (dirtyFiles) {
                    dirtyFiles.remove(p);
                }
                continue;
            }
            try (FileChannel ch = FileChannel.open(p, StandardOpenOption.WRITE)) {
                ch.force(true);
            } catch (IOException e) {
                last = e;
                continue;
            }
            synchronized (dirtyFiles) {
                dirtyFiles.remove(p);
            }
        }
        if (last != null) throw last;
    }

    public long maxSeq() {
        long max = 0;
        if (!Files.isDirectory(baseDir)) return max;
        try (var paths = Files.list(baseDir)) {
            for (var p : paths.toList()) {
                if (!p.getFileName().toString().endsWith(".jsonl")) continue;
                try (BufferedReader reader = Files.newBufferedReader(p)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.isBlank()) continue;
                        try {
                            Map<?, ?> m = MAPPER.readValue(line, Map.class);
                            if (m.get(SEQ_FIELD) instanceof Number n) {
                                max = Math.max(max, n.longValue());
                            }
                        } catch (IOException ignored) {
                        }
                    }
                } catch (IOException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
        return max;
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> loadAll() {
        List<Map<String, Object>> all = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        if (!Files.isDirectory(baseDir)) return all;
        try (var paths = Files.list(baseDir)) {
            for (var p : paths.toList()) {
                if (!p.getFileName().toString().endsWith(".jsonl")) continue;
                try (BufferedReader reader = Files.newBufferedReader(p)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.isBlank()) continue;
                        try {
                            Map<String, Object> m = MAPPER.readValue(line, Map.class);
                            if (m.get(SEQ_FIELD) instanceof Number n) {
                                long s = n.longValue();
                                if (!seen.add(s)) continue;
                            }
                            all.add(m);
                        } catch (IOException ignored) {
                        }
                    }
                } catch (IOException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
        return all;
    }

    private Path dateFile(long ts) {
        String date = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT);
        return baseDir.resolve("events_" + date + ".jsonl");
    }

    private static void toMap(TelemetryEvent event, Map<String, Object> map) {
        switch (event) {
            case TelemetryEvent.LlmRequestEvent e -> {
                map.put("inputTokens", e.inputTokens());
                map.put("outputTokens", e.outputTokens());
                map.put("cacheReadTokens", e.cacheReadTokens());
                map.put("cacheCreationTokens", e.cacheCreationTokens());
                map.put("latencyMs", e.latencyMs());
                map.put("stopReason", e.stopReason());
                map.put("success", e.success());
                map.put("errorMessage", e.errorMessage());
            }
            case TelemetryEvent.FileChangeEvent e -> {
                map.put("filePath", e.filePath());
                map.put("extension", e.extension());
                map.put("addedLines", e.addedLines());
                map.put("removedLines", e.removedLines());
                map.put("source", e.source().name());
            }
            case TelemetryEvent.ToolCallEvent e -> {
                map.put("toolName", e.toolName());
                map.put("category", e.category());
                map.put("success", e.success());
                map.put("elapsedSec", e.elapsedSec());
            }
            case TelemetryEvent.AgentErrorEvent e -> {
                map.put("errorType", e.errorType());
                map.put("message", e.message());
            }
            case TelemetryEvent.InterruptEvent e -> {
                // no extra fields beyond base
            }
        }
    }
}
