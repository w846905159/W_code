package com.mewcode.telemetry;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TelemetryStore {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");

    private final Path baseDir;

    public TelemetryStore(Path baseDir) {
        this.baseDir = baseDir;
    }

    public void append(TelemetryEvent event) {
        try {
            Files.createDirectories(baseDir);
            String date = LocalDate.now().format(DATE_FMT);
            Path file = baseDir.resolve("events_" + date + ".jsonl");

            Map<String, Object> map = new LinkedHashMap<>();
            map.put("eventType", event.eventType());
            map.put("sessionId", event.sessionId());
            map.put("ts", event.timestamp());
            map.put("model", event.model());
            toMap(event, map);

            String json = MAPPER.writeValueAsString(map) + "\n";
            Files.writeString(file, json, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
        }
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> loadAll() {
        List<Map<String, Object>> all = new ArrayList<>();
        try (var paths = Files.list(baseDir)) {
            for (var p : paths.toList()) {
                if (!p.toString().endsWith(".jsonl")) continue;
                try (BufferedReader reader = Files.newBufferedReader(p)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.isBlank()) continue;
                        all.add(MAPPER.readValue(line, Map.class));
                    }
                } catch (IOException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
        return all;
    }

    private static void toMap(TelemetryEvent event, Map<String, Object> map) {
        switch (event) {
            case TelemetryEvent.LlmRequestEvent e -> {
                map.put("inputTokens", e.inputTokens());
                map.put("outputTokens", e.outputTokens());
                map.put("cacheReadTokens", e.cacheReadTokens());
                map.put("cacheCreationTokens", e.cacheCreationTokens());
                map.put("latencyMs", e.latencyMs());
                map.put("stopReason", e.stopReason());
                map.put("success", e.success());
                map.put("errorMessage", e.errorMessage());
            }
            case TelemetryEvent.FileChangeEvent e -> {
                map.put("filePath", e.filePath());
                map.put("extension", e.extension());
                map.put("addedLines", e.addedLines());
                map.put("removedLines", e.removedLines());
                map.put("source", e.source().name());
            }
            case TelemetryEvent.ToolCallEvent e -> {
                map.put("toolName", e.toolName());
                map.put("category", e.category());
                map.put("success", e.success());
                map.put("elapsedSec", e.elapsedSec());
            }
            case TelemetryEvent.AgentErrorEvent e -> {
                map.put("errorType", e.errorType());
                map.put("message", e.message());
            }
            case TelemetryEvent.InterruptEvent e -> {
                // no extra fields beyond base
            }
        }
    }
}
