package com.mewcode.telemetry;

public sealed interface TelemetryEvent {

    String eventType();
    String sessionId();
    long timestamp();
    String model();

    enum EditSource { AGENT, USER }

    record LlmRequestEvent(
        String eventType,
        String sessionId,
        long timestamp,
        String model,
        int inputTokens,
        int outputTokens,
        int cacheReadTokens,
        int cacheCreationTokens,
        long latencyMs,
        String stopReason,
        boolean success,
        String errorMessage
    ) implements TelemetryEvent {}

    record FileChangeEvent(
        String eventType,
        String sessionId,
        long timestamp,
        String model,
        String filePath,
        String extension,
        int addedLines,
        int removedLines,
        EditSource source
    ) implements TelemetryEvent {}

    record ToolCallEvent(
        String eventType,       // "tool_call"
        String sessionId,
        long timestamp,
        String model,
        String toolName,        // "ReadFile", "Bash", "WriteFile" ...
        String category,        // "READ", "WRITE", "COMMAND"
        boolean success,
        double elapsedSec       // 执行耗时
    ) implements TelemetryEvent {}

    record AgentErrorEvent(
        String eventType,       // "agent_error"
        String sessionId,
        long timestamp,
        String model,
        String errorType,       // "stream_error" | "timeout" | "rate_limit" | "context_too_long"
        String message
    ) implements TelemetryEvent {}

    record InterruptEvent(
        String eventType,       // "interrupt"
        String sessionId,
        long timestamp,
        String model
    ) implements TelemetryEvent {}

    record FileDiff(int addedLines, int removedLines) {}
}
