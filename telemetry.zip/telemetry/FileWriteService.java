package com.mewcode.telemetry;

import java.util.HashMap;

/**
 * Unified write layer. All file writes (agent tools + future UI editor) go
 * through this service, which diffs before/after content and emits telemetry.
 */
public class FileWriteService {

    /**
     * Record a file write (AGENT tool or USER). The caller performs the actual
     * write and passes the <b>before</b> content read prior to writing, so the
     * diff reflects the real change (not the already-written content).
     *
     * @param path    file path
     * @param before  content before the write
     * @param content content after the write
     * @param source  AGENT or USER
     */
    public static void write(String path, String before, String content,
                             TelemetryEvent.EditSource source) {
        TelemetryEvent.FileDiff diff = diff(before, content);
        TelemetryEmitter.emit(new TelemetryEvent.FileChangeEvent(
                "file_change", TelemetryEmitter.getSessionId(), System.currentTimeMillis(),
                TelemetryEmitter.getModelName(),
                path, extOf(path), diff.addedLines(), diff.removedLines(), source));

        var registry = FileStateRegistry.get();
        if (registry != null) registry.set(path, content);
    }

    /**
     * Record a file edit (AGENT tool or USER). The caller performs the actual
     * replacement and passes both <b>before</b> and <b>after</b> content so the
     * diff reflects the real change.
     */
    public static void edit(String path, String before, String after,
                            TelemetryEvent.EditSource source) {
        TelemetryEvent.FileDiff diff = diff(before, after);
        TelemetryEmitter.emit(new TelemetryEvent.FileChangeEvent(
                "file_change", TelemetryEmitter.getSessionId(), System.currentTimeMillis(),
                TelemetryEmitter.getModelName(),
                path, extOf(path), diff.addedLines(), diff.removedLines(), source));

        var registry = FileStateRegistry.get();
        if (registry != null) registry.set(path, after);
    }

    /**
     * Count added and removed lines by comparing before and after content.
     * Uses set-based matching: a line in 'after' that also exists in 'before'
     * is considered preserved; everything else is added or removed.
     */
    public static TelemetryEvent.FileDiff diff(String before, String after) {
        String[] bLines = before.split("\n", -1);
        String[] aLines = after.split("\n", -1);

        var beforeCount = new HashMap<String, Integer>();
        for (String line : bLines) {
            beforeCount.merge(line, 1, Integer::sum);
        }

        int common = 0;
        for (String line : aLines) {
            Integer count = beforeCount.get(line);
            if (count != null && count > 0) {
                common++;
                beforeCount.put(line, count - 1);
            }
        }

        return new TelemetryEvent.FileDiff(aLines.length - common, bLines.length - common);
    }

    private static String extOf(String path) {
        int idx = path.lastIndexOf('.');
        return idx >= 0 ? path.substring(idx) : "";
    }
}
