package com.mewcode.telemetry;

import java.nio.file.Path;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Shared per-file content snapshots. Both the agent write path
 * (FileWriteService) and the file system watcher keep this registry in sync so
 * we can attribute each change to AGENT (our own writes) or USER (external
 * IDE / UI edits).
 *
 * <p>The AI-vs-user code ratio is derived by comparing these snapshots:
 * agent writes update the snapshot and emit AGENT events; the watcher diffs
 * the snapshot against on-disk content for everything else and emits USER
 * events.</p>
 */
public final class FileStateRegistry {

    private static volatile FileStateRegistry INSTANCE;

    private final ConcurrentHashMap<String, String> snapshots = new ConcurrentHashMap<>();

    private static String key(String path) {
        return Path.of(path).toAbsolutePath().normalize().toString();
    }

    public static synchronized void init() {
        if (INSTANCE == null) {
            INSTANCE = new FileStateRegistry();
        }
    }

    public static FileStateRegistry get() {
        return INSTANCE;
    }

    public boolean hasSnapshot(String path) {
        return snapshots.containsKey(key(path));
    }

    public String snapshot(String path) {
        return snapshots.get(key(path));
    }

    public void set(String path, String content) {
        snapshots.put(key(path), content);
    }
}
