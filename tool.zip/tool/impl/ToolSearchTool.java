// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.tool.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mewcode.subagent.AgentTool;
import com.mewcode.subagent.SubAgentSpec;
import com.mewcode.tool.Tool;
import com.mewcode.tool.ToolCategory;
import com.mewcode.tool.ToolRegistry;
import com.mewcode.tool.ToolResult;

import java.util.*;
import java.util.stream.Collectors;

public class ToolSearchTool implements Tool {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT);

    private static final String DESCRIPTION = """
            Search for and load additional tools that are not immediately available. \
            Some tools are deferred (not loaded by default) to save context space. \
            Use this tool to discover and load them.

            Query forms:
            - "select:ToolName,AnotherTool" -- fetch exact tools by name
            - "keyword search" -- keyword search, returns up to max_results matches
            - "subagent:keyword" -- search sub-agent types by keyword
            - "subagent:list" -- list all available sub-agent types

            When you need a tool or sub-agent type that isn't in your current list, use this to find it.""";

    private final ToolRegistry registry;
    private final String protocol;
    private final AgentTool agentTool;

    public ToolSearchTool(ToolRegistry registry) {
        this(registry, "anthropic", null);
    }

    public ToolSearchTool(ToolRegistry registry, String protocol) {
        this(registry, protocol, null);
    }

    public ToolSearchTool(ToolRegistry registry, String protocol, AgentTool agentTool) {
        this.registry = registry;
        this.protocol = protocol;
        this.agentTool = agentTool;
    }

    @Override
    public String name() {
        return "ToolSearch";
    }

    @Override
    public String description() {
        return DESCRIPTION;
    }

    @Override
    public ToolCategory category() {
        return ToolCategory.READ;
    }

    @Override
    public boolean shouldDefer() {
        return false;
    }

    @Override
    public Map<String, Object> schema() {
        return Map.of(
                "name", name(),
                "description", description(),
                "input_schema", Map.of(
                        "type", "object",
                        "properties", Map.of(
                                "query", Map.of(
                                        "type", "string",
                                        "description", "Query to find deferred tools. Use \"select:Name1,Name2\" for direct selection, or keywords to search."
                                ),
                                "max_results", Map.of(
                                        "type", "integer",
                                        "description", "Maximum results to return (default: 5)",
                                        "default", 5
                                )
                        ),
                        "required", List.of("query")
                )
        );
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String query = stringArg(args, "query", "");
        if (query.isEmpty()) {
            return ToolResult.error("Error: query is required");
        }

        int maxResults = intArg(args, "max_results", 5);
        if (maxResults < 1) {
            maxResults = 5;
        }
        if (maxResults > 20) {
            maxResults = 20;
        }

        List<Map<String, Object>> schemas;

        if (query.startsWith("subagent:")) {
            return handleSubAgentSearch(query.substring("subagent:".length()).trim());
        } else if (query.startsWith("select:")) {
            List<String> names = Arrays.stream(query.substring("select:".length()).split(","))
                    .map(String::trim)
                    .toList();
            schemas = registry.findDeferredByNames(names, protocol);
        } else {
            schemas = registry.searchDeferred(query, maxResults, protocol);
        }

        if (schemas.isEmpty()) {
            List<Tool> deferred = registry.getDeferredTools();
            String nameList = deferred.stream()
                    .map(Tool::name)
                    .collect(Collectors.joining(", "));
            return ToolResult.success(
                    "No matching deferred tools found for query \"" + query
                            + "\". Available deferred tools: " + nameList
            );
        }

        // Mark found tools as discovered so their schemas appear in subsequent requests
        for (var s : schemas) {
            Object nameObj = s.get("name");
            if (nameObj instanceof String n) {
                registry.markDiscovered(n);
            }
        }

        String schemasJson;
        try {
            schemasJson = MAPPER.writeValueAsString(schemas);
        } catch (JsonProcessingException e) {
            return ToolResult.error("Error serializing schemas: " + e.getMessage());
        }

        return ToolResult.success(
                "Found " + schemas.size() + " tool(s). Their full schemas are now loaded and will be available in subsequent requests.\n\n" + schemasJson
        );
    }

    private ToolResult handleSubAgentSearch(String query) {
        if (agentTool == null) {
            return ToolResult.error("Error: Agent tool not available for subagent search");
        }

        List<String> allNames = agentTool.getAllSubAgentNames();
        Map<String, SubAgentSpec> specs = agentTool.getAgentSpecs();

        // "list" — return all available types
        if ("list".equals(query)) {
            var sb = new StringBuilder();
            sb.append("Available sub-agent types:\n");
            for (String name : allNames) {
                boolean discovered = agentTool.getDiscoveredSubAgentNames().contains(name);
                SubAgentSpec spec = resolveSubAgent(name, specs);
                String desc = spec != null ? spec.description() : "(unknown)";
                String marker = discovered ? "" : " [undiscovered]";
                sb.append("- ").append(name).append(marker).append(": ").append(desc).append("\n");
            }
            sb.append("\nUse \"subagent:<name>\" to discover a specific type.");
            return ToolResult.success(sb.toString().strip());
        }

        // Single exact name
        if (agentTool.getDiscoveredSubAgentNames().contains(query)) {
            return ToolResult.success("Sub-agent '" + query + "' is already loaded and available.");
        }
        if (allNames.contains(query)) {
            agentTool.discoverSubAgent(query);
            SubAgentSpec spec = resolveSubAgent(query, specs);
            String desc = spec != null ? spec.description() : "(unknown)";
            return ToolResult.success(
                    "Discovered sub-agent '" + query + "': " + desc
                    + "\nIt is now available in the Agent tool's subagent_type parameter.");
        }

        // Keyword search
        String lower = query.toLowerCase();
        var matches = new ArrayList<String>();
        for (String name : allNames) {
            if (name.toLowerCase().contains(lower)) {
                matches.add(name);
            } else if (specs != null) {
                SubAgentSpec spec = specs.get(name);
                if (spec != null && spec.description().toLowerCase().contains(lower)) {
                    matches.add(name);
                }
            }
        }

        if (matches.isEmpty()) {
            return ToolResult.success(
                    "No sub-agents found matching \"" + query + "\". "
                    + "Available: " + String.join(", ", allNames));
        }

        var sb = new StringBuilder();
        sb.append("Found ").append(matches.size()).append(" sub-agent(s):\n");
        for (String name : matches) {
            boolean discovered = agentTool.getDiscoveredSubAgentNames().contains(name);
            SubAgentSpec spec = resolveSubAgent(name, specs);
            String desc = spec != null ? spec.description() : "(unknown)";
            String marker = discovered ? " (loaded)" : "";
            sb.append("- ").append(name).append(marker).append(": ").append(desc).append("\n");
        }
        sb.append("\nUse \"subagent:").append(matches.get(0))
                .append("\" to load a specific type.");
        return ToolResult.success(sb.toString().strip());
    }

    private static SubAgentSpec resolveSubAgent(String name, Map<String, SubAgentSpec> specs) {
        if (specs != null) {
            SubAgentSpec spec = specs.get(name);
            if (spec != null) return spec;
        }
        return switch (name) {
            case "general-purpose" -> com.mewcode.subagent.SubAgentSpec.GENERAL_PURPOSE;
            case "plan" -> com.mewcode.subagent.SubAgentSpec.PLAN;
            case "explore" -> com.mewcode.subagent.SubAgentSpec.EXPLORE;
            default -> null;
        };
    }

    private static String stringArg(Map<String, Object> args, String key, String def) {
        var v = args.get(key);
        return v instanceof String s ? s : def;
    }

    private static int intArg(Map<String, Object> args, String key, int def) {
        var v = args.get(key);
        if (v instanceof Number n) return n.intValue();
        return def;
    }
}
