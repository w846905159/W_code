// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.tool.impl;

import com.mewcode.tool.Tool;
import com.mewcode.tool.ToolCategory;
import com.mewcode.tool.ToolResult;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class BashTool implements Tool {

    private static final int MAX_TIMEOUT = 600;

    private static final String OS_NAME = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
    private static final boolean IS_WINDOWS = OS_NAME.contains("win");

    /** Resolved bash executable (empty string if none could be found on Windows). */
    private static volatile String bashPath;

    private static final String DESCRIPTION = """
            Execute a shell command and return stdout and stderr.

            IMPORTANT: Avoid using this tool to run cat, head, tail, sed, awk, or echo commands. \
            Instead use the dedicated ReadFile, EditFile, or WriteFile tools which provide a better experience.

            Usage notes:
            - The working directory persists between commands, but shell state does not.
            - Always quote file paths containing spaces with double quotes.
            - Try to maintain your current working directory using absolute paths; avoid cd unless the user explicitly requests it.
            - Optional timeout in seconds (max 600). Default is 120s.
            - When issuing multiple independent commands, make separate parallel tool calls instead of chaining with &&.
            - Use && to chain sequential dependent commands. Use ; only when you don't care if earlier commands fail.
            - DO NOT use newlines to separate commands.

            Git Safety Protocol:
            - NEVER run destructive git commands (push --force, reset --hard, checkout ., clean -f, branch -D) unless the user explicitly requests it.
            - NEVER skip hooks (--no-verify) unless the user explicitly requests it.
            - Prefer creating a new commit rather than amending an existing one.
            - Before running destructive operations, consider safer alternatives.

            Avoid unnecessary sleep commands. Do not retry failing commands in a sleep loop — diagnose the root cause instead.
            When using find, search from "." or a specific path, not "/" — scanning the full filesystem is too expensive.""";

    @Override
    public String name() {
        return "Bash";
    }

    @Override
    public String description() {
        return DESCRIPTION;
    }

    @Override
    public ToolCategory category() {
        return ToolCategory.COMMAND;
    }

    @Override
    public Map<String, Object> schema() {
        return Map.of(
                "name", name(),
                "description", description(),
                "input_schema", Map.of(
                        "type", "object",
                        "properties", Map.of(
                                "command", Map.of("type", "string", "description", "Shell command to execute"),
                                "timeout", Map.of("type", "integer", "description", "Timeout in seconds (max 600)", "default", 120)
                        ),
                        "required", List.of("command")
                )
        );
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String command = stringArg(args, "command", "");
        if (command.isEmpty()) {
            return ToolResult.error("Error: command is required");
        }

        int timeout = intArg(args, "timeout", 120);
        if (timeout > MAX_TIMEOUT) {
            timeout = MAX_TIMEOUT;
        }

        try {
            String shell = resolveBash();
            List<String> cmd;
            if (!IS_WINDOWS || !shell.isEmpty()) {
                cmd = List.of(shell, "-c", command);
            } else {
                // Windows without Git Bash: fall back to the native cmd shell.
                cmd = List.of("cmd.exe", "/C", command);
            }
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(false);
            File workingDir = resolveWorkingDirectory();
            if (workingDir != null) {
                pb.directory(workingDir);
            }
            Process process = pb.start();

            // Drain stdout and stderr CONCURRENTLY on separate virtual threads.
            // Reading them sequentially deadlocks whenever the child writes
            // more than the OS pipe buffer to stderr while stdout is still
            // being drained. The timeout below bounds the full lifetime, so a
            // stalled command can never hang this thread forever.
            ExecutorService pump = Executors.newVirtualThreadPerTaskExecutor();
            try {
                Future<String> stdoutF = pump.submit(() -> readStream(process.getInputStream()));
                Future<String> stderrF = pump.submit(() -> readStream(process.getErrorStream()));

                boolean finished = process.waitFor(timeout, TimeUnit.SECONDS);
                if (!finished) {
                    process.destroyForcibly();
                    process.waitFor(5, TimeUnit.SECONDS);
                    String stdout = await(stdoutF, 5, "");
                    String stderr = await(stderrF, 5, "");
                    return ToolResult.error("Error: command timed out after " + timeout + "s\n"
                            + formatOutput(command, stdout, stderr, -1));
                }

                String stdout = await(stdoutF, 5, "");
                String stderr = await(stderrF, 5, "");
                int exitCode = process.exitValue();

                return new ToolResult(formatOutput(command, stdout, stderr, exitCode), exitCode != 0);
            } finally {
                // Interrupt any drain task still blocked because a grandchild
                // inherited the pipe and kept it open.
                pump.shutdownNow();
            }

        } catch (IOException e) {
            return ToolResult.error("Error executing command: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return ToolResult.error("Error: command interrupted");
        }
    }

    private static String formatOutput(String command, String stdout, String stderr, int exitCode) {
        var sb = new StringBuilder();
        sb.append("$ ").append(command).append('\n');
        if (!stdout.isEmpty()) {
            sb.append(stdout);
            if (!stdout.endsWith("\n")) {
                sb.append('\n');
            }
        }
        if (!stderr.isEmpty()) {
            sb.append("STDERR: ").append(stderr);
            if (!stderr.endsWith("\n")) {
                sb.append('\n');
            }
        }
        sb.append("(exit code ").append(exitCode).append(')');
        return sb.toString();
    }

    /** Reads a stream fully as UTF-8; returns partial/empty on error. */
    private static String readStream(InputStream in) {
        try {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private static String await(Future<String> f, long seconds, String defaultVal) {
        try {
            return f.get(seconds, TimeUnit.SECONDS);
        } catch (Exception e) {
            return defaultVal;
        }
    }

    /**
     * Resolves the working directory for a command. When a worktree session is
     * active its path is used (so EnterWorktree/agent isolation actually takes
     * effect for the shell); otherwise commands run in the JVM's launch
     * directory. Returns null when no directory can be determined.
     */
    private static File resolveWorkingDirectory() {
        var session = com.mewcode.worktree.WorktreeSessionStore.getCurrentSession();
        if (session != null && session.worktreePath() != null && !session.worktreePath().isBlank()) {
            Path wt = Path.of(session.worktreePath());
            if (Files.isDirectory(wt)) {
                return wt.toFile();
            }
        }
        Path cwd = Path.of(System.getProperty("user.dir"));
        return Files.isDirectory(cwd) ? cwd.toFile() : null;
    }

    /**
     * Resolves the shell to use for command execution.
     * <ul>
     *   <li>Non-Windows: always {@code bash}.</li>
     *   <li>Windows: prefers Git Bash found on PATH or at the usual install
     *       locations so POSIX-style commands keep working. Falls back to an
     *       empty string (caller then uses {@code cmd.exe /C}).</li>
     * </ul>
     */
    private static String resolveBash() {
        if (bashPath != null) return bashPath;
        String resolved = IS_WINDOWS ? findOnPath("bash.exe") : "bash";
        if (IS_WINDOWS && resolved == null) {
            String localAppData = System.getenv("LOCALAPPDATA");
            String[] candidates = {
                    "C:\\Program Files\\Git\\bin\\bash.exe",
                    "C:\\Program Files\\Git\\usr\\bin\\bash.exe",
                    "C:\\Program Files (x86)\\Git\\bin\\bash.exe",
                    localAppData != null ? localAppData + "\\Programs\\Git\\bin\\bash.exe" : null,
                    "D:\\Git\\bin\\bash.exe"
            };
            for (String c : candidates) {
                if (c != null && Files.isExecutable(Path.of(c))) {
                    resolved = c;
                    break;
                }
            }
        }
        bashPath = resolved == null ? "" : resolved;
        return bashPath;
    }

    /** Looks for an executable in the current PATH. */
    private static String findOnPath(String exe) {
        String pathEnv = System.getenv("Path");
        if (pathEnv == null) return null;
        for (String dir : pathEnv.split(Pattern.quote(File.pathSeparator))) {
            if (dir == null || dir.isEmpty()) continue;
            Path p = Path.of(dir, exe);
            if (Files.isExecutable(p)) return p.toString();
        }
        return null;
    }

    private static String stringArg(Map<String, Object> args, String key, String def) {
        var v = args.get(key);
        return v instanceof String s ? s : def;
    }

    private static int intArg(Map<String, Object> args, String key, int def) {
        var v = args.get(key);
        if (v instanceof Number n) return n.intValue();
        return def;
    }
}
