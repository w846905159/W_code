// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.teams;

import com.mewcode.agent.Agent;
import com.mewcode.agent.AgentEvent;
import com.mewcode.config.ProviderConfig;
import com.mewcode.conversation.ConversationManager;
import com.mewcode.llm.LlmClient;
import com.mewcode.tool.ToolRegistry;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Logger;

/**
 * Manages multi-agent teams with mailbox-based communication.
 */
public class TeamManager {

    private static final Logger LOG = Logger.getLogger(TeamManager.class.getName());

    public enum TeamMode { IN_PROCESS, TMUX, ITERM }

    private final Map<String, Team> teams = new LinkedHashMap<>();

    public synchronized Team createTeam(String name, TeamMode mode) {
        Team team = new Team(name, mode);
        teams.put(name, team);
        return team;
    }

    public synchronized Team createTeamWith(Team team) {
        teams.put(team.name, team);
        return team;
    }

    public synchronized Team getTeam(String name) {
        return teams.get(name);
    }

    public synchronized void deleteTeam(String name) {
        Team team = teams.remove(name);
        if (team != null) {
            team.stopAll();
        }
    }

    public synchronized List<String> listTeams() {
        return new ArrayList<>(teams.keySet());
    }

    public synchronized void closeAll() {
        for (Team team : teams.values()) {
            team.stopAll();
        }
        teams.clear();
    }

    public synchronized List<TeammateProgress> getAllTeammateProgress() {
        return teams.values().stream()
                .flatMap(t -> t.getTeammateProgressList().stream())
                .toList();
    }

    public static TeamMode detectBackend() {
        return TeamMode.IN_PROCESS;
    }

    public static TeamMode detectPaneBackend() {
        String tmux = System.getenv("TMUX");
        if (tmux != null && !tmux.isEmpty()) {
            return TeamMode.TMUX;
        }
        String iterm = System.getenv("ITERM_SESSION_ID");
        if (iterm != null && !iterm.isEmpty()) {
            return TeamMode.ITERM;
        }
        try {
            Process p = new ProcessBuilder("which", "tmux").start();
            if (p.waitFor() == 0) return TeamMode.TMUX;
        } catch (Exception ignored) {}
        return TeamMode.IN_PROCESS;
    }

    // ── Inner classes ──────────────────────────────────────────────────

    private static Path teamsBaseDir() {
        String dir = System.getenv("MEWCODE_TEAMS_DIR");
        if (dir != null && !dir.isEmpty()) {
            return Path.of(dir);
        }
        return Path.of(System.getProperty("user.dir"), ".mewcode", "teams");
    }

    public static class Team {
        final String name;
        final TeamMode mode;
        final Map<String, Member> members = new LinkedHashMap<>();
        private final FileMailBox mailBox;

        public Team(String name, TeamMode mode) {
            this.name = name;
            this.mode = mode;
            this.mailBox = new FileMailBox(teamsBaseDir().resolve(name).resolve("inboxes"));
        }

        public Team(String name, TeamMode mode, FileMailBox mailBox) {
            this.name = name;
            this.mode = mode;
            this.mailBox = mailBox;
        }

        public String getName() { return name; }
        public TeamMode getMode() { return mode; }

        public FileMailBox getMailBox() { return mailBox; }

        public synchronized Member addMember(String name, LlmClient client, ToolRegistry registry,
                                             String protocol, ProviderConfig cfg) {
            Agent ag = (client != null) ? new Agent(client, registry, protocol, cfg) : null;
            Member member = new Member(name, ag, new ConversationManager());
            members.put(name, member);
            return member;
        }

        public synchronized BlockingQueue<AgentEvent> startMember(String name, String task) {
            Member member = members.get(name);
            if (member == null) return null;
            member.conv.addUserMessage(task);
            BlockingQueue<AgentEvent> queue = member.agent.run(member.conv);
            member.active = true;
            return queue;
        }

        public synchronized void stopMember(String name) {
            Member member = members.get(name);
            if (member == null) return;
            // External backends (tmux/iTerm) own a real OS pane that must be
            // torn down before clearing the local handle. In-process members
            // just need the thread interrupted.
            if (member.paneId != null && !member.paneId.isEmpty()) {
                switch (mode) {
                    case TMUX -> TmuxBackend.stopTmuxTeammate(member.paneId);
                    case ITERM -> ITermBackend.stopITermTeammate(member.paneId);
                }
            }
            member.active = false;
            if (member.thread != null) {
                member.thread.interrupt();
            }
        }

        public synchronized void stopAll() {
            for (String name : new ArrayList<>(members.keySet())) {
                stopMember(name);
            }
        }

        public synchronized Member getMember(String name) {
            return members.get(name);
        }

        public synchronized boolean hasMember(String name) {
            return members.containsKey(name);
        }

        public synchronized List<String> memberNames() {
            return new ArrayList<>(members.keySet());
        }

        public void sendMessage(String from, String to, String content) {
            sendMessage(from, to, content, FileMailBox.MessageKind.TASK);
        }

        public void sendMessage(String from, String to, String content, FileMailBox.MessageKind kind) {
            mailBox.send(to, new FileMailBox.MailMessage(from, content, kind));
        }

        public void sendMessage(String from, String to, FileMailBox.MailMessage msg) {
            mailBox.send(to, msg);
        }

        public List<TeammateProgress> getTeammateProgressList() {
            return members.values().stream()
                    .filter(m -> m.progress != null)
                    .map(m -> m.progress)
                    .toList();
        }

        /**
         * Registers an externally-spawned teammate (tmux/iTerm) in the Members
         * map. These members don't have an AgentRef on this side — their LLM
         * lives in the spawned process — so the entry is just a name+handle
         * stub used by the lead's coordination tools.
         */
        public synchronized void recordExternalMember(String name, String paneId) {
            Member member = new Member(name, null, null);
            member.active = true;
            member.paneId = paneId;
            members.put(name, member);
        }
    }

    public static class Member {
        public final String name;
        public final Agent agent;
        public final ConversationManager conv;
        public volatile boolean active;
        public volatile Thread thread;
        public TeammateProgress progress;

        /**
         * PaneID is the backend-specific handle assigned by tmux/iTerm spawn
         * (e.g., window or tab name). Empty for in-process members.
         */
        public volatile String paneId;

        public Member(String name, Agent agent, ConversationManager conv) {
            this.name = name;
            this.agent = agent;
            this.conv = conv;
        }

        public String getName() { return name; }
        public boolean isActive() { return active; }
    }

}
