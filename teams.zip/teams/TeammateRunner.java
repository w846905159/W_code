// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.teams;

import com.mewcode.agent.AgentEvent;
import com.mewcode.tui.SpinnerVerbs;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Main loop for in-process teammates.
 * Corresponds to Go's runner.go.
 *
 * The teammate lifecycle per turn:
 * 1. InjectPendingMessages — fold any pending mailbox messages into a system reminder
 * 2. Agent.Run() — execute one full turn (blocking until LoopComplete)
 * 3. sendIdleNotification — drop an idle marker into the lead's inbox
 * 4. waitForNextPromptOrShutdown — idle poll, return on new work or [shutdown]
 */
public final class TeammateRunner {

    public static final String LEAD_NAME = "lead";
    public static final String SHUTDOWN_PREFIX = "[shutdown]";

    public static final long IDLE_POLL_MS = 500;

    private TeammateRunner() {}

    /**
     * Drives a teammate's main loop in the current thread. It blocks until
     * the thread is interrupted or a shutdown request lands in the inbox.
     * <p>
     * The initialPrompt jump-starts the first iteration; subsequent iterations
     * get their prompt from the mailbox.
     */
    public static void runInProcessTeammate(
            TeamManager.Team team,
            TeamManager.Member member,
            String initialPrompt,
            String addendum,
            BlockingQueue<AgentEvent> eventOut
    ) {
        var progress = new TeammateProgress(member.getName(), team.getName(), SpinnerVerbs.random());
        member.progress = progress;

        if (addendum != null && !addendum.isEmpty()) {
            member.conv.addSystemReminder(addendum);
        }

        String nextPrompt = initialPrompt;
        String idleReason = "available";

        while (!Thread.currentThread().isInterrupted()) {
            // Fold pending messages into the conversation as a system reminder
            String reminder = injectPendingMessages(team, member.getName());
            if (reminder != null && !reminder.isEmpty()) {
                member.conv.addSystemReminder(reminder);
            }

            if (nextPrompt != null && !nextPrompt.isEmpty()) {
                member.conv.addUserMessage(nextPrompt);
            }
            nextPrompt = null;

            // Run agent
            var agentQueue = member.agent.run(member.conv);
            boolean failed = drainAgentEvents(agentQueue, eventOut, progress);

            // Update progress status
            if (failed) {
                progress.setStatus("failed");
                idleReason = "failed";
            } else {
                progress.setStatus("idle");
                idleReason = "available";
            }

            // Notify the lead that this teammate finished its turn
            team.sendMessage(member.getName(), LEAD_NAME,
                    new FileMailBox.MailMessage(
                            member.getName(),
                            createIdleNotification(member.getName(), idleReason),
                            java.time.Instant.now().toString(),
                            false, "", "idle",
                            FileMailBox.MessageKind.IDLE
                    ));

            // Idle poll: drain inbox, detect shutdown, otherwise build next prompt
            var result = waitForNextPromptOrShutdown(team, member.getName());
            if (result.shutdown) break;
            nextPrompt = result.prompt;
        }

        member.active = false;
        if (progress != null) {
            if ("failed".equals(idleReason)) {
                progress.setStatus("failed");
            } else {
                progress.setStatus("completed");
            }
        }
    }

    /**
     * Reads every unread notification in every team's lead inbox and returns
     * them as system-reminder strings (one per team). The lead's main loop
     * installs this as a notification callback so teammate idle notifications
     * surface to the model at the top of each turn.
     */
    public static List<String> drainLeadMailbox(TeamManager teamMgr) {
        if (teamMgr == null) return List.of();
        var result = new java.util.ArrayList<String>();
        for (String teamName : teamMgr.listTeams()) {
            var team = teamMgr.getTeam(teamName);
            if (team == null) continue;
            var messages = team.getMailBox().readUnread(LEAD_NAME);
            if (messages.isEmpty()) continue;

            var sb = new StringBuilder();
            sb.append("<team-notification team=\"").append(teamName).append("\">\n");
            for (var msg : messages) {
                sb.append("from=").append(msg.from()).append(": ").append(msg.text()).append("\n");
            }
            sb.append("</team-notification>");
            result.add(sb.toString());

            team.getMailBox().markAllRead(LEAD_NAME);
        }
        return result;
    }

    /**
     * Builds the system reminder addendum for a teammate.
     * Matches Go's BuildTeammateAddendum.
     */
    public static String buildTeammateAddendum(String teamName, String memberName, List<String> otherMembers) {
        var sb = new StringBuilder();
        sb.append("You are a member of team \"").append(teamName).append("\". ");
        sb.append("Your name is \"").append(memberName).append("\".\n\n");
        sb.append("The lead is reachable as \"").append(LEAD_NAME).append("\". ");
        sb.append("Deliver your final result to the lead with SendMessage(to=\"").append(LEAD_NAME)
                .append("\", content=...) — the idle notification alone only signals completion, ")
                .append("it does not carry your output.\n");
        if (otherMembers != null && !otherMembers.isEmpty()) {
            sb.append("Other team members: ").append(String.join(", ", otherMembers)).append("\n\n");
        }
        sb.append("You can communicate with the lead and teammates using the SendMessage tool.\n");
        sb.append("Messages from the team arrive as system reminders at the start of each turn.\n");
        sb.append("When you finish your current task, send your final result to \"")
                .append(LEAD_NAME).append("\" via SendMessage, then stop calling tools — ");
        sb.append("an idle notification will be sent to the lead automatically.\n");
        return sb.toString();
    }

    /**
     * Returns any unread mailbox messages formatted as a system-reminder string
     * and marks them read. Returns empty string if no new mail.
     * Matches Go's InjectPendingMessages.
     */
    public static String injectPendingMessages(TeamManager.Team team, String memberName) {
        var messages = team.getMailBox().readUnread(memberName);
        if (messages.isEmpty()) return "";

        var sb = new StringBuilder("You have new messages:\n\n");
        for (var msg : messages) {
            sb.append("From ").append(msg.from()).append(": ").append(msg.text()).append("\n\n");
        }
        team.getMailBox().markAllRead(memberName);
        return sb.toString();
    }

    public static boolean isShutdownRequest(String message) {
        return message != null && message.strip().startsWith(SHUTDOWN_PREFIX);
    }

    /**
     * True when a message is a terminate signal. Honours the structured
     * {@link FileMailBox.MessageKind#SHUTDOWN} kind, and falls back to the
     * legacy {@code [shutdown]} text prefix so any hand-typed shutdown still
     * works after the kind field was introduced.
     */
    private static boolean isShutdown(FileMailBox.MailMessage msg) {
        return msg.kind() == FileMailBox.MessageKind.SHUTDOWN
                || isShutdownRequest(msg.text());
    }

    /**
     * Builds the idle notification text. Matches Go's CreateIdleNotification.
     */
    public static String createIdleNotification(String memberName, String reason) {
        return "[idle] %s (reason: %s)".formatted(memberName, reason);
    }

    // ── Internal helpers ──────────────────────────────────────────────

    private record WaitResult(String prompt, boolean shutdown) {}

    /**
     * Blocks until the inbox has at least one actionable message, then turns the
     * actionable batch into the next user prompt. Routing is based on the
     * structured {@link FileMailBox.MessageKind kind} (backed up by the legacy
     * prefix checks): {@code SHUTDOWN} terminates, {@code NOTICE} is consumed but
     * never wakes an idle worker (so a teammate's progress report can't be
     * mistaken for a command), and everything else ({@code TASK}) wakes into a
     * prompt. Matches Go's waitForNextPromptOrShutdown.
     */
    private static WaitResult waitForNextPromptOrShutdown(TeamManager.Team team, String memberName) {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Thread.sleep(IDLE_POLL_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return new WaitResult(null, true);
            }

            var messages = team.getMailBox().readUnread(memberName);
            if (messages.isEmpty()) continue;

            boolean hasShutdown = false;
            var keep = new java.util.ArrayList<FileMailBox.MailMessage>();
            for (var msg : messages) {
                if (isShutdown(msg)) {
                    hasShutdown = true;
                } else if (msg.kind() == FileMailBox.MessageKind.NOTICE) {
                    // Informational: never wake an idle worker into a task turn.
                    continue;
                } else {
                    keep.add(msg);
                }
            }
            team.getMailBox().markAllRead(memberName);

            if (hasShutdown) {
                return new WaitResult(null, true);
            }
            if (keep.isEmpty()) {
                continue;
            }
            return new WaitResult(formatInboundAsPrompt(keep), false);
        }
        return new WaitResult(null, true);
    }

    /**
     * Turns an unread batch into a single user prompt.
     * Matches Go's formatInboundAsPrompt.
     */
    private static String formatInboundAsPrompt(List<FileMailBox.MailMessage> msgs) {
        if (msgs.isEmpty()) return "";
        var sb = new StringBuilder("You have new messages from your team:\n\n");
        for (var msg : msgs) {
            sb.append("From ").append(msg.from()).append(": ").append(msg.text()).append("\n\n");
        }
        return sb.toString();
    }

    /**
     * Drains agent events from the source queue, forwarding them to sink and
     * recording progress. Returns true if the agent encountered a fatal error.
     */
    private static boolean drainAgentEvents(BlockingQueue<AgentEvent> source,
                                             BlockingQueue<AgentEvent> sink,
                                             TeammateProgress progress) {
        while (true) {
            AgentEvent event;
            try {
                event = source.poll(60, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                if (progress != null) progress.setStatus("failed");
                return true;
            }
            if (event == null) return false;
            if (sink != null) {
                sink.offer(event);
            }

            // Record progress from agent events
            if (event instanceof AgentEvent.ToolUseEvent tue) {
                if (progress != null) progress.recordToolUse(tue.toolName(), tue.args());
            } else if (event instanceof AgentEvent.UsageEvent ue) {
                if (progress != null) progress.recordTokens(ue.inputTokens(), ue.outputTokens());
            } else if (event instanceof AgentEvent.ErrorEvent) {
                if (progress != null) progress.setStatus("failed");
                return true;
            } else if (event instanceof AgentEvent.LoopComplete) {
                return false;
            }
        }
    }
}
