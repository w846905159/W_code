// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.teams;

import com.mewcode.agent.AgentEvent;
import com.mewcode.config.ProviderConfig;
import com.mewcode.llm.LlmClient;
import com.mewcode.tool.ToolRegistry;

import java.util.concurrent.BlockingQueue;

/**
 * Unified dispatcher for teammate spawning across all backends.
 * Corresponds to Go's spawn.go.
 */
public final class SpawnDispatcher {

    public record SpawnConfig(
            TeamManager.Team team,
            String memberName,
            String task,
            String addendum,
            LlmClient client,
            ToolRegistry registry,
            String protocol,
            ProviderConfig providerConfig,
            String workdir
    ) {}

    public record SpawnResult(
            TeamManager.TeamMode mode,
            BlockingQueue<AgentEvent> eventQueue,
            String paneId
    ) {
        public SpawnResult(TeamManager.TeamMode mode, String paneId) {
            this(mode, null, paneId);
        }
    }

    private SpawnDispatcher() {}

    /**
     * Creates a new team member and launches it under the team's currently
     * selected backend. It is the single entry point used by AgentTool's
     * team_name code path.
     * <p>
     * For external backends (tmux/iTerm), the teammate's initial task is
     * delivered via the mailbox before the new process boots, so the teammate
     * sees the task on its first idle poll.
     */
    public static SpawnResult spawnTeammate(SpawnConfig config) throws Exception {
        var team = config.team();
        var mode = team.getMode();

        switch (mode) {
            case IN_PROCESS -> {
                // Workdir override applied before launch so file/Bash tools
                // resolve relative to the isolated path.
                BlockingQueue<AgentEvent> eventQueue = InProcessBackend.startInProcessMember(
                        team,
                        config.memberName(),
                        config.client(),
                        config.registry(),
                        config.protocol(),
                        config.providerConfig(),
                        config.task(),
                        config.addendum()
                );
                if (config.workdir() != null) {
                    var member = team.getMember(config.memberName());
                    if (member != null && member.agent != null) {
                        member.agent.setWorkDir(config.workdir());
                    }
                }
                return new SpawnResult(mode, eventQueue, null);
            }
            case TMUX -> {
                // Write task to mailbox so first poll picks it up
                if (config.task() != null && !config.task().isEmpty()) {
                    team.sendMessage(TeammateRunner.LEAD_NAME, config.memberName(), config.task());
                }
                String cliCommand = buildTeammateCLI(team.getName(), config.memberName(), config.workdir());
                String paneId = TmuxBackend.spawnTmuxTeammate(team.getName(), config.memberName(), cliCommand);
                team.recordExternalMember(config.memberName(), paneId);
                return new SpawnResult(mode, paneId);
            }
            case ITERM -> {
                if (config.task() != null && !config.task().isEmpty()) {
                    team.sendMessage(TeammateRunner.LEAD_NAME, config.memberName(), config.task());
                }
                String cliCommand = buildTeammateCLI(team.getName(), config.memberName(), config.workdir());
                String tabId = ITermBackend.spawnITermTeammate(team.getName(), config.memberName(), cliCommand);
                team.recordExternalMember(config.memberName(), tabId);
                return new SpawnResult(mode, tabId);
            }
            default -> throw new IllegalStateException("Unsupported team mode: " + mode);
        }
    }

    /**
     * Builds the shell command for a worker process.
     * Format: cd '<workdir>' && '<mewcode>' --teammate --team-name <t> --agent-name <n>
     */
    public static String buildTeammateCLI(String teamName, String memberName, String workdir) {
        String wd = workdir != null ? workdir : System.getProperty("user.dir");
        String mewcode = ProcessHandle.current().info().command().orElse("mewcode");
        return "cd %s && %s --teammate --team-name %s --agent-name %s".formatted(
                shellQuote(wd), shellQuote(mewcode), shellQuote(teamName), shellQuote(memberName));
    }

    static String shellQuote(String s) {
        if (s.matches("[a-zA-Z0-9_./-]+")) return s;
        return "'" + s.replace("'", "'\\''") + "'";
    }
}
