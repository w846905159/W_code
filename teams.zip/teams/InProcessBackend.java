// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.teams;

import com.mewcode.agent.Agent;
import com.mewcode.agent.AgentEvent;
import com.mewcode.config.ProviderConfig;
import com.mewcode.llm.LlmClient;
import com.mewcode.tool.ToolRegistry;
import com.mewcode.tui.SpinnerVerbs;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * In-process backend for running teammates in virtual threads.
 * Corresponds to Go's inprocess.go.
 */
public final class InProcessBackend {

    private InProcessBackend() {}

    /**
     * Registers a teammate on the team and launches its long-running main loop
     * in a virtual thread. The returned queue forwards every AgentEvent emitted
     * across all turns; it terminates when the loop exits (thread interrupt or
     * shutdown request in the inbox).
     * <p>
     * The lifecycle of the thread is bound to cancellation of the teammate:
     * the caller interrupts the thread to stop it. Each pass through the loop
     * calls TeammateRunner.runInProcessTeammate.
     */
    public static BlockingQueue<AgentEvent> startInProcessMember(
            TeamManager.Team team,
            String memberName,
            LlmClient client,
            ToolRegistry registry,
            String protocol,
            ProviderConfig providerConfig,
            String task,
            String addendum
    ) {
        var member = team.addMember(memberName, client, registry, protocol, providerConfig);
        member.progress = new TeammateProgress(memberName, team.getName(), SpinnerVerbs.random());

        member.active = true;
        BlockingQueue<AgentEvent> eventQueue = new LinkedBlockingQueue<>(32);

        member.thread = Thread.startVirtualThread(() -> {
            try {
                TeammateRunner.runInProcessTeammate(team, member, task, addendum, eventQueue);
            } finally {
                member.active = false;
            }
        });

        return eventQueue;
    }
}
