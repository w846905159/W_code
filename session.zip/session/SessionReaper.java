// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.session;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * Background reaper that periodically prunes history sessions so stale
 * transcripts and their file-history directories don't accumulate on disk
 * forever. Mirrors the worktree stale-cleanup pattern: a single daemon thread
 * runs {@link SessionManager#prune} on a fixed schedule.
 */
public final class SessionReaper {

    private static final Logger log = Logger.getLogger(SessionReaper.class.getName());

    private static volatile ScheduledExecutorService executor;

    private SessionReaper() {}

    public static synchronized void start(String workDir, int retentionDays, int maxSessions) {
        if (executor != null) {
            return;
        }
        executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "session-reaper");
            t.setDaemon(true);
            return t;
        });
        executor.scheduleAtFixedRate(() -> {
            try {
                int removed = SessionManager.prune(workDir, retentionDays, maxSessions);
                if (removed > 0) {
                    log.fine("session reaper removed " + removed + " session(s)");
                }
            } catch (Exception e) {
                log.fine("Session reaper error: " + e.getMessage());
            }
        }, 60, 6 * 60 * 60, TimeUnit.SECONDS); // first run after 60s, then every 6h
    }

    static int sessionReaperRun(String workDir, int retentionDays, int maxSessions) {
        return SessionManager.prune(workDir, retentionDays, maxSessions);
    }
}
