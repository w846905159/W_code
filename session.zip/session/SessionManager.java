

package com.mewcode.session;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mewcode.conversation.ConversationManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

public class SessionManager {

    /**
     * TYPE_COMPACT_BOUNDARY marks a session record as a compaction boundary
     * rather than a plain conversation message. A boundary record's content
     * holds a JSON blob (see {@link CompactBoundary}) carrying the summary text
     * plus the recent tail (keep) preserved verbatim at compaction time. Plain
     * messages leave {@code type} null/empty, so old sessions and normal turns
     * are unaffected (append-only, backward-compatible).
     */
    public static final String TYPE_COMPACT_BOUNDARY = "compact_boundary";

    /**
     * A session record. {@code type} distinguishes record kinds: empty/null (the
     * default) means a plain conversation message; {@link #TYPE_COMPACT_BOUNDARY}
     * means {@code content} is a {@link CompactBoundary} JSON blob written by
     * {@link #saveCompactBoundary}.
     */
    public record SessionMessage(String role, String type, String content, long timestamp) {
        /** Convenience constructor for plain (non-boundary) messages. */
        public SessionMessage(String role, String content, long timestamp) {
            this(role, null, content, timestamp);
        }

        public boolean isCompactBoundary() {
            return TYPE_COMPACT_BOUNDARY.equals(type);
        }
    }

    /**
     * One verbatim message preserved in the recent tail at compaction time. Only
     * role + content text is stored, matching how the session log already
     * persists messages (text only, no tool blocks).
     */
    public record KeepMessage(String role, String content) {}

    /**
     * Structured payload stored (as JSON) in the content of a boundary record.
     * {@code summary} is the LLM-produced summary of the older prefix; {@code keep}
     * is the recent tail kept verbatim. On resume the compacted state is rebuilt
     * as: [user message = summary] + keep + any plain messages appended after the
     * boundary.
     */
    public record CompactBoundary(String summary, List<KeepMessage> keep) {}

    /** Result of {@link #findLastCompactBoundary}: the boundary and the plain messages after it. */
    public record BoundaryScan(CompactBoundary boundary, List<SessionMessage> after, boolean found) {}

    public record SessionInfo(String id, String firstMessage, int messageCount,
                              long fileSize, String gitBranch, Instant modTime) {}

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static Path sessionsDir(String workDir) {
        return Path.of(workDir, ".mewcode", "sessions");
    }

    // ---- ID generation ----

    public static String newId() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
    }

    // ---- Persistence ----

    public static void saveMessage(String workDir, String sessionId, String role, String content) {
        saveRecord(workDir, sessionId, role, null, content);
    }

    /**
     * Append a compaction boundary record so a later resume can rebuild the
     * compacted state (summary + kept tail) instead of replaying the full
     * pre-compaction transcript. Append-only: the original prefix messages stay
     * in the file but won't be replayed past this boundary (see
     * {@link #findLastCompactBoundary}). The summary + keep are inlined into the
     * record's content as a {@link CompactBoundary} JSON blob. No-op when
     * workDir/sessionId is null/blank (tests, one-shot callers).
     */
    public static void saveCompactBoundary(String workDir, String sessionId,
                                           String summary, List<KeepMessage> keep) {
        if (workDir == null || workDir.isBlank() || sessionId == null || sessionId.isBlank()) {
            return;
        }
        try {
            String blob = MAPPER.writeValueAsString(
                    new CompactBoundary(summary, keep == null ? List.of() : keep));
            saveRecord(workDir, sessionId, "system", TYPE_COMPACT_BOUNDARY, blob);
        } catch (JsonProcessingException ignored) {
            // best-effort: a failed boundary just means the next resume replays
            // verbatim, which is still correct (backward-compatible).
        }
    }

    private static void saveRecord(String workDir, String sessionId,
                                   String role, String type, String content) {
        try {
            Path baseDir = sessionsDir(workDir);
            Files.createDirectories(baseDir);
            Path file = baseDir.resolve(sessionId + ".jsonl");
            Map<String, Object> line = new LinkedHashMap<>();
            line.put("role", role);
            // omit `type` for plain messages so old readers and old sessions are
            // unaffected (matches Go's `omitempty`).
            if (type != null && !type.isEmpty()) {
                line.put("type", type);
            }
            line.put("content", content);
            line.put("ts", Instant.now().getEpochSecond());
            String json = MAPPER.writeValueAsString(line) + "\n";
            Files.writeString(file, json, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // best-effort, same as the Go version
        }
    }

    public static List<SessionMessage> loadSession(String workDir, String sessionId) {
        Path file = sessionsDir(workDir).resolve(sessionId + ".jsonl");
        if (!Files.exists(file)) {
            return List.of();
        }
        List<SessionMessage> messages = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;
                try {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> map = MAPPER.readValue(line, Map.class);
                    String role = (String) map.get("role");
                    String type = (String) map.get("type");
                    String content = (String) map.get("content");
                    long ts = map.get("ts") instanceof Number n ? n.longValue() : 0L;
                    if (content != null && !content.isEmpty()) {
                        messages.add(new SessionMessage(role, type, content, ts));
                    }
                } catch (IOException ignored) {
                    // skip malformed lines
                }
            }
        } catch (IOException ignored) {
            // return whatever we collected so far
        }
        return messages;
    }

    // ---- Compaction-boundary scanning ----

    /**
     * Scan the loaded records for the LAST compaction boundary. Returns the
     * parsed boundary plus the plain (non-boundary) messages appended after it.
     * When no boundary exists (or its blob is corrupt) {@code found} is false and
     * the caller should replay all records verbatim — backward-compatible with
     * old sessions that have no boundary records.
     */
    public static BoundaryScan findLastCompactBoundary(List<SessionMessage> messages) {
        int last = -1;
        for (int i = 0; i < messages.size(); i++) {
            if (messages.get(i).isCompactBoundary()) {
                last = i;
            }
        }
        if (last < 0) {
            return new BoundaryScan(null, List.of(), false);
        }
        CompactBoundary boundary;
        try {
            boundary = MAPPER.readValue(messages.get(last).content(), CompactBoundary.class);
        } catch (IOException e) {
            // Corrupt boundary blob — fall back to full replay rather than losing
            // the conversation.
            return new BoundaryScan(null, List.of(), false);
        }
        List<SessionMessage> after = new ArrayList<>();
        for (int i = last + 1; i < messages.size(); i++) {
            SessionMessage m = messages.get(i);
            if (m.isCompactBoundary()) continue; // defensive; we targeted the final one
            after.add(m);
        }
        return new BoundaryScan(boundary, after, true);
    }

    // ---- Conversation rebuild ----

    /**
     * Compaction-aware rebuild. If the session contains a {@code compact_boundary},
     * the live conversation is the compacted state — [summary as user message] +
     * kept tail + any plain messages appended after the boundary — and the
     * original pre-compaction prefix is NOT replayed (it stays in the file for
     * audit). Without a boundary (old sessions) everything is replayed verbatim.
     */
    public static ConversationManager rebuildConversation(List<SessionMessage> messages) {
        BoundaryScan scan = findLastCompactBoundary(messages);
        if (!scan.found()) {
            return replay(messages);
        }
        List<SessionMessage> replay = new ArrayList<>();
        // Summary becomes the leading user message with the same Chinese framing
        // as autoCompact, so the model sees a consistent context header on resume.
        String resumeSummary = "本次会话延续自之前的对话，因上下文空间不足进行了压缩。以下是早期对话的摘要：\n\n"
                + scan.boundary().summary();
        if (!scan.boundary().keep().isEmpty()) {
            resumeSummary += "\n\n近期消息已原样保留。";
        }
        replay.add(new SessionMessage("user", resumeSummary, 0L));
        for (KeepMessage k : scan.boundary().keep()) {
            replay.add(new SessionMessage(k.role(), k.content(), 0L));
        }
        replay.addAll(scan.after());
        return replay(replay);
    }

    private static ConversationManager replay(List<SessionMessage> messages) {
        ConversationManager conversation = new ConversationManager();
        for (SessionMessage msg : messages) {
            if (msg.isCompactBoundary()) continue; // never replay the raw boundary blob
            switch (msg.role()) {
                case "assistant" -> conversation.addAssistantMessage(msg.content());
                default -> conversation.addUserMessage(msg.content());
            }
        }
        return conversation;
    }

    // ---- Recycling (prune) ----

    /**
     * Remove history sessions that are too old (beyond {@code retentionDays})
     * or that exceed {@code maxSessions} (oldest dropped first). Each removed
     * session's on-disk artifacts are deleted too: its {@code .jsonl} transcript,
     * its {@code file-history/<id>} directory, and (if present) its
     * {@code .meta.json} sidecar. Returns the number of sessions removed.
     */
    public static int prune(String workDir, int retentionDays, int maxSessions) {
        Path baseDir = sessionsDir(workDir);
        if (!Files.isDirectory(baseDir)) {
            return 0;
        }
        Instant retentionCutoff = Instant.now().minus(Duration.ofDays(retentionDays));
        List<Path> files;
        try (Stream<Path> paths = Files.list(baseDir)) {
            files = paths.filter(p -> p.toString().endsWith(".jsonl"))
                    .filter(Files::isRegularFile)
                    .sorted(Comparator.comparingLong(SessionManager::mtime).reversed())
                    .toList();
        } catch (IOException e) {
            return 0;
        }

        int removed = 0;
        int kept = 0;
        for (Path file : files) {
            boolean tooOld = mtime(file) < retentionCutoff.toEpochMilli();
            boolean overCap = kept >= maxSessions;
            String id = fileNameBase(file);
            if (tooOld || overCap) {
                deleteRecursively(baseDir.resolve(id + ".jsonl"));
                deleteRecursively(Path.of(workDir, ".mewcode", "file-history", id));
                deleteRecursively(baseDir.resolve(id + ".meta.json"));
                deleteRecursively(baseDir.resolve(id + ".state.json"));
                removed++;
            } else {
                kept++;
            }
        }
        return removed;
    }

    private static String fileNameBase(Path file) {
        String n = file.getFileName().toString();
        return n.endsWith(".jsonl") ? n.substring(0, n.length() - ".jsonl".length()) : n;
    }

    private static long mtime(Path p) {
        try {
            return Files.getLastModifiedTime(p).toMillis();
        } catch (IOException e) {
            return 0L;
        }
    }

    private static void deleteRecursively(Path target) {
        if (!Files.exists(target)) {
            return;
        }
        try (Stream<Path> walk = Files.walk(target)) {
            walk.sorted(java.util.Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                }
            });
        } catch (IOException ignored) {
        }
    }

    // ---- Session meta index ----

    private record BranchCache(String branch, long expiresAtMillis) {}

    private static final Map<String, BranchCache> BRANCH_CACHE = new ConcurrentHashMap<>();
    private static final long BRANCH_TTL_MS = 5L * 60 * 1000;

    public static class SessionMeta {
        public String id;
        public String firstMessage;
        public int messageCount;
        public long fileSize;
        public String modTime;
        public String gitBranch;
    }

    /**
     * Write/refresh the lightweight {@code <id>.meta.json} sidecar so
     * {@link #listSessions} can render the resume list without full-loading
     * every session transcript. Incremental &amp; cheap: reuses the existing
     * firstMessage, increments messageCount, caches the git branch.
     */
    public static void writeMeta(String workDir, String sessionId) {
        if (workDir == null || workDir.isBlank() || sessionId == null || sessionId.isBlank()) {
            return;
        }
        try {
            Path jsonl = sessionsDir(workDir).resolve(sessionId + ".jsonl");
            if (!Files.exists(jsonl)) {
                return;
            }
            SessionMeta m = readMeta(workDir, sessionId);
            if (m == null) {
                m = new SessionMeta();
            }
            if (m.firstMessage == null || m.firstMessage.isBlank()) {
                m.firstMessage = loadSession(workDir, sessionId).stream()
                        .filter(x -> "user".equals(x.role()) && x.content() != null && !x.content().isBlank())
                        .map(SessionMessage::content)
                        .findFirst().orElse("");
            }
            if (m.messageCount > 0) {
                m.messageCount++;
            } else {
                m.messageCount = countNonEmptyLines(jsonl);
            }
            m.fileSize = Files.size(jsonl);
            m.modTime = Files.getLastModifiedTime(jsonl).toInstant().toString();
            m.gitBranch = cachedGitBranch(workDir);
            m.id = sessionId;
            Files.createDirectories(jsonl.getParent());
            MAPPER.writerWithDefaultPrettyPrinter()
                    .writeValue(sessionsDir(workDir).resolve(sessionId + ".meta.json").toFile(), m);
        } catch (Exception ignored) {
            // best-effort
        }
    }

    private static SessionMeta readMeta(String workDir, String id) {
        Path p = sessionsDir(workDir).resolve(id + ".meta.json");
        if (!Files.exists(p)) {
            return null;
        }
        try {
            return MAPPER.readValue(p.toFile(), SessionMeta.class);
        } catch (Exception e) {
            return null;
        }
    }

    private static int countNonEmptyLines(Path file) {
        if (!Files.exists(file)) {
            return 0;
        }
        int count = 0;
        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    count++;
                }
            }
        } catch (IOException ignored) {
            // best-effort
        }
        return count;
    }

    /**
     * Rewrite the session transcript to keep only the first {@code keepLines}
     * non-empty records. Used by /rewind so the on-disk conversation matches the
     * in-memory rollback (otherwise a resume replays the pre-rewind transcript).
     * Also drops the fast live-snapshot so a later resume rebuilds from the
     * truncated file. Best-effort.
     */
    public static void truncateSession(String workDir, String sessionId, int keepLines) {
        if (workDir == null || workDir.isBlank() || sessionId == null || sessionId.isBlank()) {
            return;
        }
        Path file = sessionsDir(workDir).resolve(sessionId + ".jsonl");
        // keepLines of 0 means "old snapshot lacking persistedLines metadata" —
        // never treat that as permission to wipe the whole transcript.
        if (!Files.exists(file) || keepLines <= 0) {
            return;
        }
        try {
            List<String> lines = Files.readAllLines(file);
            List<String> kept = new ArrayList<>();
            int n = 0;
            for (String line : lines) {
                if (n >= keepLines) break;
                if (line.isBlank()) continue;
                kept.add(line);
                n++;
            }
            Files.write(file, kept, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            Files.deleteIfExists(sessionsDir(workDir).resolve(sessionId + ".state.json"));
            writeMeta(workDir, sessionId);
        } catch (IOException ignored) {
            // best-effort
        }
    }

    // ---- Fast live snapshot (startup/restart acceleration) ----

    /**
     * The live (compacted) conversation state, enough to rebuild the working
     * context on resume without replaying the full pre-compaction transcript.
     */
    public record LiveState(String summary, List<KeepMessage> keep) {}

    /**
     * Persist the live conversation to {@code <id>.state.json} so a later resume
     * loads one small blob instead of replaying a huge transcript. Written at
     * compaction time; best-effort.
     */
    public static void saveLiveSnapshot(String workDir, String sessionId,
                                        String summary, List<KeepMessage> keep) {
        if (workDir == null || workDir.isBlank() || sessionId == null || sessionId.isBlank()) {
            return;
        }
        try {
            Path dir = sessionsDir(workDir);
            Files.createDirectories(dir);
            LiveState state = new LiveState(summary, keep == null ? List.of() : keep);
            MAPPER.writerWithDefaultPrettyPrinter()
                    .writeValue(dir.resolve(sessionId + ".state.json").toFile(), state);
        } catch (IOException ignored) {
            // best-effort
        }
    }

    /** Load the fast live snapshot, or null when absent/unreadable. */
    public static LiveState loadLiveSnapshot(String workDir, String sessionId) {
        if (workDir == null || workDir.isBlank() || sessionId == null || sessionId.isBlank()) {
            return null;
        }
        try {
            Path file = sessionsDir(workDir).resolve(sessionId + ".state.json");
            if (!Files.exists(file)) {
                return null;
            }
            return MAPPER.readValue(file.toFile(), LiveState.class);
        } catch (IOException e) {
            return null;
        }
    }

    private static String cachedGitBranch(String workDir) {
        long now = System.currentTimeMillis();
        BranchCache cached = BRANCH_CACHE.get(workDir);
        if (cached != null && cached.expiresAtMillis() > now) {
            return cached.branch();
        }
        String branch = currentGitBranch(workDir);
        BRANCH_CACHE.put(workDir, new BranchCache(branch, now + BRANCH_TTL_MS));
        return branch;
    }

    // ---- Listing ----

    public static List<SessionInfo> listSessions(String workDir) {        Path baseDir = sessionsDir(workDir);
        if (!Files.isDirectory(baseDir)) {
            return List.of();
        }
        String branch = currentGitBranch(workDir);
        List<SessionInfo> sessions = new ArrayList<>();
        try (Stream<Path> paths = Files.list(baseDir)) {
            paths.filter(p -> p.toString().endsWith(".jsonl"))
                 .filter(Files::isRegularFile)
                 .forEach(p -> {
                     String fileName = p.getFileName().toString();
                     String id = fileName.substring(0, fileName.length() - ".jsonl".length());
                     try {
                         long fileSize = Files.size(p);
                         Instant modTime = Files.getLastModifiedTime(p).toInstant();
                         SessionMeta meta = readMeta(workDir, id);
                         if (meta != null) {
                             // Lightweight path: trust the sidecar, no full load.
                             String first = meta.firstMessage == null ? "" : meta.firstMessage;
                             String metaBranch = meta.gitBranch == null ? "" : meta.gitBranch;
                             sessions.add(new SessionInfo(id, first, meta.messageCount,
                                     fileSize, metaBranch, safeParse(meta.modTime, modTime)));
                             return;
                         }
                         List<SessionMessage> msgs = loadSession(workDir, id);
                         String first = msgs.stream()
                                 .filter(m -> "user".equals(m.role()))
                                 .map(SessionMessage::content)
                                 .findFirst()
                                 .orElse("");
                         sessions.add(new SessionInfo(id, first, msgs.size(),
                                 fileSize, branch, modTime));
                     } catch (IOException ignored) {
                         // skip this file
                     }
                 });
        } catch (IOException ignored) {
            // return empty
        }
        sessions.sort(Comparator.comparing(SessionInfo::modTime).reversed());
        return sessions;
    }

    private static Instant safeParse(String iso, Instant fallback) {
        try {
            return iso == null || iso.isBlank() ? fallback : Instant.parse(iso);
        } catch (Exception e) {
            return fallback;
        }
    }

    // ---- Git branch ----

    public static String currentGitBranch(String workDir) {
        try {
            Process proc = new ProcessBuilder("git", "-C", workDir, "rev-parse", "--abbrev-ref", "HEAD")
                    .redirectErrorStream(true)
                    .start();
            String output = new String(proc.getInputStream().readAllBytes()).trim();
            int code = proc.waitFor();
            return code == 0 ? output : "";
        } catch (IOException | InterruptedException e) {
            return "";
        }
    }

    // ---- Formatting helpers ----

    public static String formatRelativeTime(Instant t) {
        Duration d = Duration.between(t, Instant.now());
        long seconds = d.getSeconds();
        if (seconds < 60) {
            return "just now";
        }
        long minutes = seconds / 60;
        if (minutes < 60) {
            return minutes == 1 ? "1 minute ago" : minutes + " minutes ago";
        }
        long hours = minutes / 60;
        if (hours < 24) {
            return hours == 1 ? "1 hour ago" : hours + " hours ago";
        }
        long days = hours / 24;
        if (days < 7) {
            return days == 1 ? "1 day ago" : days + " days ago";
        }
        long weeks = days / 7;
        return weeks == 1 ? "1 week ago" : weeks + " weeks ago";
    }

    public static String formatFileSize(long bytes) {
        if (bytes < 1024) {
            return bytes + "B";
        }
        if (bytes < 1024 * 1024) {
            double kb = bytes / 1024.0;
            return kb == (long) kb
                    ? String.format("%.0fKB", kb)
                    : String.format("%.1fKB", kb);
        }
        double mb = bytes / 1024.0 / 1024.0;
        return String.format("%.1fMB", mb);
    }

    // ---- Search ----

    public static boolean matchesSearch(SessionInfo s, String query) {
        if (query == null || query.isBlank()) {
            return true;
        }
        String q = query.toLowerCase();
        return s.firstMessage().toLowerCase().contains(q)
                || s.id().toLowerCase().contains(q);
    }
}
