// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.session;

/**
 * Freezes the working tree into a git commit so a later session can be resumed
 * / rolled back from a point-in-time snapshot almost instantly, instead of
 * replaying a full transcript. Best-effort: when git is unavailable or the
 * directory isn't a repository, returns {@code false} so callers fall back to
 * the always-available on-disk {@code .state.json} snapshot.
 */
public final class SessionSnapshot {

    private SessionSnapshot() {}

    /**
     * {@code git add -A} then {@code git commit --allow-empty}. Returns
     * {@code true} only when the commit succeeded.
     */
    public static boolean snapshotWorktree(String workDir, String message) {
        try {
            Process add = new ProcessBuilder("git", "-C", workDir, "add", "-A")
                    .redirectErrorStream(true).start();
            add.waitFor();

            Process commit = new ProcessBuilder("git", "-C", workDir, "commit",
                    "-m", message, "--allow-empty")
                    .redirectErrorStream(true).start();
            int code = commit.waitFor();
            return code == 0;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Create a checkpoint commit at the current state and return its full SHA.
     * Returns "" when git is unavailable or the directory isn't a repository.
     */
    public static String commitCheckpoint(String workDir, String message) {
        try {
            Process add = new ProcessBuilder("git", "-C", workDir, "add", "-A")
                    .redirectErrorStream(true).start();
            add.waitFor();
            Process commit = new ProcessBuilder("git", "-C", workDir, "commit",
                    "-m", message, "--allow-empty")
                    .redirectErrorStream(true).start();
            if (commit.waitFor() != 0) {
                return "";
            }
            Process rev = new ProcessBuilder("git", "-C", workDir, "rev-parse", "HEAD")
                    .redirectErrorStream(true).start();
            rev.waitFor();
            return new String(rev.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).trim();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Hard-reset the working tree to a checkpoint commit. This restores tracked
     * files to their state at the checkpoint and removes files/directories that
     * were added afterwards. Because the app stages everything at each checkpoint,
     * this reliably reverts both modified and newly created files. Any uncommitted
     * work is discarded (that is the point of rewinding). Returns true on success.
     */
    public static boolean restoreCheckpoint(String workDir, String hash) {
        if (workDir == null || hash == null || hash.isBlank()) {
            return false;
        }
        try {
            Process reset = new ProcessBuilder("git", "-C", workDir, "reset", "--hard", hash)
                    .redirectErrorStream(true).start();
            if (reset.waitFor() != 0) {
                return false;
            }
            Process rev = new ProcessBuilder("git", "-C", workDir, "rev-parse", "HEAD")
                    .redirectErrorStream(true).start();
            rev.waitFor();
            String head = new String(rev.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).trim();
            return head.startsWith(hash) || head.equals(hash);
        } catch (Exception e) {
            return false;
        }
    }
}
