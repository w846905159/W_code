// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.memory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mewcode.conversation.ConversationManager;
import com.mewcode.conversation.Message;
import com.mewcode.llm.LlmClient;
import com.mewcode.llm.StreamEvent;

import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.BlockingQueue;

/**
 * Owns the automatic memory lifecycle: every {@code EXTRACTION_INTERVAL}
 * turns it asks the LLM to extract facts from the conversation and classifies
 * each into one of four types. Each memory is persisted BOTH as a standalone
 * frontmatter {@code .md} file (the single source of truth) and as an entry
 * in {@code auto_memory.json}. A single {@code MEMORY.md} index (all
 * name+description lines) is kept up to date and is what the resident system
 * prompt always carries; the individual {@code .md} files are loaded on
 * demand by {@link MemoryRecall}.
 */
public class MemoryManager {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record MemoryEntry(String content, String timestamp, String type) {
        public MemoryEntry(String content, String timestamp) {
            this(content, timestamp, null);
        }
    }

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final int EXTRACTION_INTERVAL = 5;
    private static final String MEMORY_DIR = ".mewcode/memory";
    private static final String MEMORY_FILE = "auto_memory.json";
    private static final String MEMORY_INDEX = "MEMORY.md";

    // The four classification types; used to validate what the LLM returns.
    private static final Set<String> VALID_TYPES = Set.of("user", "feedback", "project", "reference");

    private final Path memoryDir;
    private final Path memoryFile;
    private List<MemoryEntry> entries = new ArrayList<>();
    private int turnCount;

    public MemoryManager(String workDir) {
        this(Path.of(workDir, MEMORY_DIR));
    }

    /** Test-only factory: keeps the unified memory dir inside the given work dir. */
    static MemoryManager forTestDir(Path workDir) {
        return new MemoryManager(workDir.resolve("test-mem"));
    }

    private MemoryManager(Path memoryDir) {
        this.memoryDir = memoryDir;
        this.memoryFile = memoryDir.resolve(MEMORY_FILE);
        load();
        writeMemoryIndex();
    }

    // ---- Directory accessors ----

    /**
     * Returns the unified memory directory where all four types live
     * alongside the {@code MEMORY.md} index.
     */
    public Path memoryDir() {
        return memoryDir;
    }

    // ---- Persistence ----

    private void load() {
        entries = new ArrayList<>();
        loadFile(memoryFile);
    }

    private void loadFile(Path path) {
        if (!Files.exists(path)) {
            return;
        }
        try {
            byte[] data = Files.readAllBytes(path);
            List<MemoryEntry> loaded = MAPPER.readValue(data, new TypeReference<List<MemoryEntry>>() {});
            entries.addAll(loaded);
        } catch (IOException ignored) {
            // best-effort: corrupt file shouldn't kill the manager
        }
    }

    private void save() {
        writeJson(memoryFile, entries);
    }

    private void writeJson(Path path, List<MemoryEntry> data) {
        try {
            Files.createDirectories(path.getParent());
            String json = MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(data);
            Files.writeString(path, json);
        } catch (IOException ignored) {
            // best-effort
        }
    }

    // ---- Accessors ----

    public List<String> getMemories() {
        return entries.stream().map(MemoryEntry::content).toList();
    }

    public boolean shouldExtract() {
        turnCount++;
        return turnCount % EXTRACTION_INTERVAL == 0;
    }

    public void clear() {
        entries = new ArrayList<>();
        writeJson(memoryFile, List.of());
        clearMdFiles(memoryDir);
        writeMemoryIndex();
    }

    private void clearMdFiles(Path dir) {
        if (!Files.isDirectory(dir)) return;
        try (var s = Files.list(dir)) {
            for (Path p : (Iterable<Path>) s.filter(Files::isRegularFile).toList()) {
                String name = p.getFileName().toString();
                // Keep the index file, drop every individual memory file.
                if (name.endsWith(".md") && !name.equals(MEMORY_INDEX)) {
                    Files.deleteIfExists(p);
                }
            }
        } catch (IOException ignored) {}
    }

    // ---- Extraction via LLM ----

    public void extract(LlmClient client, ConversationManager conv) {
        List<Message> messages = conv.getMessages();
        if (messages.size() < 4) {
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (Message msg : messages) {
            sb.append('[').append(msg.getRole()).append("]: ")
              .append(msg.getContent()).append('\n');
        }

        ConversationManager extractConv = new ConversationManager();
        extractConv.addUserMessage(
                "Extract key facts from this conversation worth remembering across future conversations. "
                        + "Classify each item into one of four types — the type decides which storage scope the item lives in:\n"
                        + "- `user` (user-level scope): the user's preferences, role, or background that applies across all projects\n"
                        + "- `feedback` (user-level scope): corrections the user gave or approaches the user validated\n"
                        + "- `project` (project-level scope): facts specific to the current project (tech stack, conventions, deadlines)\n"
                        + "- `reference` (project-level scope): external resources tied to this project (docs, dashboards)\n\n"
                        + "Discriminate carefully between what is about the USER (applies to any project or conversation) "
                        + "versus what is specific to THIS repository:\n"
                        + "  - A general preference or validated principle that helps understand the user in any project → `user` or `feedback`.\n"
                        + "  - True only for this repo / this project (tech stack, layout, deadlines, docs) → `project` or `reference`.\n"
                        + "  - One-off actions or content not worth remembering → OMIT it (do not save).\n\n"
                        + "Format your output with these exact headers — skip a category if there is nothing worth saving for it:\n\n"
                        + "### user\n- item 1\n- item 2\n\n### feedback\n- item 3\n\n### project\n- item 4\n\n### reference\n- item 5\n\n"
                        + "Output nothing else (no preamble, no explanation). If nothing is worth remembering, output the four empty headers only.\n\n"
                        + "Conversation:\n"
                        + sb
        );

        BlockingQueue<StreamEvent> events = client.stream(extractConv, null);
        StringBuilder result = new StringBuilder();
        try {
            while (true) {
                StreamEvent event = events.take();
                if (event instanceof StreamEvent.TextDelta td) {
                    result.append(td.text());
                } else if (event instanceof StreamEvent.StreamEnd || event instanceof StreamEvent.Error) {
                    break;
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        if (result.isEmpty()) {
            return;
        }

        Map<String, String> bySection = parseTypedSections(result.toString());
        if (bySection.isEmpty()) {
            return;
        }
        String now = DateTimeFormatter.ISO_INSTANT.format(Instant.now());
        boolean changed = false;
        for (Map.Entry<String, String> section : bySection.entrySet()) {
            String type = section.getKey();
            String content = section.getValue().trim();
            if (content.isEmpty()) {
                continue;
            }
            if (!VALID_TYPES.contains(type)) {
                // Unknown type → drop. Avoid silently filing it under a type the
                // LLM might be hallucinating.
                continue;
            }
            entries.add(new MemoryEntry(content, now, type));
            changed = true;
            // Single source of truth: persist as a frontmatter .md file too.
            String desc = content.length() > 60 ? content.substring(0, 60) + "…" : content;
            ingest(type, desc, content);
        }
        if (changed) {
            save();
            writeMemoryIndex();
        }
    }

    // parseTypedSections groups lines under `### <type>` headers into a type → body map.
    // Only contiguous lines that follow a known header end up in that section; anything
    // before the first header is ignored. Case-insensitive on the type name; trims to a
    // single canonical lowercase form so the caller can compare against VALID_TYPES.
    static Map<String, String> parseTypedSections(String text) {
        Map<String, String> out = new LinkedHashMap<>();
        String currentType = null;
        StringBuilder buf = new StringBuilder();
        for (String line : text.split("\n", -1)) {
            String trimmed = line.trim();
            if (trimmed.startsWith("### ")) {
                if (currentType != null) {
                    String body = buf.toString().trim();
                    if (!body.isEmpty()) {
                        out.merge(currentType, body, (a, b) -> a + "\n" + b);
                    }
                }
                currentType = trimmed.substring(4).trim().toLowerCase(Locale.ROOT);
                buf.setLength(0);
            } else if (currentType != null) {
                buf.append(line).append('\n');
            }
        }
        if (currentType != null) {
            String body = buf.toString().trim();
            if (!body.isEmpty()) {
                out.merge(currentType, body, (a, b) -> a + "\n" + b);
            }
        }
        return out;
    }

    // ---- Injection ----

    public void injectMemories(ConversationManager conv) {
        List<String> memories = getMemories();
        if (memories.isEmpty()) {
            return;
        }

        StringBuilder sb = new StringBuilder("## Auto Memory\n\n");
        for (String mem : memories) {
            sb.append(mem).append("\n\n");
        }

        if (conv.getMessages().isEmpty()) {
            conv.addUserMessage(sb.toString());
            conv.addAssistantMessage("Understood, I'll keep this context in mind.");
        }
    }

    // ---- Custom instructions ----

    public static String loadInstructions(String workDir) {
        List<Path> candidates = List.of(
                Path.of(workDir, "MEWCODE.md"),
                Path.of(workDir, ".mewcode", "INSTRUCTIONS.md")
        );
        for (Path p : candidates) {
            try {
                return Files.readString(p);
            } catch (IOException ignored) {
                // try next
            }
        }
        return "";
    }

    // ── Single-source-of-truth .md memory files ──────────────────────

    /**
     * Write one memory item as a frontmatter .md file (with a `name`
     * identity, a `description`, and a `type`) into the given scope
     * directory. The description is what makes the memory retrievable.
     *
     * @return the written file path, or {@code null} if the write failed
     */
    public Path writeMemoryMd(Path scopeDir, String type, String description, String content) {
        try {
            Files.createDirectories(scopeDir);
            String stamp = java.time.LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS")) + "-" + (type == null ? "mem" : type);
            Path file = scopeDir.resolve(stamp + ".md");
            StringBuilder sb = new StringBuilder("---\n");
            if (type != null && !type.isEmpty()) {
                sb.append("type: ").append(type).append('\n');
            }
            sb.append("name: ").append(buildName(type, description)).append('\n');
            if (description != null && !description.isEmpty()) {
                sb.append("description: \"").append(description.replace("\"", "'")).append("\"\n");
            }
            sb.append("---\n\n").append(content == null ? "" : content).append('\n');
            Files.writeString(file, sb.toString());
            return file;
        } catch (IOException ignored) {
            return null;
        }
    }

    /**
     * Derive a stable identity slug for a memory from its type + description.
     * Falls back to a type-based name when the description has no usable
     * ASCII words (e.g. fully non-ASCII text).
     */
    static String buildName(String type, String description) {
        String base = slugify(description);
        if (base.isEmpty() || base.isBlank()) {
            base = "memory";
        }
        String t = (type == null || type.isEmpty()) ? "mem" : type;
        return t + "-" + base;
    }

    /** Lowercase, keep [a-z0-9-], collapse separators, trim to ~5 tokens / 60 chars. */
    private static String slugify(String text) {
        if (text == null) return "";
        String lower = text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-")
                .replaceAll("^-+|-+$", "");
        if (lower.isEmpty()) return "";
        return lower.length() > 60 ? lower.substring(0, 60).replaceAll("-+$", "") : lower;
    }

    /**
     * Ingest a memory item as a single-source-of-truth .md file into the
     * unified memory directory. Returns the written path, or {@code null}
     * on failure.
     */
    public Path ingest(String type, String description, String content) {
        return writeMemoryMd(memoryDir, type, description, content);
    }

    // ── MEMORY.md index ────────────────────────────────────────────────

    /**
     * Builds the MEMORY.md index content: a compact manifest of every memory's
     * name + description + type. This is the "always resident" piece that the
     * system prompt carries so the model knows what memories exist; the actual
     * memories are then loaded on demand via recall.
     */
    private String buildIndexContent() {
        List<MemoryScanner.MemoryHeader> all =
                MemoryScanner.scanMemoryFiles(memoryDir, "all");
        if (all.isEmpty()) return "";
        return "# Auto Memory Index\n\n"
                + MemoryScanner.formatMemoryManifest(all)
                + "\n";
    }

    /**
     * (Re)writes the {@code MEMORY.md} index to disk from the current memory
     * files. Called on startup and after every write so the index stays in
     * sync with the standalone memory files.
     */
    public void writeMemoryIndex() {
        String content = buildIndexContent();
        try {
            Files.createDirectories(memoryDir);
            Files.writeString(memoryDir.resolve(MEMORY_INDEX), content);
        } catch (IOException ignored) {
            // best-effort
        }
    }

    /**
     * Returns the current MEMORY.md index content (name + description + type
     * for every memory), for residency in the system prompt. Empty if there
     * are no memories yet.
     */
    public String getMemoryIndexContent() {
        return buildIndexContent();
    }
}
