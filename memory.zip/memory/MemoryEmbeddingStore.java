package com.mewcode.memory;

import com.mewcode.rag.embedding.EmbeddingService;
import com.mewcode.rag.model.Chunk;
import com.mewcode.rag.model.Source;
import com.mewcode.rag.store.LuceneVectorStore;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Vector index over memory files, backed by LuceneVectorStore. Reused by
 * MemoryRecall as the cheap first-stage prefilter (top-K), before the LLM
 * selector makes the final relevance pick. Best-effort; never throws into
 * the caller's main flow.
 */
public class MemoryEmbeddingStore implements AutoCloseable {

    public record MemoryHit(String filePath, String content) {}

    private final LuceneVectorStore store;
    private final EmbeddingService embedding;

    public MemoryEmbeddingStore(Path indexDir, EmbeddingService embedding) {
        this.store = new LuceneVectorStore(indexDir);
        this.embedding = embedding;
    }

    public void initialize() throws Exception {
        store.initialize();
    }

    /** Index one memory file as a single chunk keyed by its filePath. */
    public void indexMemory(String filePath, String scope, String type, String text) throws Exception {
        Source src = new Source("memory", filePath, type);
        long sid = store.insertSource(src);
        float[] vec = embedding.embed(text);
        Map<String, Object> meta = Map.of(
                "file_path", filePath == null ? "" : filePath,
                "scope", scope == null ? "" : scope,
                "type", type == null ? "" : type);
        Chunk c = new Chunk(sid, 0, text == null ? "" : text, meta);
        c.setEmbedding(vec);
        store.insertChunk(c);
    }

    /** Remove any previously indexed source (and its chunks) for this path. */
    public void deleteByPath(String filePath) throws Exception {
        if (filePath == null) return;
        for (var s : store.listSources()) {
            if (filePath.equals(s.getPath())) {
                store.deleteSource(s.getId());
            }
        }
    }

    /**
     * Upsert one memory file by path: evict any stale entry for the same
     * path first, then index fresh. Keeps the index duplicate-free even if
     * the file is re-embedded across incremental refreshes or sessions.
     */
    public void upsertMemory(String filePath, String scope, String type, String text) throws Exception {
        deleteByPath(filePath);
        indexMemory(filePath, scope, type, text);
    }

    /** Cosine top-K over all indexed memories, ordered by relevance. */
    public List<MemoryHit> searchTopK(String query, int k) throws Exception {
        float[] q = embedding.embed(query);
        List<Chunk> chunks = store.search(q, k);
        List<MemoryHit> out = new ArrayList<>();
        for (Chunk c : chunks) {
            if (c.getMetadata() == null) continue;
            Object fp = c.getMetadata().get("file_path");
            out.add(new MemoryHit(fp == null ? "" : String.valueOf(fp), c.getContent()));
        }
        return out;
    }

    @Override
    public void close() throws Exception {
        store.close();
    }
}
