// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.memory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Query-time memory recall: scans the (single, unified) memory directory,
 * asks a selector LLM to pick up to 5 relevant memory NAMES from a manifest
 * of name + description, and returns the corresponding paths + mtimes so the
 * caller can read full contents and inject them as a system-reminder.
 *
 * <p>Recall is deliberately vetor-free: the manifest's one-line descriptions
 * are what the selector uses to judge relevance, and already-surfaced
 * memories are excluded so nothing is re-injected across turns.
 */
public final class MemoryRecall {

    private MemoryRecall() {}

    private static final ObjectMapper MAPPER = new ObjectMapper();

    // ── Selector system prompt ─────────────────────────────────────────

    public static final String SELECTOR_SYSTEM_PROMPT = """
            You are selecting memories that will be useful to MewCode as it processes a user's query. \
            You will be given the user's query and a list of available memories, each shown as their \
            name and a one-line description.

            Return a list of memory NAMES for the memories that will clearly be useful to MewCode as it \
            processes the user's query (up to 5). Only include memories that you are certain will be \
            helpful based on their name and description.
            - If you are unsure if a memory will be useful in processing the user's query, then do not \
            include it in your list. Be selective and discerning.
            - If there are no memories in the list that would clearly be useful, feel free to return an empty list.
            - If a list of recently-used tools is provided, do not select memories that are usage reference \
            or API documentation for those tools (MewCode is already exercising them). DO still select \
            memories containing warnings, gotchas, or known issues about those tools — active use is exactly \
            when those matter.

            Respond with valid JSON only, no markdown, in this exact shape: \
            {"selected_memories": ["name1", "name2"]}""";

    // ── Result record ──────────────────────────────────────────────────

    /**
     * One memory file selected for surfacing into the main conversation.
     * {@code mtimeMs} is threaded through so callers can render freshness
     * without a second stat.
     */
    public record RelevantMemory(String path, long mtimeMs) {}

    // ── Selector function interface ────────────────────────────────────

    /**
     * Abstraction for the side-query LLM call used by the recall selector.
     * Given a system prompt and a user message, the caller stands up a
     * dedicated side-query client and returns the raw assistant text.
     * Errors are treated as "selector failed -> no recall".
     */
    @FunctionalInterface
    public interface SelectorFn {
        String select(String systemPrompt, String userMessage) throws Exception;
    }

    // ── Main entry point ───────────────────────────────────────────────

    /**
     * Scans the unified memory directory, filters already-surfaced memories,
     * asks the selector to pick up to 5 relevant NAMES, and returns the
     * corresponding absolute paths + mtimes.
     *
     * @param query           the user's query text
     * @param memoryDir       the unified memory directory (may be null)
     * @param recentTools     recently-used tool names (may be null)
     * @param alreadySurfaced names/paths shown in prior turns (may be null)
     * @param selector        the side-query function
     * @return selected memories; empty list on any failure
     */
    public static List<RelevantMemory> findRelevantMemories(
            String query,
            Path memoryDir,
            List<String> recentTools,
            Set<String> alreadySurfaced,
            SelectorFn selector) {
        if (selector == null || memoryDir == null) return List.of();

        List<MemoryScanner.MemoryHeader> all =
                MemoryScanner.scanMemoryFiles(memoryDir, "all");

        // Exclude memories already surfaced in prior turns.
        Set<String> surfaced = alreadySurfaced != null ? alreadySurfaced : Set.of();
        List<MemoryScanner.MemoryHeader> candidates = new ArrayList<>();
        for (var m : all) {
            if (!surfaced.contains(m.name()) && !surfaced.contains(m.filePath())) {
                candidates.add(m);
            }
        }
        if (candidates.isEmpty()) return List.of();

        List<String> selectedNames = selectRelevantMemories(query, candidates, recentTools, selector);

        return buildResults(selectedNames, candidates);
    }

    /**
     * Maps selected memory names onto candidate {@link MemoryHeader}s
     * (matching by name, then absolute path, then filename), returning one
     * {@link RelevantMemory} per match. Path + mtime are preserved for
     * freshness rendering.
     */
    public static List<RelevantMemory> buildResults(
            List<String> selectedNames, List<MemoryScanner.MemoryHeader> candidates) {
        if (selectedNames == null || selectedNames.isEmpty()) return List.of();
        Map<String, MemoryScanner.MemoryHeader> byKey = new HashMap<>();
        for (var m : candidates) {
            byKey.put(m.name(), m);
            byKey.putIfAbsent(m.filePath(), m);
            byKey.putIfAbsent(m.filename(), m);
        }
        List<RelevantMemory> result = new ArrayList<>();
        for (String name : selectedNames) {
            var m = byKey.get(name);
            if (m != null) {
                result.add(new RelevantMemory(m.filePath(), m.mtimeMs()));
            }
        }
        return result;
    }

    // ── Selector logic ─────────────────────────────────────────────────

    private static List<String> selectRelevantMemories(
            String query,
            List<MemoryScanner.MemoryHeader> memories,
            List<String> recentTools,
            SelectorFn selector) {

        Set<String> validNames = new HashSet<>();
        for (var m : memories) {
            validNames.add(m.name());
        }

        String manifest = MemoryScanner.formatMemoryManifest(memories);

        String toolsSection = "";
        if (recentTools != null && !recentTools.isEmpty()) {
            toolsSection = "\n\nRecently used tools: " + String.join(", ", recentTools);
        }

        String userMessage = "Query: " + query + "\n\nAvailable memories:\n" + manifest + toolsSection;

        String raw;
        try {
            raw = selector.select(SELECTOR_SYSTEM_PROMPT, userMessage);
        } catch (Exception e) {
            return List.of();
        }

        String clean = extractJsonObject(raw);
        if (clean.isEmpty()) return List.of();

        try {
            JsonNode root = MAPPER.readTree(clean);
            JsonNode arr = root.get("selected_memories");
            if (arr == null || !arr.isArray()) return List.of();

            List<String> out = new ArrayList<>();
            for (JsonNode node : arr) {
                String f = node.asText();
                if (validNames.contains(f)) {
                    out.add(f);
                }
            }
            return out;
        } catch (Exception e) {
            return List.of();
        }
    }

    /**
     * Returns the first {@code {...}} substring found in raw, or the raw
     * text trimmed if it already starts with '{'. Tolerates markdown
     * fences or prose around the JSON despite the prompt.
     */
    static String extractJsonObject(String raw) {
        if (raw == null) return "";
        String trimmed = raw.trim();
        if (trimmed.startsWith("{")) return trimmed;
        int start = trimmed.indexOf('{');
        if (start < 0) return "";
        int end = trimmed.lastIndexOf('}');
        if (end < start) return "";
        return trimmed.substring(start, end + 1);
    }

    // ── Reminder rendering ─────────────────────────────────────────────

    /**
     * Reads each selected memory file's full content and formats a single
     * system-reminder body with freshness headers.
     *
     * @param memories the selected memories from {@link #findRelevantMemories}
     * @return rendered reminder text, or "" if none
     */
    public static String renderReminder(List<RelevantMemory> memories) {
        if (memories == null || memories.isEmpty()) return "";

        var sb = new StringBuilder();
        sb.append("The following relevant memories from prior conversations may help:\n\n");
        for (var mem : memories) {
            String content;
            try {
                content = Files.readString(Path.of(mem.path()));
            } catch (IOException e) {
                continue; // skip unreadable files
            }
            String basename = Path.of(mem.path()).getFileName().toString();
            sb.append("## Memory: ").append(basename)
              .append(" (saved ").append(MemoryAge.age(mem.mtimeMs())).append(")\n\n");
            String note = MemoryAge.freshnessText(mem.mtimeMs());
            if (!note.isEmpty()) {
                sb.append(note).append("\n\n");
            }
            sb.append(content).append("\n\n---\n\n");
        }
        return sb.toString();
    }
}
