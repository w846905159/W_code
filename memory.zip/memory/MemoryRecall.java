// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package com.mewcode.memory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mewcode.rag.embedding.EmbeddingService;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.IntStream;

/**
 * Query-time memory recall: scans both user- and project-level memory
 * directories, asks a selector LLM to pick up to 5 relevant filenames,
 * and returns the corresponding paths + mtimes so the caller can read
 * full contents and inject them as a system-reminder.
 */
public final class MemoryRecall {

    private MemoryRecall() {}

    private static final ObjectMapper MAPPER = new ObjectMapper();

    // ── Selector system prompt ─────────────────────────────────────────

    public static final String SELECTOR_SYSTEM_PROMPT = """
            You are selecting memories that will be useful to MewCode as it processes a user's query. \
            You will be given the user's query and a list of available memory files with their filenames and descriptions.

            Return a list of filenames for the memories that will clearly be useful to MewCode as it \
            processes the user's query (up to 5). Only include memories that you are certain will be \
            helpful based on their name and description.
            - If you are unsure if a memory will be useful in processing the user's query, then do not \
            include it in your list. Be selective and discerning.
            - If there are no memories in the list that would clearly be useful, feel free to return an empty list.
            - If a list of recently-used tools is provided, do not select memories that are usage reference \
            or API documentation for those tools (MewCode is already exercising them). DO still select \
            memories containing warnings, gotchas, or known issues about those tools — active use is exactly \
            when those matter.

            Respond with valid JSON only, no markdown, in this exact shape: \
            {"selected_memories": ["filename1.md", "filename2.md"]}""";

    // ── Result record ──────────────────────────────────────────────────

    /**
     * One memory file selected for surfacing into the main conversation.
     * {@code mtimeMs} is threaded through so callers can render freshness
     * without a second stat.
     */
    public record RelevantMemory(String path, long mtimeMs) {}

    // ── Selector function interface ────────────────────────────────────

    /**
     * Abstraction for the side-query LLM call used by the recall selector.
     * Given a system prompt and a user message, the caller stands up a
     * dedicated side-query client and returns the raw assistant text.
     * Errors are treated as "selector failed -> no recall".
     */
    @FunctionalInterface
    public interface SelectorFn {
        String select(String systemPrompt, String userMessage) throws Exception;
    }

    // ── Main entry point ───────────────────────────────────────────────

    private static final int EMBEDDING_PREFILTER_TOP_K = 50;

    /**
     * Scans both directories, filters already-surfaced paths, asks the
     * selector to pick up to 5 relevant filenames, and returns the
     * corresponding absolute paths + mtimes.
     *
     * @param query            the user's query text
     * @param userMemDir       user-level memory dir (may be null)
     * @param projectMemDir    project-level memory dir (may be null)
     * @param recentTools      recently-used tool names (may be null)
     * @param alreadySurfaced  paths shown in prior turns (may be null)
     * @param selector         the side-query function
     * @return selected memories; empty list on any failure
     */
    public static List<RelevantMemory> findRelevantMemories(
            String query,
            Path userMemDir,
            Path projectMemDir,
            List<String> recentTools,
            Set<String> alreadySurfaced,
            SelectorFn selector) {
        return findRelevantMemories(query, userMemDir, projectMemDir,
                recentTools, alreadySurfaced, selector, null);
    }

    /**
     * Two-stage recall: {@code embeddingService} provides vector pre-filtering
     * (top-20 candidates by cosine similarity), then the LLM selector makes the
     * final pick from those. When {@code embeddingService} is null, falls back
     * to the original single-stage selector-only behaviour.
     */
    public static List<RelevantMemory> findRelevantMemories(
            String query,
            Path userMemDir,
            Path projectMemDir,
            List<String> recentTools,
            Set<String> alreadySurfaced,
            SelectorFn selector,
            EmbeddingService embeddingService) {
        return findRelevantMemories(query, userMemDir, projectMemDir, recentTools,
                alreadySurfaced, selector, embeddingService, null);
    }

    /**
     * Two-stage recall with an optional persistent vector index: when
     * {@code memoryStore} is non-null it supplies the top-K candidate
     * prefilter; otherwise {@code embeddingService} does a per-call embedding
     * prefilter; either way the LLM selector makes the final relevance pick.
     */
    public static List<RelevantMemory> findRelevantMemories(
            String query,
            Path userMemDir,
            Path projectMemDir,
            List<String> recentTools,
            Set<String> alreadySurfaced,
            SelectorFn selector,
            EmbeddingService embeddingService,
            MemoryEmbeddingStore memoryStore) {
        return findRelevantMemories(query, userMemDir, projectMemDir, recentTools,
                alreadySurfaced, selector, embeddingService, memoryStore, false);
    }

    /**
     * Two-stage recall with an optional persistent vector index: when
     * {@code memoryStore} is non-null it supplies the top-K candidate
     * prefilter; otherwise {@code embeddingService} does a per-call embedding
     * prefilter; either way the LLM selector makes the final relevance pick.
     *
     * @param excludeCoreUser when true, drops {@code user}-type memories from
     *                        the candidate pool so the on-demand recall never
     *                        repeats the already-resident core (user) memories.
     */
    public static List<RelevantMemory> findRelevantMemories(
            String query,
            Path userMemDir,
            Path projectMemDir,
            List<String> recentTools,
            Set<String> alreadySurfaced,
            SelectorFn selector,
            EmbeddingService embeddingService,
            MemoryEmbeddingStore memoryStore,
            boolean excludeCoreUser) {

        if (selector == null) return List.of();

        List<MemoryScanner.MemoryHeader> all = new ArrayList<>();
        if (userMemDir != null) {
            all.addAll(MemoryScanner.scanMemoryFiles(userMemDir, "user"));
        }
        if (projectMemDir != null) {
            all.addAll(MemoryScanner.scanMemoryFiles(projectMemDir, "project"));
        }

        // Filter already-surfaced memories and, optionally, core (user) memories.
        Set<String> surfaced = alreadySurfaced != null ? alreadySurfaced : Set.of();
        List<MemoryScanner.MemoryHeader> candidates = new ArrayList<>();
        for (var m : all) {
            if (excludeCoreUser && "user".equals(m.type())) continue;
            if (!surfaced.contains(m.filePath())) {
                candidates.add(m);
            }
        }
        if (candidates.isEmpty()) return List.of();

        // Stage 1: vector prefilter (persistent index preferred; else embedding service).
        List<MemoryScanner.MemoryHeader> stageCandidates = candidates;
        if (memoryStore != null) {
            stageCandidates = vectorPrefilter(memoryStore, query, candidates, EMBEDDING_PREFILTER_TOP_K);
        } else if (embeddingService != null && candidates.size() > EMBEDDING_PREFILTER_TOP_K) {
            List<String> searchTexts = candidates.stream()
                    .map(MemoryRecall::buildSearchText)
                    .toList();
            List<MemoryScanner.MemoryHeader> ranked =
                    rankByEmbedding(query, searchTexts, candidates, embeddingService, EMBEDDING_PREFILTER_TOP_K);
            if (!ranked.isEmpty()) {
                stageCandidates = ranked;
            }
        }

        List<String> selectedFilenames = selectRelevantMemories(
                query, stageCandidates, recentTools, selector);

        // Map selected filenames back to header paths + mtimes.
        return buildResults(selectedFilenames, candidates);
    }

    /**
     * Uses the persistent memory vector index to shortlist top-K candidate
     * headers. Falls back to the full candidate list on any failure.
     */
    static List<MemoryScanner.MemoryHeader> vectorPrefilter(
            MemoryEmbeddingStore store, String query,
            List<MemoryScanner.MemoryHeader> candidates, int topK) {
        try {
            Set<String> hitPaths = store.searchTopK(query, topK).stream()
                    .map(MemoryEmbeddingStore.MemoryHit::filePath)
                    .collect(java.util.stream.Collectors.toSet());
            return candidates.stream()
                    .filter(m -> m.filePath() != null && hitPaths.contains(m.filePath()))
                    .toList();
        } catch (Exception e) {
            return candidates;
        }
    }

    /**
     * Maps selected filenames onto candidate {@link MemoryHeader}s (matching
     * by absolute path, then filename), returning one {@link RelevantMemory}
     * per match. Path + mtime are preserved for freshness rendering.
     */
    public static List<RelevantMemory> buildResults(
            List<String> selectedFilenames, List<MemoryScanner.MemoryHeader> candidates) {
        if (selectedFilenames == null || selectedFilenames.isEmpty()) return List.of();
        Map<String, MemoryScanner.MemoryHeader> byKey = new HashMap<>();
        for (var m : candidates) {
            byKey.put(m.filePath(), m);
            byKey.putIfAbsent(m.filename(), m);
        }
        List<RelevantMemory> result = new ArrayList<>();
        for (String fn : selectedFilenames) {
            var m = byKey.get(fn);
            if (m != null) {
                result.add(new RelevantMemory(m.filePath(), m.mtimeMs()));
            }
        }
        return result;
    }

    /**
     * Builds a search text for embedding from a memory header.
     * Combines scope, type, filename, and description into a single string
     * that the embedding model can compare against the user's query.
     */
    private static String buildSearchText(MemoryScanner.MemoryHeader m) {
        var sb = new StringBuilder();
        if (m.scope() != null && !m.scope().isEmpty()) {
            sb.append('[').append(m.scope()).append("] ");
        }
        if (m.type() != null && !m.type().isEmpty()) {
            sb.append('[').append(m.type()).append("] ");
        }
        sb.append(m.filename());
        if (m.description() != null && !m.description().isEmpty()) {
            sb.append(": ").append(m.description());
        }
        return sb.toString();
    }

    /**
     * Ranks memory header candidates by cosine similarity between the query
     * and each candidate's search text, returning the top-K headers.
     * <p>
     * Uses the existing RAG {@link EmbeddingService} interface (embedBatch).
     * Falls back to the full candidate list on any embedding failure so the
     * recall pipeline degrades gracefully.
     */
    static List<MemoryScanner.MemoryHeader> rankByEmbedding(
            String query,
            List<String> searchTexts,
            List<MemoryScanner.MemoryHeader> candidates,
            EmbeddingService svc,
            int topK) {
        try {
            float[] queryVec = svc.embed(query);
            if (queryVec == null) return candidates;

            List<float[]> vecs = svc.embedBatch(searchTexts);
            if (vecs.size() != searchTexts.size()) return candidates;

            List<RankedEntry> scored = new ArrayList<>(searchTexts.size());
            for (int i = 0; i < vecs.size(); i++) {
                double sim = cosineSimilarity(queryVec, vecs.get(i));
                scored.add(new RankedEntry(i, sim));
            }

            scored.sort((a, b) -> Double.compare(b.score, a.score));
            int k = Math.min(topK, scored.size());
            return IntStream.range(0, k)
                    .mapToObj(i -> candidates.get(scored.get(i).index))
                    .toList();
        } catch (Exception e) {
            return candidates;
        }
    }

    private record RankedEntry(int index, double score) {}

    private static double cosineSimilarity(float[] a, float[] b) {
        if (a == null || b == null || a.length != b.length) return 0;
        double dot = 0, normA = 0, normB = 0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        double denom = Math.sqrt(normA) * Math.sqrt(normB);
        return denom == 0 ? 0 : dot / denom;
    }

    // ── Selector logic ─────────────────────────────────────────────────

    private static List<String> selectRelevantMemories(
            String query,
            List<MemoryScanner.MemoryHeader> memories,
            List<String> recentTools,
            SelectorFn selector) {

        Set<String> validFilenames = new HashSet<>();
        for (var m : memories) {
            validFilenames.add(m.filename());
        }

        String manifest = MemoryScanner.formatMemoryManifest(memories);

        String toolsSection = "";
        if (recentTools != null && !recentTools.isEmpty()) {
            toolsSection = "\n\nRecently used tools: " + String.join(", ", recentTools);
        }

        String userMessage = "Query: " + query + "\n\nAvailable memories:\n" + manifest + toolsSection;

        String raw;
        try {
            raw = selector.select(SELECTOR_SYSTEM_PROMPT, userMessage);
        } catch (Exception e) {
            return List.of();
        }

        String clean = extractJsonObject(raw);
        if (clean.isEmpty()) return List.of();

        try {
            JsonNode root = MAPPER.readTree(clean);
            JsonNode arr = root.get("selected_memories");
            if (arr == null || !arr.isArray()) return List.of();

            List<String> out = new ArrayList<>();
            for (JsonNode node : arr) {
                String f = node.asText();
                if (validFilenames.contains(f)) {
                    out.add(f);
                }
            }
            return out;
        } catch (Exception e) {
            return List.of();
        }
    }

    /**
     * Returns the first {@code {...}} substring found in raw, or the raw
     * text trimmed if it already starts with '{'. Tolerates markdown
     * fences or prose around the JSON despite the prompt.
     */
    static String extractJsonObject(String raw) {
        if (raw == null) return "";
        String trimmed = raw.trim();
        if (trimmed.startsWith("{")) return trimmed;
        int start = trimmed.indexOf('{');
        if (start < 0) return "";
        int end = trimmed.lastIndexOf('}');
        if (end < start) return "";
        return trimmed.substring(start, end + 1);
    }

    // ── Reminder rendering ─────────────────────────────────────────────

    /**
     * Reads each selected memory file's full content and formats a single
     * system-reminder body with freshness headers.
     *
     * @param memories the selected memories from {@link #findRelevantMemories}
     * @return rendered reminder text, or "" if none
     */
    public static String renderReminder(List<RelevantMemory> memories) {
        if (memories == null || memories.isEmpty()) return "";

        var sb = new StringBuilder();
        sb.append("The following relevant memories from prior conversations may help:\n\n");
        for (var mem : memories) {
            String content;
            try {
                content = Files.readString(Path.of(mem.path()));
            } catch (IOException e) {
                continue; // skip unreadable files
            }
            String basename = Path.of(mem.path()).getFileName().toString();
            sb.append("## Memory: ").append(basename)
              .append(" (saved ").append(MemoryAge.age(mem.mtimeMs())).append(")\n\n");
            String note = MemoryAge.freshnessText(mem.mtimeMs());
            if (!note.isEmpty()) {
                sb.append(note).append("\n\n");
            }
            sb.append(content).append("\n\n---\n\n");
        }
        return sb.toString();
    }
}
