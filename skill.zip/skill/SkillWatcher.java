package com.mewcode.skill;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Watches the skill directories for structural changes (skills added / removed)
 * and reconciles the in-memory {@link SkillCatalog} with the disk.
 * <p>
 * Directory trees are registered recursively so events also fire when a skill
 * directory is created and then populated. Events are debounced so a burst of
 * file writes collapses into a single reconcile. The body of a skill is re-read
 * from disk on every {@link SkillCatalog#getFull} call, so edits to skill files
 * do not require a watcher event to take effect.
 */
public class SkillWatcher implements AutoCloseable {

    /** Callback fired (on the watcher scheduler thread) after a reconcile. */
    public interface Listener {
        void onSkillChanges(List<String> added, List<String> removed);
    }

    private static final long DEBOUNCE_MS = 300;
    private static final long POLL_TIMEOUT_MS = 1000;

    private final SkillCatalog catalog;
    private final String workDir;
    private final WatchService watchService;
    private final Listener listener;
    private final Map<WatchKey, Path> keyToDir = new ConcurrentHashMap<>();
    private final Set<Path> roots = ConcurrentHashMap.newKeySet();
    private final Set<Path> dirtyRoots = ConcurrentHashMap.newKeySet();
    private final ScheduledExecutorService scheduler;
    private volatile boolean running;
    private boolean reconcileScheduled;

    public SkillWatcher(SkillCatalog catalog, String workDir, Listener listener) {
        this.catalog = catalog;
        this.workDir = workDir;
        this.listener = listener;
        try {
            this.watchService = FileSystems.getDefault().newWatchService();
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to create skill watcher", e);
        }
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "skill-watcher");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * The two skill tiers that are watched: the user-global directory followed
     * by the project directory (project overrides user by name).
     */
    public List<Path> watchRoots() {
        List<Path> dirs = new ArrayList<>();
        String home = System.getProperty("user.home");
        if (home != null && !home.isBlank()) {
            dirs.add(Path.of(home, ".mewcode", "skills"));
        }
        if (workDir != null && !workDir.isBlank()) {
            dirs.add(Path.of(workDir, ".mewcode", "skills"));
        }
        return dirs;
    }

    public void start() {
        running = true;
        registerRoots();
        Thread.ofVirtual().name("skill-watcher-loop").start(this::loop);
    }

    private void registerRoots() {
        for (Path root : watchRoots()) {
            roots.add(root);
            try {
                registerTree(root);
            } catch (IOException ignored) {
            }
        }
    }

    private void registerTree(Path dir) throws IOException {
        if (!Files.isDirectory(dir)) {
            return;
        }
        registerDir(dir);
        try (var walk = Files.walk(dir)) {
            walk.filter(Files::isDirectory).skip(1)
                    .forEach(d -> {
                        try {
                            registerDir(d);
                        } catch (IOException ignored) {
                        }
                    });
        }
    }

    private void registerDir(Path dir) throws IOException {
        WatchKey key = dir.register(watchService,
                StandardWatchEventKinds.ENTRY_CREATE,
                StandardWatchEventKinds.ENTRY_DELETE,
                StandardWatchEventKinds.ENTRY_MODIFY);
        keyToDir.put(key, dir);
    }

    private void loop() {
        while (running) {
            WatchKey key;
            try {
                key = watchService.poll(POLL_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            if (key == null) {
                continue;
            }
            Path dir = keyToDir.get(key);
            for (WatchEvent<?> event : key.pollEvents()) {
                if (event.kind() == StandardWatchEventKinds.OVERFLOW) {
                    continue;
                }
                Object ctx = event.context();
                Path child = (ctx instanceof Path p && dir != null) ? dir.resolve(p) : dir;
                if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE
                        && ctx instanceof Path && child != null && Files.isDirectory(child)) {
                    try {
                        registerTree(child);
                    } catch (IOException ignored) {
                    }
                }
                markDirty(child);
            }
            if (!key.reset()) {
                keyToDir.remove(key);
            }
        }
    }

    private void markDirty(Path path) {
        for (Path root : roots) {
            if (path == null || path.startsWith(root) || root.startsWith(path)) {
                dirtyRoots.add(root);
            }
        }
        scheduleReconcile();
    }

    private void scheduleReconcile() {
        boolean first;
        synchronized (this) {
            if (reconcileScheduled) {
                return;
            }
            reconcileScheduled = true;
            first = true;
        }
        if (first) {
            scheduler.schedule(this::reconcile, DEBOUNCE_MS, TimeUnit.MILLISECONDS);
        }
    }

    private void reconcile() {
        synchronized (this) {
            reconcileScheduled = false;
        }
        Set<Path> dirty = new HashSet<>(dirtyRoots);
        dirtyRoots.clear();
        if (dirty.isEmpty()) {
            return;
        }
        try {
            SkillCatalog.SkillChanges changes = catalog.reconcileAll(workDir);
            if (listener != null
                    && (!changes.added().isEmpty() || !changes.removed().isEmpty())) {
                listener.onSkillChanges(changes.added(), changes.removed());
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void close() {
        running = false;
        scheduler.shutdown();
        try {
            watchService.close();
        } catch (IOException ignored) {
        }
    }
}
