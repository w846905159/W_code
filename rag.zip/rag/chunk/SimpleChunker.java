package com.mewcode.rag.chunk;

import com.mewcode.rag.model.Chunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SimpleChunker implements Chunker {

    private final int linesPerChunk;

    public SimpleChunker() {
        this(100);
    }

    public SimpleChunker(int linesPerChunk) {
        this.linesPerChunk = linesPerChunk;
    }

    @Override
    public List<Chunk> chunk(long sourceId, String text, String filePath) {
        String[] lines = text.split("\n", -1);
        var chunks = new ArrayList<Chunk>();
        int chunkIndex = 0;

        for (int i = 0; i < lines.length; i += linesPerChunk) {
            int end = Math.min(i + linesPerChunk, lines.length);
            var sb = new StringBuilder();
            for (int j = i; j < end; j++) {
                sb.append(lines[j]).append('\n');
            }

            Map<String, Object> metadata = Map.of(
                    "file", filePath,
                    "lineStart", i + 1,
                    "lineEnd", end
            );
            chunks.add(new Chunk(sourceId, chunkIndex++, sb.toString(), metadata));
        }

        return chunks;
    }
}
