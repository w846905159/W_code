package com.mewcode.rag.chunk;

import com.mewcode.rag.model.Chunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class HeadingChunker implements Chunker {

    private static final Pattern HEADING_PATTERN = Pattern.compile("^(#{2,3})\\s+(.+)$", Pattern.MULTILINE);

    @Override
    public List<Chunk> chunk(long sourceId, String text, String filePath) {
        var matcher = HEADING_PATTERN.matcher(text);
        var chunks = new ArrayList<Chunk>();
        int chunkIndex = 0;
        int lastStart = 0;
        String lastHeading = "(top)";

        while (matcher.find()) {
            if (matcher.start() > lastStart) {
                String sectionContent = text.substring(lastStart, matcher.start()).strip();
                if (!sectionContent.isEmpty()) {
                    chunks.add(new Chunk(sourceId, chunkIndex++, sectionContent,
                            Map.of("file", filePath, "heading", lastHeading)));
                }
            }
            lastHeading = matcher.group(2);
            lastStart = matcher.start();
        }

        String remaining = text.substring(lastStart).strip();
        if (!remaining.isEmpty()) {
            chunks.add(new Chunk(sourceId, chunkIndex++, remaining,
                    Map.of("file", filePath, "heading", lastHeading)));
        }

        if (chunks.isEmpty()) {
            return new SimpleChunker(50).chunk(sourceId, text, filePath);
        }

        return chunks;
    }
}
