package com.mewcode.rag.chunk;

import com.mewcode.rag.model.Chunk;

import java.util.List;

public interface Chunker {
    List<Chunk> chunk(long sourceId, String text, String filePath);
}
