package com.mewcode.rag.chunk;

import com.mewcode.rag.model.Chunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Chunks text by its numbered-outline headings, e.g. lines like
 * "2.3.10 switch语句", "1 概述", "2.1 命名". Designed for Chinese
 * technical/standards PDFs that use a numeric section hierarchy.
 *
 * <p>Each section becomes one chunk with metadata {file, heading}.
 * Title/intro lines before the first numbered heading are attached to the
 * first chunk. A configured max length guards against oversized sections.
 */
public class OutlineChunker implements Chunker {

    private static final Pattern OUTLINE =
            Pattern.compile("(?m)^[ \\t]*(?<num>\\d+(?:\\.\\d+)*)[ \\t]+(?<title>\\S.*)$");

    private final int maxChunkChars;
    private final Pattern noise;

    public OutlineChunker() {
        this(4000);
    }

    public OutlineChunker(int maxChunkChars) {
        this.maxChunkChars = maxChunkChars;
        // Footer/header noise: standalone doc ids like "21631" and page numbers.
        this.noise = Pattern.compile("(?m)^[ \\t]*\\d{3,}[ \\t]*$");
    }

    @Override
    public List<Chunk> chunk(long sourceId, String text, String filePath) {
        String cleaned = cleanNoise(text);
        List<Chunk> chunks = new ArrayList<>();

        Matcher m = OUTLINE.matcher(cleaned);
        List<int[]> ranges = new ArrayList<>();   // [start, chapterLevel]
        List<String> headings = new ArrayList<>();

        int lastStart = 0;
        String lastHeading = "(top)";
        while (m.find()) {
            if (m.start() > lastStart) {
                ranges.add(new int[]{lastStart, m.start()});
                headings.add(lastHeading);
            }
            lastHeading = m.group("title");
            lastStart = m.start();
        }
        if (cleaned.length() > lastStart) {
            ranges.add(new int[]{lastStart, cleaned.length()});
            headings.add(lastHeading);
        }

        int idx = 0;
        for (int i = 0; i < ranges.size(); i++) {
            String content = cleaned.substring(ranges.get(i)[0], ranges.get(i)[1]).strip();
            if (content.isEmpty()) continue;
            for (String piece : splitLong(content)) {
                chunks.add(new Chunk(sourceId, idx++, piece,
                        Map.of("file", filePath, "heading", headings.get(i))));
            }
        }

        if (chunks.isEmpty()) {
            return new SimpleChunker(80).chunk(sourceId, cleaned, filePath);
        }
        return chunks;
    }

    private String cleanNoise(String text) {
        String s = noise.matcher(text).replaceAll("").replaceAll("(?m)^[ \\t]*\n", "");
        return s.strip();
    }

    private List<String> splitLong(String text) {
        if (text.length() <= maxChunkChars) {
            return List.of(text);
        }
        List<String> out = new ArrayList<>();
        int from = 0;
        while (from < text.length()) {
            int to = Math.min(from + maxChunkChars, text.length());
            int cut = text.lastIndexOf('\n', to);
            if (cut > from + maxChunkChars / 2) to = cut;
            out.add(text.substring(from, to).strip());
            from = to;
        }
        return out;
    }
}
