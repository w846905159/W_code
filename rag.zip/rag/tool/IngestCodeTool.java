package com.mewcode.rag.tool;

import com.mewcode.rag.RagConfig;
import com.mewcode.rag.chunk.SimpleChunker;
import com.mewcode.rag.document.CodeParser;
import com.mewcode.rag.embedding.EmbeddingService;
import com.mewcode.rag.model.Source;
import com.mewcode.rag.model.Chunk;
import com.mewcode.rag.store.VectorStore;
import com.mewcode.tool.Tool;
import com.mewcode.tool.ToolCategory;
import com.mewcode.tool.ToolResult;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class IngestCodeTool implements Tool {

    private static final String DESCRIPTION = """
            Scan a directory and ingest source code files into the RAG knowledge base.
            Supports: .java, .go, .kt, .ts, .js, .py, .rs, .cpp, .c, .h files.
            Files are parsed, split into chunks, embedded, and stored for later retrieval.
            """;

    private final VectorStore store;
    private final EmbeddingService embedding;
    private final RagConfig config;
    private final CodeParser codeParser;
    private final SimpleChunker chunker;

    public IngestCodeTool(VectorStore store, EmbeddingService embedding, RagConfig config) {
        this.store = store;
        this.embedding = embedding;
        this.config = config;
        this.codeParser = new CodeParser();
        this.chunker = new SimpleChunker(config.getChunkLines());
    }

    @Override
    public String name() { return "IngestCode"; }

    @Override
    public String description() { return DESCRIPTION; }

    @Override
    public ToolCategory category() { return ToolCategory.COMMAND; }

    @Override
    public boolean shouldDefer() { return false; }

    @Override
    public Map<String, Object> schema() {
        return Map.of(
                "name", name(),
                "description", description(),
                "input_schema", Map.of(
                        "type", "object",
                        "properties", Map.of(
                                "path", Map.of("type", "string", "description", "Directory path to scan for source code"),
                                "glob", Map.of("type", "string", "description",
                                        "File glob pattern (default: **/*.java)")
                        ),
                        "required", List.of("path")
                )
        );
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(Map<String, Object> args) {
        String dirPath = (String) args.get("path");
        String globPattern = args.containsKey("glob") ? (String) args.get("glob") : "**/*.java";

        Path root = Path.of(dirPath);
        if (!Files.isDirectory(root)) {
            return ToolResult.error("Directory not found: " + dirPath);
        }

        var extensions = new HashSet<>(codeParser.supportedExtensions());
        var codeFiles = new ArrayList<Path>();
        var matcher = root.getFileSystem().getPathMatcher("glob:" + globPattern);

        try {
            Files.walkFileTree(root, Set.of(FileVisitOption.FOLLOW_LINKS), Integer.MAX_VALUE,
                    new SimpleFileVisitor<>() {
                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                            String fileName = file.getFileName().toString();
                            if (matcher.matches(file) && extensions.stream().anyMatch(ext ->
                                    fileName.endsWith(ext))) {
                                codeFiles.add(file);
                            }
                            return FileVisitResult.CONTINUE;
                        }
                    });
        } catch (IOException e) {
            return ToolResult.error("Error scanning directory: " + e.getMessage());
        }

        if (codeFiles.isEmpty()) {
            return ToolResult.success("No matching code files found in " + dirPath);
        }

        int totalChunks = 0;
        int totalFiles = 0;
        var errors = new ArrayList<String>();

        for (Path file : codeFiles) {
            try {
                String relativePath = root.relativize(file).toString();
                String text = codeParser.parseText(file);
                if (text.isBlank()) continue;

                var source = new Source("code", relativePath, relativePath);
                long sourceId = store.insertSource(source);

                var chunks = chunker.chunk(sourceId, text, relativePath);

                var texts = chunks.stream().map(Chunk::getContent).toList();
                var embeddings = embedding.embedBatch(texts);

                for (int i = 0; i < chunks.size(); i++) {
                    chunks.get(i).setEmbedding(embeddings.get(i));
                    store.insertChunk(chunks.get(i));
                }

                totalFiles++;
                totalChunks += chunks.size();

            } catch (Exception e) {
                errors.add(file.getFileName() + ": " + e.getMessage());
            }
        }

        var sb = new StringBuilder();
        sb.append("Ingested ").append(totalFiles).append(" files (").append(totalChunks)
                .append(" chunks) from ").append(dirPath);
        if (!errors.isEmpty()) {
            sb.append("\nErrors (").append(errors.size()).append("):");
            for (var err : errors) {
                sb.append("\n  - ").append(err);
            }
        }
        return ToolResult.success(sb.toString());
    }
}
