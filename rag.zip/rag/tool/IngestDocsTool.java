package com.mewcode.rag.tool;

import com.mewcode.rag.RagConfig;
import com.mewcode.rag.chunk.HeadingChunker;
import com.mewcode.rag.chunk.SimpleChunker;
import com.mewcode.rag.document.*;
import com.mewcode.rag.embedding.EmbeddingService;
import com.mewcode.rag.model.Chunk;
import com.mewcode.rag.model.Source;
import com.mewcode.rag.store.VectorStore;
import com.mewcode.tool.Tool;
import com.mewcode.tool.ToolCategory;
import com.mewcode.tool.ToolResult;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class IngestDocsTool implements Tool {

    private static final String DESCRIPTION = """
            Ingest documents (markdown, text, PDF, Word) into the RAG knowledge base.
            Supports: .md, .txt, .pdf, .docx files.
            Documents are parsed, split into chunks, embedded, and stored for retrieval.
            """;

    private final VectorStore store;
    private final EmbeddingService embedding;
    private final RagConfig config;
    private final Map<String, DocumentParser> parsers;
    private final HeadingChunker headingChunker;
    private final SimpleChunker simpleChunker;

    public IngestDocsTool(VectorStore store, EmbeddingService embedding, RagConfig config) {
        this.store = store;
        this.embedding = embedding;
        this.config = config;

        this.parsers = new HashMap<>();
        for (var parser : List.of(
                new TextParser(), new MarkdownParser(),
                new PdfParser(), new WordParser())) {
            for (var ext : parser.supportedExtensions()) {
                parsers.put(ext, parser);
            }
        }

        this.headingChunker = new HeadingChunker();
        this.simpleChunker = new SimpleChunker(config.getChunkLines());
    }

    @Override
    public String name() { return "IngestDocs"; }

    @Override
    public String description() { return DESCRIPTION; }

    @Override
    public ToolCategory category() { return ToolCategory.COMMAND; }

    @Override
    public boolean shouldDefer() { return false; }

    @Override
    public Map<String, Object> schema() {
        return Map.of(
                "name", name(),
                "description", description(),
                "input_schema", Map.of(
                        "type", "object",
                        "properties", Map.of(
                                "path", Map.of("type", "string", "description", "File or directory path to ingest"),
                                "recursive", Map.of("type", "boolean", "description",
                                        "Recurse into subdirectories (default: false)")
                        ),
                        "required", List.of("path")
                )
        );
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(Map<String, Object> args) {
        String pathStr = (String) args.get("path");
        boolean recursive = Boolean.TRUE.equals(args.get("recursive"));

        Path target = Path.of(pathStr);
        if (!Files.exists(target)) {
            return ToolResult.error("Path not found: " + pathStr);
        }

        var files = new ArrayList<Path>();
        if (Files.isDirectory(target)) {
            int maxDepth = recursive ? Integer.MAX_VALUE : 1;
            try {
                Files.walkFileTree(target, Set.of(FileVisitOption.FOLLOW_LINKS), maxDepth,
                        new SimpleFileVisitor<>() {
                            @Override
                            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                                String name = file.getFileName().toString();
                                if (parsers.keySet().stream().anyMatch(name::endsWith)) {
                                    files.add(file);
                                }
                                return FileVisitResult.CONTINUE;
                            }
                        });
            } catch (IOException e) {
                return ToolResult.error("Error scanning directory: " + e.getMessage());
            }
        } else {
            files.add(target);
        }

        if (files.isEmpty()) {
            return ToolResult.success("No supported documents found in " + pathStr);
        }

        int totalChunks = 0;
        int totalFiles = 0;
        var errors = new ArrayList<String>();

        for (Path file : files) {
            try {
                String ext = getExtension(file.getFileName().toString());
                var parser = parsers.get(ext);
                if (parser == null) continue;

                String text = parser.parseText(file);
                if (text.isBlank()) continue;

                String relativePath = target.relativize(file).toString();
                if (!Files.isDirectory(target)) {
                    relativePath = file.getFileName().toString();
                }

                var source = new Source("file", relativePath, relativePath);
                long sourceId = store.insertSource(source);

                List<Chunk> chunks;
                if (".md".equals(ext) || ".mdx".equals(ext)) {
                    chunks = headingChunker.chunk(sourceId, text, relativePath);
                } else {
                    chunks = simpleChunker.chunk(sourceId, text, relativePath);
                }

                var texts = chunks.stream().map(Chunk::getContent).toList();
                var embeddings = embedding.embedBatch(texts);

                for (int i = 0; i < chunks.size(); i++) {
                    chunks.get(i).setEmbedding(embeddings.get(i));
                    store.insertChunk(chunks.get(i));
                }

                totalFiles++;
                totalChunks += chunks.size();

            } catch (Exception e) {
                errors.add(file.getFileName() + ": " + e.getMessage());
            }
        }

        var sb = new StringBuilder();
        sb.append("Ingested ").append(totalFiles).append(" documents (").append(totalChunks)
                .append(" chunks) from ").append(pathStr);
        if (!errors.isEmpty()) {
            sb.append("\nErrors (").append(errors.size()).append("):");
            for (var err : errors) {
                sb.append("\n  - ").append(err);
            }
        }
        return ToolResult.success(sb.toString());
    }

    private String getExtension(String filename) {
        int dot = filename.lastIndexOf('.');
        return dot > 0 ? filename.substring(dot).toLowerCase() : "";
    }
}
