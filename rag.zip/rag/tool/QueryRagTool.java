package com.mewcode.rag.tool;

import com.mewcode.rag.RagConfig;
import com.mewcode.rag.embedding.EmbeddingService;
import com.mewcode.rag.store.VectorStore;
import com.mewcode.tool.Tool;
import com.mewcode.tool.ToolCategory;
import com.mewcode.tool.ToolResult;

import java.util.List;
import java.util.Map;

public class QueryRagTool implements Tool {

    private static final String DESCRIPTION = """
            Query the RAG knowledge base and return relevant context.
            Accepts a natural language query, retrieves the most relevant chunks
            from ingested documents and code, and returns them with source information.
            """;

    private final VectorStore store;
    private final EmbeddingService embedding;
    private final RagConfig config;

    public QueryRagTool(VectorStore store, EmbeddingService embedding, RagConfig config) {
        this.store = store;
        this.embedding = embedding;
        this.config = config;
    }

    @Override
    public String name() { return "QueryRAG"; }

    @Override
    public String description() { return DESCRIPTION; }

    @Override
    public ToolCategory category() { return ToolCategory.READ; }

    @Override
    public boolean shouldDefer() { return false; }

    @Override
    public Map<String, Object> schema() {
        return Map.of(
                "name", name(),
                "description", description(),
                "input_schema", Map.of(
                        "type", "object",
                        "properties", Map.of(
                                "query", Map.of("type", "string", "description",
                                        "Natural language query to search the knowledge base"),
                                "top_k", Map.of("type", "integer", "description",
                                        "Number of results to return (default: " + config.getTopK() + ")")
                        ),
                        "required", List.of("query")
                )
        );
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(Map<String, Object> args) {
        String query = (String) args.get("query");
        int topK = args.containsKey("top_k") ? ((Number) args.get("top_k")).intValue() : config.getTopK();

        if (query == null || query.isBlank()) {
            return ToolResult.error("Query cannot be empty");
        }

        try {
            float[] queryEmbedding = embedding.embed(query);
            var chunks = store.search(queryEmbedding, topK);

            if (chunks.isEmpty()) {
                return ToolResult.success("No relevant results found in the knowledge base. " +
                        "Try ingesting documents first with IngestCode or IngestDocs.");
            }

            var sb = new StringBuilder();
            sb.append("Found ").append(chunks.size()).append(" relevant results:\n\n");

            for (int i = 0; i < chunks.size(); i++) {
                var chunk = chunks.get(i);
                sb.append("--- Result ").append(i + 1).append(" ---\n");

                var meta = chunk.getMetadata();
                if (meta != null) {
                    if (meta.containsKey("file")) {
                        sb.append("Source: ").append(meta.get("file")).append("\n");
                    }
                    if (meta.containsKey("heading")) {
                        sb.append("Section: ").append(meta.get("heading")).append("\n");
                    }
                    if (meta.containsKey("lineStart") && meta.containsKey("lineEnd")) {
                        sb.append("Lines: ").append(meta.get("lineStart"))
                                .append("-").append(meta.get("lineEnd")).append("\n");
                    }
                }

                String content = chunk.getContent();
                if (content.length() > 2000) {
                    content = content.substring(0, 2000) + "\n... (truncated)";
                }
                sb.append(content).append("\n\n");
            }

            return ToolResult.success(sb.toString());

        } catch (Exception e) {
            return ToolResult.error("Query failed: " + e.getMessage());
        }
    }
}
