package com.mewcode.rag.embedding;

import java.util.List;

public interface EmbeddingService {
    float[] embed(String text) throws Exception;
    List<float[]> embedBatch(List<String> texts) throws Exception;
    int dimension();
}
