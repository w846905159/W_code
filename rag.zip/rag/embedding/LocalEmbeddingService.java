package com.mewcode.rag.embedding;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure-Java, offline embedding service. No API key, no native libraries.
 *
 * <p>Produces a deterministic fixed-dimension vector using hashed character
 * n-gram term frequencies. This is a bag-of-features lexical embedding: it
 * captures lexical overlap between text, which is sufficient for local
 * code/document retrieval and works fully offline. It does not understand
 * semantics the way a neural embedding does, but requires no external service.
 */
public class LocalEmbeddingService implements EmbeddingService {

    private static final int DIM = 1024;
    private static final int MIN_NGRAM = 2;
    private static final int MAX_NGRAM = 3;

    public LocalEmbeddingService() {
    }

    @Override
    public float[] embed(String text) throws Exception {
        var results = embedBatch(List.of(text));
        return results.isEmpty() ? new float[DIM] : results.get(0);
    }

    @Override
    public List<float[]> embedBatch(List<String> texts) {
        var results = new ArrayList<float[]>(texts.size());
        for (String text : texts) {
            results.add(embedOne(text));
        }
        return results;
    }

    @Override
    public int dimension() {
        return DIM;
    }

    private float[] embedOne(String text) {
        float[] vec = new float[DIM];
        if (text == null) {
            return vec;
        }
        String normalized = text.toLowerCase().replaceAll("\\s+", " ");
        int len = normalized.length();
        int total = 0;

        for (int n = MIN_NGRAM; n <= MAX_NGRAM && n <= len; n++) {
            for (int i = 0; i + n <= len; i++) {
                String gram = normalized.substring(i, i + n);
                int bucket = bucket(gram);
                vec[bucket] += 1.0f;
                total++;
            }
        }

        // L2-normalize so cosine similarity works correctly.
        float norm = 0;
        for (float v : vec) {
            norm += v * v;
        }
        norm = (float) Math.sqrt(norm);
        if (norm > 0) {
            for (int i = 0; i < DIM; i++) {
                vec[i] /= norm;
            }
        }
        return vec;
    }

    private int bucket(String gram) {
        int hash = 0;
        for (int i = 0; i < gram.length(); i++) {
            hash = (hash * 31 + gram.charAt(i)) & 0x7fffffff;
        }
        return hash % DIM;
    }
}
