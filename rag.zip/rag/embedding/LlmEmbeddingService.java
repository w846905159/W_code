package com.mewcode.rag.embedding;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LlmEmbeddingService implements EmbeddingService {

    private final String apiKey;
    private final String apiUrl;
    private final String model;
    private final int dimension;
    private final HttpClient httpClient;
    private final ObjectMapper jsonMapper;

    public LlmEmbeddingService(String apiKey, String apiUrl, String model, int dimension) {
        this.apiKey = apiKey;
        this.apiUrl = apiUrl;
        this.model = model;
        this.dimension = dimension;
        this.httpClient = HttpClient.newHttpClient();
        this.jsonMapper = new ObjectMapper();
    }

    public static LlmEmbeddingService forOpenAI(String apiKey) {
        return new LlmEmbeddingService(
                apiKey,
                "https://api.openai.com/v1/embeddings",
                "text-embedding-3-small",
                1536);
    }

    @Override
    public float[] embed(String text) throws Exception {
        var results = embedBatch(List.of(text));
        return results.isEmpty() ? new float[dimension] : results.get(0);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<float[]> embedBatch(List<String> texts) throws Exception {
        var requestBody = Map.of(
                "input", texts,
                "model", model
        );

        var request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonMapper.writeValueAsString(requestBody)))
                .build();

        var response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new RuntimeException("Embedding API error: " + response.statusCode() + " " + response.body());
        }

        var body = jsonMapper.readValue(response.body(), Map.class);
        var data = (List<Map<String, Object>>) body.get("data");

        var results = new ArrayList<float[]>();
        for (var item : data) {
            var embeddingList = (List<Double>) item.get("embedding");
            float[] vec = new float[embeddingList.size()];
            for (int i = 0; i < embeddingList.size(); i++) {
                vec[i] = embeddingList.get(i).floatValue();
            }
            results.add(vec);
        }
        return results;
    }

    @Override
    public int dimension() {
        return dimension;
    }
}
