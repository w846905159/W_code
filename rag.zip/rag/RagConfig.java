package com.mewcode.rag;

import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;

public class RagConfig {

    private static final AtomicReference<RagConfig> instance = new AtomicReference<>();

    private final Path dbPath;
    private final String embeddingApiKey;
    private final String embeddingApiUrl;
    private final String embeddingModel;
    private final int embeddingDimension;
    private final int chunkLines;
    private final int topK;

    public RagConfig(Path dbPath, String embeddingApiKey, String embeddingApiUrl,
                     String embeddingModel, int embeddingDimension,
                     int chunkLines, int topK) {
        this.dbPath = dbPath;
        this.embeddingApiKey = embeddingApiKey;
        this.embeddingApiUrl = embeddingApiUrl;
        this.embeddingModel = embeddingModel;
        this.embeddingDimension = embeddingDimension;
        this.chunkLines = chunkLines;
        this.topK = topK;
    }

    public static RagConfig get() {
        return instance.get();
    }

    public static void set(RagConfig config) {
        instance.set(config);
    }

    public static RagConfig createDefault(String workDir, String apiKey) {
        return new RagConfig(
                Path.of(workDir, ".mewcode", "rag.db"),
                apiKey,
                "https://api.openai.com/v1/embeddings",
                "text-embedding-3-small",
                1536,
                100,
                5
        );
    }

    public Path getDbPath() { return dbPath; }
    public String getEmbeddingApiKey() { return embeddingApiKey; }
    public String getEmbeddingApiUrl() { return embeddingApiUrl; }
    public String getEmbeddingModel() { return embeddingModel; }
    public int getEmbeddingDimension() { return embeddingDimension; }
    public int getChunkLines() { return chunkLines; }
    public int getTopK() { return topK; }
}
