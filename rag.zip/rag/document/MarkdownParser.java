package com.mewcode.rag.document;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class MarkdownParser implements DocumentParser {

    @Override
    public String parseText(Path filePath) throws IOException {
        String content = Files.readString(filePath);
        if (content.startsWith("---")) {
            int end = content.indexOf("---", 3);
            if (end > 0) {
                content = content.substring(end + 3);
            }
        }
        return content.strip();
    }

    @Override
    public List<String> supportedExtensions() {
        return List.of(".md", ".mdx");
    }
}
