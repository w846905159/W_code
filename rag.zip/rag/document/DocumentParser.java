package com.mewcode.rag.document;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public interface DocumentParser {
    String parseText(Path filePath) throws IOException;
    List<String> supportedExtensions();
}
