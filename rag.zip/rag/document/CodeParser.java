package com.mewcode.rag.document;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class CodeParser implements DocumentParser {

    @Override
    public String parseText(Path filePath) throws IOException {
        return Files.readString(filePath);
    }

    @Override
    public List<String> supportedExtensions() {
        return List.of(".java", ".go", ".kt", ".kts", ".ts", ".js", ".py", ".rs", ".cpp", ".c", ".h", ".hpp");
    }
}
