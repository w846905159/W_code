package com.mewcode.rag.document;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class WordParser implements DocumentParser {

    @Override
    public String parseText(Path filePath) throws IOException {
        try (var doc = new XWPFDocument(Files.newInputStream(filePath));
             var extractor = new XWPFWordExtractor(doc)) {
            return extractor.getText();
        }
    }

    @Override
    public List<String> supportedExtensions() {
        return List.of(".docx");
    }
}
