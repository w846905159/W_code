package com.mewcode.rag.document;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public class PdfParser implements DocumentParser {

    @Override
    public String parseText(Path filePath) throws IOException {
        try (var doc = Loader.loadPDF(filePath.toFile())) {
            var stripper = new PDFTextStripper();
            return stripper.getText(doc);
        }
    }

    @Override
    public List<String> supportedExtensions() {
        return List.of(".pdf");
    }
}
