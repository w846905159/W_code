package com.mewcode.rag.model;

import java.util.Map;

public class Chunk {
    private long id;
    private long sourceId;
    private int chunkIndex;
    private String content;
    private Map<String, Object> metadata;
    private float[] embedding;

    public Chunk() {}

    public Chunk(long sourceId, int chunkIndex, String content, Map<String, Object> metadata) {
        this.sourceId = sourceId;
        this.chunkIndex = chunkIndex;
        this.content = content;
        this.metadata = metadata;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getSourceId() { return sourceId; }
    public void setSourceId(long sourceId) { this.sourceId = sourceId; }
    public int getChunkIndex() { return chunkIndex; }
    public void setChunkIndex(int chunkIndex) { this.chunkIndex = chunkIndex; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    public float[] getEmbedding() { return embedding; }
    public void setEmbedding(float[] embedding) { this.embedding = embedding; }
}
