package com.mewcode.rag.model;

public class Source {
    private long id;
    private String sourceType;
    private String path;
    private String title;
    private String ingestedAt;

    public Source() {}

    public Source(String sourceType, String path, String title) {
        this.sourceType = sourceType;
        this.path = path;
        this.title = title;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getSourceType() { return sourceType; }
    public void setSourceType(String sourceType) { this.sourceType = sourceType; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getIngestedAt() { return ingestedAt; }
    public void setIngestedAt(String ingestedAt) { this.ingestedAt = ingestedAt; }
}
