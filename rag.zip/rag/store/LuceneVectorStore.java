package com.mewcode.rag.store;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mewcode.rag.model.Chunk;
import com.mewcode.rag.model.Source;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.KnnFloatVectorField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.VectorSimilarityFunction;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.KnnFloatVectorQuery;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Pure-Java vector store backed by Lucene 9+ HNSW vector search.
 * Requires no native extension (unlike sqlite-vec).
 */
public class LuceneVectorStore implements VectorStore {

    private static final String FIELD_TYPE = "doc_type";
    private static final String TYPE_SOURCE = "source";
    private static final String TYPE_CHUNK = "chunk";
    private static final String FIELD_SOURCE_ID = "source_id";
    private static final String FIELD_META = "metadata";
    private static final String FIELD_EMBEDDING = "embedding";

    private final Path indexPath;
    private final ObjectMapper jsonMapper = new ObjectMapper();
    private Directory directory;
    private IndexWriter writer;
    private final AtomicLong nextSourceId = new AtomicLong(1);
    private long nextChunkId = 1;

    public LuceneVectorStore(Path indexPath) {
        this.indexPath = indexPath;
    }

    @Override
    public void initialize() throws Exception {
        Files.createDirectories(indexPath);
        directory = FSDirectory.open(indexPath);
        var config = new IndexWriterConfig();
        writer = new IndexWriter(directory, config);
        writer.commit();

        long maxSource = 0;
        try (var reader = DirectoryReader.open(directory)) {
            for (int i = 0; i < reader.maxDoc(); i++) {
                if (reader.document(i).getField(FIELD_SOURCE_ID) != null) {
                    long sid = Long.parseLong(reader.document(i).get(FIELD_SOURCE_ID));
                    if (sid > maxSource) maxSource = sid;
                }
            }
        }
        nextSourceId.set(maxSource + 1);
    }

    @Override
    public long insertSource(Source source) throws Exception {
        long id = nextSourceId.getAndIncrement();
        var doc = new Document();
        doc.add(new StringField(FIELD_TYPE, TYPE_SOURCE, Field.Store.YES));
        doc.add(new StringField(FIELD_SOURCE_ID, String.valueOf(id), Field.Store.YES));
        doc.add(new StringField("source_type", source.getSourceType(), Field.Store.YES));
        doc.add(new StringField("path", source.getPath() == null ? "" : source.getPath(), Field.Store.YES));
        if (source.getTitle() != null) {
            doc.add(new StringField("title", source.getTitle(), Field.Store.YES));
        }
        doc.add(new StringField("ingested_at",
                source.getIngestedAt() == null ? now() : source.getIngestedAt(), Field.Store.YES));
        writer.addDocument(doc);
        writer.commit();
        return id;
    }

    @Override
    public long insertChunk(Chunk chunk) throws Exception {
        String metadataJson = chunk.getMetadata() != null
                ? jsonMapper.writeValueAsString(chunk.getMetadata())
                : "{}";
        long id = nextChunkId++;

        var doc = new Document();
        doc.add(new StringField(FIELD_TYPE, TYPE_CHUNK, Field.Store.YES));
        doc.add(new StringField("id", String.valueOf(id), Field.Store.YES));
        doc.add(new StringField(FIELD_SOURCE_ID, String.valueOf(chunk.getSourceId()), Field.Store.YES));
        doc.add(new StoredField("chunk_index", chunk.getChunkIndex()));
        doc.add(new StoredField("content", chunk.getContent()));
        doc.add(new StoredField(FIELD_META, metadataJson));
        doc.add(new KnnFloatVectorField(FIELD_EMBEDDING, chunk.getEmbedding(),
                VectorSimilarityFunction.COSINE));
        writer.addDocument(doc);
        writer.commit();
        return id;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Chunk> search(float[] queryEmbedding, int topK) throws Exception {
        var results = new ArrayList<Chunk>();
        try (var reader = DirectoryReader.open(writer)) {
            var searcher = new IndexSearcher(reader);
            var topDocs = searcher.search(new KnnFloatVectorQuery(FIELD_EMBEDDING, queryEmbedding, topK), topK);
            for (ScoreDoc sd : topDocs.scoreDocs) {
                Document doc = searcher.doc(sd.doc);
                if (isChunk(doc)) {
                    results.add(toChunk(doc));
                }
            }
        }
        return results;
    }

    @Override
    public List<Source> listSources() throws Exception {
        var sources = new ArrayList<Source>();
        try (var reader = DirectoryReader.open(writer)) {
            for (int i = 0; i < reader.maxDoc(); i++) {
                Document doc = reader.document(i);
                if (isSource(doc)) {
                    Source s = new Source();
                    s.setId(Long.parseLong(doc.get(FIELD_SOURCE_ID)));
                    s.setSourceType(doc.get("source_type"));
                    s.setPath(doc.get("path"));
                    s.setTitle(doc.get("title"));
                    s.setIngestedAt(doc.get("ingested_at"));
                    sources.add(s);
                }
            }
        }
        sources.sort(Comparator.comparing(Source::getIngestedAt).reversed());
        return sources;
    }

    @Override
    public void deleteSource(long sourceId) throws Exception {
        writer.deleteDocuments(new Term(FIELD_SOURCE_ID, String.valueOf(sourceId)));
        writer.commit();
    }

    @Override
    public void close() throws Exception {
        if (writer != null) writer.close();
        if (directory != null) directory.close();
    }

    private boolean isSource(Document doc) {
        return TYPE_SOURCE.equals(doc.get(FIELD_TYPE));
    }

    private boolean isChunk(Document doc) {
        return TYPE_CHUNK.equals(doc.get(FIELD_TYPE));
    }

    @SuppressWarnings("unchecked")
    private Chunk toChunk(Document doc) throws IOException {
        var chunk = new Chunk();
        String idField = doc.get("id");
        chunk.setId(idField != null ? Long.parseLong(idField) : -1);
        chunk.setSourceId(Long.parseLong(doc.get(FIELD_SOURCE_ID)));
        chunk.setChunkIndex(doc.getField("chunk_index") != null
                ? doc.getField("chunk_index").numericValue().intValue() : 0);
        chunk.setContent(doc.get("content"));
        String metaJson = doc.get(FIELD_META);
        if (metaJson != null) {
            try {
                chunk.setMetadata(jsonMapper.readValue(metaJson, Map.class));
            } catch (Exception ignored) {
            }
        }
        return chunk;
    }

    private String now() {
        return java.time.LocalDateTime.now().toString();
    }
}
