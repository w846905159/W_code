package com.mewcode.rag.store;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mewcode.rag.model.Chunk;
import com.mewcode.rag.model.Source;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SqliteVecStore implements VectorStore {

    private static final int EMBEDDING_DIM = 1536;
    private static final String VEC_EXT_NAME = "vec0";

    private final Path dbPath;
    private Connection conn;
    private final ObjectMapper jsonMapper = new ObjectMapper();

    public SqliteVecStore(Path dbPath) {
        this.dbPath = dbPath;
    }

    @Override
    public void initialize() throws Exception {
        Files.createDirectories(dbPath.getParent());

        conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath.toAbsolutePath());

        try (var stmt = conn.createStatement()) {
            stmt.execute("SELECT load_extension('" + findVecExtension() + "')");
        }

        try (var stmt = conn.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS sources (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_type TEXT    NOT NULL,
                    path        TEXT    NOT NULL,
                    title       TEXT,
                    ingested_at TEXT    NOT NULL DEFAULT (datetime('now')),
                    UNIQUE(source_type, path)
                )
            """);

            stmt.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks USING vec0(
                    id          INTEGER PRIMARY KEY,
                    source_id   INTEGER,
                    chunk_index INTEGER,
                    content     TEXT,
                    metadata    TEXT,
                    embedding   FLOAT[%d]
                )
            """.formatted(EMBEDDING_DIM));
        }
    }

    @Override
    public long insertSource(Source source) throws Exception {
        try (var stmt = conn.prepareStatement(
                "INSERT OR REPLACE INTO sources (source_type, path, title) VALUES (?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, source.getSourceType());
            stmt.setString(2, source.getPath());
            stmt.setString(3, source.getTitle());
            stmt.executeUpdate();
            var rs = stmt.getGeneratedKeys();
            return rs.next() ? rs.getLong(1) : -1;
        }
    }

    @Override
    public long insertChunk(Chunk chunk) throws Exception {
        String metadataJson = chunk.getMetadata() != null
                ? jsonMapper.writeValueAsString(chunk.getMetadata())
                : "{}";

        float[] emb = chunk.getEmbedding();
        StringBuilder embStr = new StringBuilder("[");
        for (int i = 0; i < emb.length; i++) {
            if (i > 0) embStr.append(",");
            embStr.append(emb[i]);
        }
        embStr.append("]");

        try (var stmt = conn.prepareStatement(
                "INSERT INTO chunks (source_id, chunk_index, content, metadata, embedding) VALUES (?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, chunk.getSourceId());
            stmt.setInt(2, chunk.getChunkIndex());
            stmt.setString(3, chunk.getContent());
            stmt.setString(4, metadataJson);
            stmt.setObject(5, embStr.toString(), Types.OTHER);
            stmt.executeUpdate();
            var rs = stmt.getGeneratedKeys();
            return rs.next() ? rs.getLong(1) : -1;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Chunk> search(float[] queryEmbedding, int topK) throws Exception {
        StringBuilder embStr = new StringBuilder("[");
        for (int i = 0; i < queryEmbedding.length; i++) {
            if (i > 0) embStr.append(",");
            embStr.append(queryEmbedding[i]);
        }
        embStr.append("]");

        var results = new ArrayList<Chunk>();
        String sql = """
            SELECT c.id, c.source_id, c.chunk_index, c.content, c.metadata, c.embedding, distance
            FROM chunks WHERE embedding MATCH ? AND k = ?
            ORDER BY distance
        """;

        try (var stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, embStr.toString(), Types.OTHER);
            stmt.setInt(2, topK);
            var rs = stmt.executeQuery();
            while (rs.next()) {
                var chunk = new Chunk();
                chunk.setId(rs.getLong("id"));
                chunk.setSourceId(rs.getLong("source_id"));
                chunk.setChunkIndex(rs.getInt("chunk_index"));
                chunk.setContent(rs.getString("content"));
                String metaJson = rs.getString("metadata");
                if (metaJson != null) {
                    chunk.setMetadata(jsonMapper.readValue(metaJson, Map.class));
                }
                results.add(chunk);
            }
        }
        return results;
    }

    @Override
    public List<Source> listSources() throws Exception {
        var sources = new ArrayList<Source>();
        try (var stmt = conn.createStatement()) {
            var rs = stmt.executeQuery("SELECT id, source_type, path, title, ingested_at FROM sources ORDER BY ingested_at DESC");
            while (rs.next()) {
                var s = new Source();
                s.setId(rs.getLong("id"));
                s.setSourceType(rs.getString("source_type"));
                s.setPath(rs.getString("path"));
                s.setTitle(rs.getString("title"));
                s.setIngestedAt(rs.getString("ingested_at"));
                sources.add(s);
            }
        }
        return sources;
    }

    @Override
    public void deleteSource(long sourceId) throws Exception {
        try (var stmt = conn.prepareStatement("DELETE FROM chunks WHERE source_id = ?")) {
            stmt.setLong(1, sourceId);
            stmt.executeUpdate();
        }
        try (var stmt = conn.prepareStatement("DELETE FROM sources WHERE id = ?")) {
            stmt.setLong(1, sourceId);
            stmt.executeUpdate();
        }
    }

    @Override
    public void close() throws Exception {
        if (conn != null) conn.close();
    }

    private String findVecExtension() {
        String os = System.getProperty("os.name").toLowerCase();
        String libName;
        if (os.contains("win")) {
            libName = "vec0.dll";
        } else if (os.contains("mac")) {
            libName = "vec0.dylib";
        } else {
            libName = "vec0.so";
        }

        String[] searchPaths = {
            ".mewcode/vec/" + libName,
            System.getProperty("user.home") + "/.mewcode/vec/" + libName,
            "/usr/local/lib/" + libName,
            "/usr/lib/" + libName
        };

        for (String path : searchPaths) {
            if (Files.exists(Path.of(path))) {
                return Path.of(path).toAbsolutePath().toString();
            }
        }

        return libName;
    }
}
