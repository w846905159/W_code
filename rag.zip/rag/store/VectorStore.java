package com.mewcode.rag.store;

import com.mewcode.rag.model.Chunk;
import com.mewcode.rag.model.Source;
import java.util.List;

public interface VectorStore {
    void initialize() throws Exception;
    long insertSource(Source source) throws Exception;
    long insertChunk(Chunk chunk) throws Exception;
    List<Chunk> search(float[] queryEmbedding, int topK) throws Exception;
    List<Source> listSources() throws Exception;
    void deleteSource(long sourceId) throws Exception;
    void close() throws Exception;
}
