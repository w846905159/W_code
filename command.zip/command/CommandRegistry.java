package com.mewcode.command;

import com.mewcode.command.Command.CommandType;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CommandRegistry {

    private final List<Command> commands = new ArrayList<>();
    private final Map<String, Function<CommandContext, String>> handlers = new HashMap<>();

    public CommandRegistry() {
        registerDefaults();
    }

    public void register(Command cmd, Function<CommandContext, String> handler) {
        commands.add(cmd);
        if (handler != null) {
            handlers.put(cmd.name(), handler);
            for (var alias : cmd.aliases()) {
                handlers.put(alias, handler);
            }
        }
    }

    public List<Command> search(String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return commands.stream()
                .filter(c -> !c.hidden())
                .filter(c -> {
                    if (c.name().toLowerCase(Locale.ROOT).startsWith(lower)) return true;
                    for (var alias : c.aliases()) {
                        if (alias.toLowerCase(Locale.ROOT).startsWith(lower)) return true;
                    }
                    return false;
                })
                .sorted(Comparator.comparing(Command::name))
                .collect(Collectors.toList());
    }

    public Optional<Command> find(String name) {
        return commands.stream()
                .filter(c -> c.matches(name))
                .findFirst();
    }

    public String execute(String name, CommandContext ctx) {
        Function<CommandContext, String> handler = handlers.get(name);
        if (handler != null) return handler.apply(ctx);
        Optional<Command> cmd = find(name);
        if (cmd.isEmpty()) return "Unknown command: " + name;
        handler = handlers.get(cmd.get().name());
        if (handler != null) return handler.apply(ctx);
        return "No handler registered for /" + name;
    }

    public List<Command> listAll() {
        return Collections.unmodifiableList(commands);
    }

    public List<Command> listVisible() {
        return commands.stream()
                .filter(c -> !c.hidden())
                .sorted(Comparator.comparing(Command::name))
                .collect(Collectors.toList());
    }

    private void registerDefaults() {
        // /help
        register(
                new Command("help", "Show available commands",
                        new String[]{"h", "?"}, CommandType.LOCAL, false),
                ctx -> {
                    String args = ctx.args();
                    if (args != null && !args.isBlank()) {
                        Optional<Command> target = find(args.strip());
                        if (target.isEmpty()) return "Unknown command: " + args.strip();
                        Command c = target.get();
                        var sb = new StringBuilder();
                        sb.append("/").append(c.name()).append(" — ").append(c.description()).append("\n");
                        if (c.aliases().length > 0)
                            sb.append("  Aliases: ").append(String.join(", ", c.aliases())).append("\n");
                        return sb.toString();
                    }
                    var sb = new StringBuilder("Available commands:\n\n");
                    for (var cmd : listVisible()) {
                        String aliases = "";
                        if (cmd.aliases().length > 0)
                            aliases = ", /" + String.join(", /", cmd.aliases());
                        sb.append("  /").append(cmd.name()).append(aliases).append("\n");
                        sb.append("    ").append(cmd.description()).append("\n");
                    }
                    sb.append("\nType /help <command> for details.");
                    return sb.toString();
                }
        );

        // /mcp
        register(
                new Command("mcp", "Show MCP server status",
                        new String[]{}, CommandType.LOCAL, false),
                ctx -> {
                    if (ctx.mcpInfo() == null) return "No MCP servers configured";
                    String info = ctx.mcpInfo().get();
                    return info.isEmpty() ? "No MCP servers connected" : info;
                }
        );

        // /clear
        register(
                new Command("clear", "Clear conversation and start fresh",
                        new String[]{}, CommandType.LOCAL_UI, false), null
        );

        // /compact
        register(
                new Command("compact", "Compress conversation context",
                        new String[]{"c"}, CommandType.LOCAL_UI, false), null
        );

        // /status
        register(
                new Command("status", "Show current status",
                        new String[]{"s"}, CommandType.LOCAL, false),
                ctx -> {
                    var sb = new StringBuilder("MewCode Status\n──────────────\n");
                    sb.append("  Mode:      ").append(ctx.permissionMode().get()).append("\n");
                    int[] tokens = ctx.tokenCount().get();
                    sb.append("  Tokens:    ").append(tokens[0]).append(" in / ").append(tokens[1]).append(" out\n");
                    sb.append("  Tools:     ").append(ctx.toolCount().getAsInt()).append(" enabled\n");
                    var memories = ctx.memoryList().get();
                    sb.append("  Memories:  ").append(memories.size()).append(" entries\n");
                    sb.append("  Model:     ").append(ctx.model()).append("\n");
                    sb.append("  Directory: ").append(ctx.workDir()).append("\n");
                    return sb.toString();
                }
        );

        // /memory
        register(
                new Command("memory", "Manage auto-memories",
                        new String[]{}, CommandType.LOCAL, false),
                ctx -> {
                    String args = ctx.args();
                    String sub = (args == null || args.isBlank()) ? "list" : args.strip().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
                    return switch (sub) {
                        case "list" -> {
                            var memories = ctx.memoryList().get();
                            if (memories.isEmpty()) yield "No memories stored yet.";
                            var sb = new StringBuilder("Auto-memories (%d):\n".formatted(memories.size()));
                            for (var m : memories) sb.append("  • ").append(m).append("\n");
                            yield sb.toString();
                        }
                        case "clear" -> { ctx.memoryClear().run(); yield "All auto-memories cleared."; }
                        default -> "Usage: /memory [list|clear]";
                    };
                }
        );

        // /plan
        register(
                new Command("plan", "Switch to plan mode (read-only)",
                        new String[]{"p"}, CommandType.LOCAL_UI, false), null
        );

        // /session
        register(
                new Command("session", "Session management",
                        new String[]{}, CommandType.LOCAL, false),
                ctx -> {
                    String args = ctx.args();
                    String sub = (args == null || args.isBlank()) ? "info" : args.strip().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
                    return switch (sub) {
                        case "info" -> ctx.sessionInfo().get();
                        case "list" -> ctx.sessionInfo().get();
                        default -> "Usage: /session [list|info]";
                    };
                }
        );

        // /permission
        register(
                new Command("permission", "Permission management",
                        new String[]{"perm"}, CommandType.LOCAL, false),
                ctx -> {
                    String args = ctx.args();
                    String sub = (args == null || args.isBlank()) ? "info" : args.strip().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
                    return switch (sub) {
                        case "info" -> "Current permission mode: " + ctx.permissionMode().get();
                        case "mode" -> "Usage: /permission mode <default|acceptEdits|plan|bypassPermissions>";
                        default -> "Usage: /permission [info|mode <mode>|rules]";
                    };
                }
        );

        // /resume
        register(
                new Command("resume", "Resume a previous session",
                        new String[]{"r"}, CommandType.LOCAL_UI, false), null
        );

        // /rewind
        register(
                new Command("rewind", "Rewind to a previous checkpoint",
                        new String[]{}, CommandType.LOCAL_UI, false), null
        );

        // /skills
        register(
                new Command("skills", "List available skills",
                        new String[]{}, CommandType.LOCAL, false),
                ctx -> {
                    var skills = ctx.skillList().get();
                    if (skills.isEmpty()) return "No skills installed.\n\nAdd skills to .mewcode/skills/<skill-name>/SKILL.md";
                    var sb = new StringBuilder("Installed skills (%d):\n".formatted(skills.size()));
                    for (var s : skills) sb.append("  • ").append(s).append("\n");
                    return sb.toString();
                }
        );

        // /telemetry
        register(
                new Command("telemetry", "Show telemetry stats. Usage: /telemetry [files|<file>]",
                        new String[]{"tl"}, CommandType.LOCAL, false),
                ctx -> {
                    var store = com.mewcode.telemetry.TelemetryEmitter.getStore();
                    if (store == null) return "Telemetry not initialized.";
                    var events = store.loadAll();
                    if (events.isEmpty()) return "No telemetry data yet.";

                    // Per-file AI vs user line attribution (from the unified write path).
                    var perFile = new java.util.LinkedHashMap<String, long[]>(); // fp -> [aiAdd,userAdd,aiRem,userRem]
                    int llmTotal = 0, llmSuccess = 0;
                    long totalInput = 0, totalOutput = 0, totalLatencyMs = 0;
                    var toolCalls = new java.util.LinkedHashMap<String, int[]>();
                    int errors = 0;
                    var errorTypes = new java.util.LinkedHashMap<String, Integer>();
                    int interruptCount = 0;

                    for (var e : events) {
                        String type = (String) e.get("eventType");
                        if (type == null) continue;
                        switch (type) {
                            case "llm_request" -> {
                                llmTotal++;
                                if (Boolean.TRUE.equals(e.get("success"))) llmSuccess++;
                                totalInput += ((Number) e.getOrDefault("inputTokens", 0)).longValue();
                                totalOutput += ((Number) e.getOrDefault("outputTokens", 0)).longValue();
                                totalLatencyMs += ((Number) e.getOrDefault("latencyMs", 0)).longValue();
                            }
                            case "file_change" -> {
                                long added = ((Number) e.getOrDefault("addedLines", 0)).longValue();
                                long removed = ((Number) e.getOrDefault("removedLines", 0)).longValue();
                                String src = (String) e.get("source");
                                String fp = (String) e.get("filePath");
                                int slot = "AGENT".equals(src) ? 0 : 1;
                                long[] v = perFile.computeIfAbsent(fp, k -> new long[4]);
                                if ("AGENT".equals(src)) { v[0] += added; v[2] += removed; }
                                else { v[1] += added; v[3] += removed; }
                            }
                            case "tool_call" -> {
                                String name = (String) e.get("toolName");
                                boolean ok = Boolean.TRUE.equals(e.get("success"));
                                toolCalls.compute(name, (k, x) -> {
                                    if (x == null) x = new int[]{0, 0};
                                    x[0]++; if (ok) x[1]++;
                                    return x;
                                });
                            }
                            case "agent_error" -> {
                                errors++;
                                String et = (String) e.get("errorType");
                                if (et != null) errorTypes.merge(et, 1, Integer::sum);
                            }
                            case "interrupt" -> interruptCount++;
                        }
                    }

                    String arg = ctx.args() == null ? "" : ctx.args().strip().toLowerCase(java.util.Locale.ROOT);

                    // ── Per-file mode: /telemetry <file> ──────────────────────
                    if (!arg.isEmpty() && !"files".equals(arg)) {
                        String query = arg.toLowerCase(java.util.Locale.ROOT);
                        String[] match = perFile.entrySet().stream()
                                .filter(en -> en.getKey() != null
                                        && en.getKey().toLowerCase(java.util.Locale.ROOT).contains(query))
                                .sorted(java.util.Map.Entry.<String, long[]>comparingByKey())
                                .findFirst()
                                .map(en -> new String[]{en.getKey(), String.join(" ", perFileLine(en.getValue()))})
                                .orElse(null);
                        if (match == null) {
                            return "No telemetry found for file matching '" + arg + "'.\n"
                                    + "Try /telemetry files to list tracked files.";
                        }
                        return fileReport(match[0], perFile.get(match[0]));
                    }

                    // ── Per-file listing mode: /telemetry files ───────────────
                    if ("files".equals(arg)) {
                        if (perFile.isEmpty()) return "No file_change events recorded yet.";
                        var sb = new StringBuilder("Per-File AI Attribution\n───────────────\n");
                        perFile.entrySet().stream()
                                .sorted(java.util.Map.Entry.<String, long[]>comparingByKey())
                                .forEach(en -> {
                                    long ai = en.getValue()[0], user = en.getValue()[1];
                                    long total = ai + user;
                                    long pct = total > 0 ? ai * 100 / total : 0;
                                    sb.append("  ").append(pct).append("%  ").append(shortName(en.getKey()))
                                            .append("  (AI ").append(ai).append(" / user ").append(user).append(")\n");
                                });
                        return sb.toString();
                    }

                    // ── Aggregate mode ────────────────────────────────────────
                    long aiAdded = 0, aiRemoved = 0, userAdded = 0, userRemoved = 0;
                    for (long[] v : perFile.values()) {
                        aiAdded += v[0]; userAdded += v[1]; aiRemoved += v[2]; userRemoved += v[3];
                    }

                    var sb = new StringBuilder();
                    sb.append("Telemetry Stats\n───────────────\n");
                    sb.append("LLM Calls:     ").append(llmTotal).append(" (").append(llmSuccess).append(" success)\n");
                    sb.append("Input Tokens:  ").append(totalInput).append("\n");
                    sb.append("Output Tokens: ").append(totalOutput).append("\n");
                    if (llmTotal > 0) sb.append("Avg Latency:   ").append(totalLatencyMs / llmTotal).append("ms\n");
                    sb.append("\n");
                    sb.append("AI Generated Code:\n");
                    sb.append("  Added:   ").append(aiAdded).append(" lines\n");
                    sb.append("  Removed: ").append(aiRemoved).append(" lines\n");
                    sb.append("User Edited Code:\n");
                    sb.append("  Added:   ").append(userAdded).append(" lines\n");
                    sb.append("  Removed: ").append(userRemoved).append(" lines\n");

                    long totalGen = aiAdded + userAdded;
                    if (totalGen > 0) {
                        long aiPct = aiAdded * 100 / totalGen;
                        sb.append("\nAI Code Generation Ratio (overall):\n");
                        sb.append("  ").append(aiPct).append("% (AI: ").append(aiAdded)
                                .append(" lines / Total: ").append(totalGen).append(" lines)\n");
                    }

                    if (!perFile.isEmpty()) {
                        sb.append("\nFiles (use /telemetry <file> for detail):\n");
                        perFile.entrySet().stream()
                                .sorted(java.util.Map.Entry.<String, long[]>comparingByKey())
                                .forEach(en -> {
                                    long ai = en.getValue()[0], user = en.getValue()[1];
                                    long t = ai + user;
                                    long pct = t > 0 ? ai * 100 / t : 0;
                                    sb.append("  ").append(pct).append("%  ").append(shortName(en.getKey()))
                                            .append("\n");
                                });
                    }

                    sb.append("\nTool Calls:\n");
                    if (toolCalls.isEmpty()) sb.append("  (none)\n");
                    else toolCalls.forEach((n, v) -> {
                        double sr = v[0] > 0 ? (double) v[1] / v[0] * 100 : 0;
                        sb.append("  ").append(n).append(": ").append(v[0]).append(" calls, ")
                                .append(v[1]).append(" success (").append(String.format("%.0f", sr)).append("%)\n");
                    });

                    sb.append("\nErrors:\n");
                    if (errors == 0) sb.append("  (none)\n");
                    else {
                        sb.append("  Total: ").append(errors).append("\n");
                        errorTypes.forEach((t, c) -> sb.append("  ").append(t).append(": ").append(c).append("\n"));
                    }
                    sb.append("\nInterrupts:\n  User Ctrl+C: ").append(interruptCount).append("\n");
                    return sb.toString();
                }
        );

        // /review
        register(
                new Command("review", "Review current code changes",
                        new String[]{}, CommandType.PROMPT, false),
                ctx -> {
                    String prompt = "Please review the current git diff for code changes. Focus on:\n"
                            + "1. Logic errors\n2. Security issues\n3. Performance problems\n4. Code style";
                    String args = ctx.args();
                    if (args != null && !args.isBlank()) prompt += "\n\nAdditional focus: " + args.strip();
                    return prompt;
                }
        );
    }

    private static String perFileLine(long[] v) {
        return v[0] + " " + v[1] + " " + v[2] + " " + v[3];
    }

    private static String fileReport(String path, long[] v) {
        long aiAdded = v[0], userAdded = v[1], aiRemoved = v[2], userRemoved = v[3];
        long totalGen = aiAdded + userAdded;
        long aiPct = totalGen > 0 ? aiAdded * 100 / totalGen : 0;
        var sb = new StringBuilder();
        sb.append("File AI Attribution\n───────────────\n");
        sb.append("  ").append(path).append("\n\n");
        sb.append("AI Generated:\n  Added:   ").append(aiAdded).append(" lines\n");
        sb.append("  Removed: ").append(aiRemoved).append(" lines\n");
        sb.append("User Edited:\n  Added:   ").append(userAdded).append(" lines\n");
        sb.append("  Removed: ").append(userRemoved).append(" lines\n");
        if (totalGen > 0) {
            sb.append("\nAI Code Generation Ratio (this file):\n");
            sb.append("  ").append(aiPct).append("% (AI: ").append(aiAdded)
                    .append(" / user: ").append(userAdded).append(")\n");
        }
        return sb.toString();
    }

    private static String shortName(String path) {
        if (path == null) return "(null)";
        int idx = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        return idx >= 0 ? path.substring(idx + 1) : path;
    }
}
