package com.mewcode.command;

import java.util.List;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public record CommandContext(
        String args,
        String workDir,
        String model,
        Supplier<String> permissionMode,
        IntSupplier toolCount,
        Supplier<int[]> tokenCount,
        Supplier<List<String>> memoryList,
        Runnable memoryClear,
        Supplier<String> sessionInfo,
        Supplier<List<String>> skillList,
        Supplier<String> mcpInfo
) {}